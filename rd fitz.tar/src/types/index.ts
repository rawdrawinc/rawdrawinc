// User & Profile Types
export interface UserProfile {
  id: string;
  name: string;
  goals: FitnessGoal[];
  preferredDays: DayOfWeek[];
  equipment: Equipment[];
  createdAt: string;
  updatedAt: string;
  onboardingCompleted: boolean;
}

export type FitnessGoal = 'weight_loss' | 'strength' | 'endurance' | 'muscle_gain';
export type DayOfWeek = 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday' | 'sunday';
export type Equipment = 'dumbbells' | 'barbell' | 'kettlebell' | 'resistance_bands' | 'pull_up_bar' | 'bench' | 'cable_machine' | 'treadmill' | 'bike' | 'rower' | 'none';

// Workout Types
export interface Workout {
  id: string;
  date: string;
  name: string;
  type: WorkoutType;
  exercises: WorkoutExercise[];
  duration: number;
  intensity: 'low' | 'medium' | 'high';
  notes?: string;
  completed: boolean;
  createdAt: string;
  updatedAt: string;
}

export type WorkoutType = 'push' | 'pull' | 'legs' | 'full_body' | 'cardio' | 'rest' | 'custom';

export interface WorkoutExercise {
  exerciseId: string;
  exerciseName?: string;
  sets: ExerciseSet[];
  notes?: string;
}

export interface ExerciseSet {
  reps: number;
  weight?: number;
  duration?: number;
  completed: boolean;
}

// Exercise Types
export interface Exercise {
  id: string;
  name: string;
  muscleGroup: MuscleGroup;
  secondaryMuscles?: MuscleGroup[];
  equipment: Equipment[];
  description: string;
  instructions: string[];
  image?: string;
  gifUrl?: string;
}

export type MuscleGroup = 
  | 'chest' 
  | 'back' 
  | 'shoulders' 
  | 'biceps' 
  | 'triceps' 
  | 'forearms' 
  | 'abs' 
  | 'obliques' 
  | 'quadriceps' 
  | 'hamstrings' 
  | 'glutes' 
  | 'calves' 
  | 'neck'
  | 'cardio';

// GPS & Route Tracking Types
export interface Route {
  id: string;
  name: string;
  type: 'run' | 'walk' | 'cycle' | 'hike';
  coordinates: Coordinate[];
  distance: number;
  duration: number;
  pace: number;
  calories: number;
  date: string;
  startTime: string;
  endTime: string;
  notes?: string;
}

export interface Coordinate {
  lat: number;
  lng: number;
  timestamp: number;
  altitude?: number;
  speed?: number;
}

export interface TrackingSession {
  id: string;
  startTime: number;
  coordinates: Coordinate[];
  isActive: boolean;
  type: 'run' | 'walk' | 'cycle' | 'hike';
}

// Nutrition Types
export interface FoodEntry {
  id: string;
  name: string;
  barcode?: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber?: number;
  sugar?: number;
  sodium?: number;
  servingSize: number;
  servingUnit: string;
  date: string;
  meal: MealType;
  createdAt: string;
}

export type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export interface DailyNutrition {
  date: string;
  entries: FoodEntry[];
  targetCalories: number;
  targetProtein: number;
  targetCarbs: number;
  targetFat: number;
}

// Journal Types
export interface JournalEntry {
  id: string;
  date: string;
  title?: string;
  content: string;
  mood?: 'great' | 'good' | 'okay' | 'bad' | 'terrible';
  workoutId?: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

// Reminder Types
export interface Reminder {
  id: string;
  title: string;
  message: string;
  time: string;
  days: DayOfWeek[];
  enabled: boolean;
  sound: boolean;
  vibration: boolean;
  createdAt: string;
}

// Achievement Types
export interface Achievement {
  id: string;
  type: AchievementType;
  title: string;
  description: string;
  icon: string;
  unlockedAt?: string;
  progress: number;
  target: number;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
}

export type AchievementType = 
  | 'first_workout'
  | 'workouts_5'
  | 'workouts_10'
  | 'workouts_50'
  | 'workouts_100'
  | 'first_5km'
  | 'first_10km'
  | 'streak_7'
  | 'streak_30'
  | 'streak_100'
  | 'weight_goal'
  | 'strength_goal'
  | 'custom';

// Streak Types
export interface StreakData {
  currentStreak: number;
  longestStreak: number;
  lastWorkoutDate: string | null;
  weeklyActivity: boolean[];
}

// Template Types
export interface WorkoutTemplate {
  id: string;
  name: string;
  type: WorkoutType;
  exercises: WorkoutExercise[];
  estimatedDuration: number;
  intensity: 'low' | 'medium' | 'high';
  isDefault: boolean;
}

// Settings Types
export interface AppSettings {
  theme: 'light' | 'dark' | 'system';
  hapticFeedback: boolean;
  audioFeedback: boolean;
  notifications: boolean;
  units: 'metric' | 'imperial';
  language: string;
}

// API Response Types
export interface WgerExercise {
  id: number;
  name: string;
  description: string;
  muscles: number[];
  muscles_secondary: number[];
  equipment: number[];
  images: WgerImage[];
  language: number;
}

export interface WgerImage {
  id: number;
  exercise: number;
  image: string;
  is_main: boolean;
}

export interface WgerMuscle {
  id: number;
  name: string;
  name_en: string;
  is_front: boolean;
}

export interface WgerEquipment {
  id: number;
  name: string;
}

export interface OpenFoodFactsProduct {
  code: string;
  product_name: string;
  nutriments: {
    'energy-kcal_100g'?: number;
    proteins_100g?: number;
    carbohydrates_100g?: number;
    fat_100g?: number;
    fiber_100g?: number;
    sugars_100g?: number;
    sodium_100g?: number;
  };
  serving_size?: string;
  quantity?: string;
}

// App State Types
export type TabName = 'planner' | 'workouts' | 'tracking' | 'nutrition' | 'journal' | 'achievements' | 'profile';

export interface AppState {
  currentTab: TabName;
  isOnboarded: boolean;
  profile: UserProfile | null;
  settings: AppSettings;
  streak: StreakData;
  achievements: Achievement[];
}
