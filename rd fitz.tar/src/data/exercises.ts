// Comprehensive Exercise Database with tutorials and illustrations
// This serves as both the primary source and fallback

import type { Exercise } from '@/types';

export const COMPREHENSIVE_EXERCISES: Exercise[] = [
  // ===== CHEST EXERCISES =====
  {
    id: 'bench-press',
    name: 'Barbell Bench Press',
    muscleGroup: 'chest',
    secondaryMuscles: ['triceps', 'shoulders'],
    equipment: ['barbell', 'bench'],
    description: 'The king of chest exercises. A compound movement that builds overall chest mass and strength.',
    instructions: [
      'Lie flat on the bench with your feet firmly on the floor',
      'Grip the bar slightly wider than shoulder-width apart',
      'Unrack the bar and lower it to your mid-chest with control',
      'Keep your elbows at about 45 degrees from your body',
      'Press the bar back up to the starting position',
      'Squeeze your chest at the top of the movement'
    ],
    image: 'https://wger.de/media/exercise-images/1/Barbell-Bench-Press.png',
    gifUrl: 'https://thumbs.gfycat.com/AgileIllfatedDore-mobile.mp4',
  },
  {
    id: 'incline-bench-press',
    name: 'Incline Barbell Bench Press',
    muscleGroup: 'chest',
    secondaryMuscles: ['shoulders', 'triceps'],
    equipment: ['barbell', 'bench'],
    description: 'Targets the upper chest for a fuller, more aesthetic chest development.',
    instructions: [
      'Set the bench to a 30-45 degree angle',
      'Lie back with your feet flat on the floor',
      'Grip the bar slightly wider than shoulder-width',
      'Lower the bar to your upper chest',
      'Press the bar back up while squeezing your upper chest',
      'Keep your shoulder blades retracted throughout'
    ],
    image: 'https://wger.de/media/exercise-images/2/Incline-Bench-Press.png',
  },
  {
    id: 'dumbbell-flyes',
    name: 'Dumbbell Flyes',
    muscleGroup: 'chest',
    secondaryMuscles: ['shoulders'],
    equipment: ['dumbbells', 'bench'],
    description: 'An isolation exercise that stretches and contracts the chest for muscle definition.',
    instructions: [
      'Lie flat on a bench with dumbbells extended above your chest',
      'Keep a slight bend in your elbows throughout the movement',
      'Lower the dumbbells out to your sides in an arc motion',
      'Feel the stretch in your chest at the bottom',
      'Bring the dumbbells back up following the same arc',
      'Squeeze your chest at the top'
    ],
    image: 'https://wger.de/media/exercise-images/3/Dumbbell-Flyes.png',
  },
  {
    id: 'push-ups',
    name: 'Push-ups',
    muscleGroup: 'chest',
    secondaryMuscles: ['triceps', 'shoulders'],
    equipment: ['none'],
    description: 'A classic bodyweight exercise that builds chest, shoulders, and triceps.',
    instructions: [
      'Start in a plank position with hands slightly wider than shoulder-width',
      'Keep your body in a straight line from head to heels',
      'Lower your body until your chest nearly touches the floor',
      'Push yourself back up to the starting position',
      'Keep your core tight throughout the movement',
      'Breathe in on the way down, out on the way up'
    ],
    image: 'https://wger.de/media/exercise-images/4/Push-ups.png',
  },
  {
    id: 'chest-dips',
    name: 'Chest Dips',
    muscleGroup: 'chest',
    secondaryMuscles: ['triceps', 'shoulders'],
    equipment: ['none'],
    description: 'A bodyweight exercise that targets the lower chest and triceps.',
    instructions: [
      'Grip parallel bars with arms extended',
      'Lean your torso forward about 30 degrees',
      'Lower your body by bending your elbows',
      'Go down until your shoulders are below your elbows',
      'Push back up to the starting position',
      'Keep your elbows slightly flared for chest emphasis'
    ],
    image: 'https://wger.de/media/exercise-images/5/Chest-Dips.png',
  },

  // ===== BACK EXERCISES =====
  {
    id: 'deadlift',
    name: 'Barbell Deadlift',
    muscleGroup: 'back',
    secondaryMuscles: ['glutes', 'hamstrings', 'quadriceps'],
    equipment: ['barbell'],
    description: 'The ultimate full-body compound exercise for overall strength and mass.',
    instructions: [
      'Stand with feet hip-width apart, bar over mid-foot',
      'Bend at the hips and knees to grip the bar',
      'Keep your back straight and chest up',
      'Take a deep breath and brace your core',
      'Drive through your heels to stand up',
      'Lock out at the top by squeezing your glutes'
    ],
    image: 'https://wger.de/media/exercise-images/6/Deadlift.png',
  },
  {
    id: 'pull-ups',
    name: 'Pull-ups',
    muscleGroup: 'back',
    secondaryMuscles: ['biceps'],
    equipment: ['pull_up_bar'],
    description: 'A bodyweight exercise that builds a wide, strong back.',
    instructions: [
      'Hang from the bar with an overhand grip, hands wider than shoulder-width',
      'Engage your lats by pulling your shoulder blades down',
      'Pull yourself up until your chin is over the bar',
      'Lower yourself back down with control',
      'Avoid swinging or using momentum',
      'Focus on driving your elbows down toward your pockets'
    ],
    image: 'https://wger.de/media/exercise-images/7/Pull-ups.png',
  },
  {
    id: 'barbell-row',
    name: 'Barbell Bent-Over Row',
    muscleGroup: 'back',
    secondaryMuscles: ['biceps', 'shoulders'],
    equipment: ['barbell'],
    description: 'A compound exercise for building back thickness and strength.',
    instructions: [
      'Stand with feet shoulder-width apart, knees slightly bent',
      'Bend forward at the hips, keeping your back straight',
      'Grip the bar with hands slightly wider than shoulder-width',
      'Pull the bar to your lower chest, squeezing your shoulder blades',
      'Lower the bar back down with control',
      'Keep your torso at about 45 degrees throughout'
    ],
    image: 'https://wger.de/media/exercise-images/8/Barbell-Row.png',
  },
  {
    id: 'lat-pulldown',
    name: 'Lat Pulldown',
    muscleGroup: 'back',
    secondaryMuscles: ['biceps'],
    equipment: ['cable_machine'],
    description: 'A machine exercise that targets the latissimus dorsi for back width.',
    instructions: [
      'Sit at the lat pulldown machine and grasp the bar wide',
      'Lean back slightly and pull the bar down to your upper chest',
      'Squeeze your lats at the bottom of the movement',
      'Control the bar back up to the starting position',
      'Keep your chest up and avoid leaning back too much',
      'Focus on pulling with your elbows, not your hands'
    ],
    image: 'https://wger.de/media/exercise-images/9/Lat-Pulldown.png',
  },
  {
    id: 'seated-cable-row',
    name: 'Seated Cable Row',
    muscleGroup: 'back',
    secondaryMuscles: ['biceps', 'shoulders'],
    equipment: ['cable_machine'],
    description: 'A machine exercise for building mid-back thickness.',
    instructions: [
      'Sit at the cable row machine with feet on the platform',
      'Grasp the handle and sit upright with knees slightly bent',
      'Pull the handle to your lower chest, squeezing your shoulder blades',
      'Keep your back straight throughout the movement',
      'Slowly return to the starting position',
      'Avoid using momentum or leaning back excessively'
    ],
    image: 'https://wger.de/media/exercise-images/10/Seated-Cable-Row.png',
  },

  // ===== SHOULDER EXERCISES =====
  {
    id: 'overhead-press',
    name: 'Overhead Press',
    muscleGroup: 'shoulders',
    secondaryMuscles: ['triceps'],
    equipment: ['barbell'],
    description: 'The primary compound movement for building shoulder strength and size.',
    instructions: [
      'Stand with feet shoulder-width apart, bar at shoulder height',
      'Grip the bar just outside shoulder-width',
      'Press the bar overhead until arms are fully extended',
      'Keep your core tight and avoid leaning back',
      'Lower the bar back to shoulder height with control',
      'Breathe out as you press up, in as you lower'
    ],
    image: 'https://wger.de/media/exercise-images/11/Overhead-Press.png',
  },
  {
    id: 'dumbbell-shoulder-press',
    name: 'Dumbbell Shoulder Press',
    muscleGroup: 'shoulders',
    secondaryMuscles: ['triceps'],
    equipment: ['dumbbells'],
    description: 'A unilateral shoulder exercise for balanced development.',
    instructions: [
      'Sit on a bench with back support, dumbbells at shoulder height',
      'Press the dumbbells overhead until arms are fully extended',
      'Keep your palms facing forward or slightly inward',
      'Lower the dumbbells back to shoulder height',
      'Avoid arching your lower back',
      'Keep your core engaged throughout'
    ],
    image: 'https://wger.de/media/exercise-images/12/Dumbbell-Shoulder-Press.png',
  },
  {
    id: 'lateral-raises',
    name: 'Dumbbell Lateral Raises',
    muscleGroup: 'shoulders',
    equipment: ['dumbbells'],
    description: 'An isolation exercise for building shoulder width and definition.',
    instructions: [
      'Stand with dumbbells at your sides, palms facing your body',
      'Raise the dumbbells out to your sides until shoulder height',
      'Keep a slight bend in your elbows throughout',
      'Lead with your elbows, not your hands',
      'Lower the dumbbells back down with control',
      'Avoid using momentum or swinging'
    ],
    image: 'https://wger.de/media/exercise-images/13/Lateral-Raises.png',
  },
  {
    id: 'front-raises',
    name: 'Dumbbell Front Raises',
    muscleGroup: 'shoulders',
    equipment: ['dumbbells'],
    description: 'Targets the front deltoids for shoulder development.',
    instructions: [
      'Stand with dumbbells in front of your thighs',
      'Raise one or both dumbbells to shoulder height',
      'Keep your arm straight with a slight bend in the elbow',
      'Lower with control back to the starting position',
      'Alternate arms or raise both together',
      'Avoid using momentum from your body'
    ],
    image: 'https://wger.de/media/exercise-images/14/Front-Raises.png',
  },
  {
    id: 'face-pulls',
    name: 'Face Pulls',
    muscleGroup: 'shoulders',
    secondaryMuscles: ['back'],
    equipment: ['cable_machine', 'resistance_bands'],
    description: 'Targets rear delts and improves shoulder health.',
    instructions: [
      'Set the cable at head height with a rope attachment',
      'Grasp the rope with both hands, step back',
      'Pull the rope toward your face, separating your hands',
      'Squeeze your rear delts at the end of the movement',
      'Slowly return to the starting position',
      'Keep your arms high throughout the movement'
    ],
    image: 'https://wger.de/media/exercise-images/15/Face-Pulls.png',
  },

  // ===== BICEPS EXERCISES =====
  {
    id: 'barbell-curl',
    name: 'Barbell Bicep Curl',
    muscleGroup: 'biceps',
    equipment: ['barbell'],
    description: 'The classic mass builder for biceps.',
    instructions: [
      'Stand with feet shoulder-width apart, bar at thigh height',
      'Grip the bar with palms facing up, hands shoulder-width',
      'Curl the bar up toward your shoulders',
      'Keep your elbows stationary at your sides',
      'Squeeze your biceps at the top',
      'Lower the bar back down with control'
    ],
    image: 'https://wger.de/media/exercise-images/16/Barbell-Curl.png',
  },
  {
    id: 'dumbbell-curl',
    name: 'Dumbbell Bicep Curl',
    muscleGroup: 'biceps',
    equipment: ['dumbbells'],
    description: 'A unilateral exercise for balanced bicep development.',
    instructions: [
      'Stand with dumbbells at your sides, palms facing your body',
      'Curl one dumbbell up, rotating your palm to face up',
      'Squeeze your bicep at the top of the movement',
      'Lower with control back to starting position',
      'Alternate arms or do both simultaneously',
      'Keep your elbows stationary throughout'
    ],
    image: 'https://wger.de/media/exercise-images/17/Dumbbell-Curl.png',
  },
  {
    id: 'hammer-curl',
    name: 'Hammer Curl',
    muscleGroup: 'biceps',
    secondaryMuscles: ['forearms'],
    equipment: ['dumbbells'],
    description: 'Targets the brachialis and forearms for arm thickness.',
    instructions: [
      'Stand with dumbbells at your sides, palms facing your body',
      'Curl the dumbbells up while keeping palms facing each other',
      'Keep your elbows stationary at your sides',
      'Squeeze at the top of the movement',
      'Lower with control back to starting position',
      'The neutral grip targets the brachialis muscle'
    ],
    image: 'https://wger.de/media/exercise-images/18/Hammer-Curl.png',
  },
  {
    id: 'preacher-curl',
    name: 'Preacher Curl',
    muscleGroup: 'biceps',
    equipment: ['barbell', 'bench'],
    description: 'An isolation exercise that eliminates momentum for strict form.',
    instructions: [
      'Sit at a preacher bench with your arms extended over the pad',
      'Grip the bar with palms facing up',
      'Curl the bar up toward your shoulders',
      'Squeeze your biceps at the top',
      'Lower the bar back down with control',
      'Keep your arms flat on the pad throughout'
    ],
    image: 'https://wger.de/media/exercise-images/19/Preacher-Curl.png',
  },
  {
    id: 'concentration-curl',
    name: 'Concentration Curl',
    muscleGroup: 'biceps',
    equipment: ['dumbbells', 'bench'],
    description: 'A strict isolation exercise for peak bicep development.',
    instructions: [
      'Sit on a bench with your legs spread',
      'Rest your elbow on the inside of your thigh',
      'Curl the dumbbell up toward your shoulder',
      'Squeeze your bicep hard at the top',
      'Lower with control back to starting position',
      'Keep your elbow planted on your thigh throughout'
    ],
    image: 'https://wger.de/media/exercise-images/20/Concentration-Curl.png',
  },

  // ===== TRICEPS EXERCISES =====
  {
    id: 'tricep-pushdown',
    name: 'Tricep Pushdown',
    muscleGroup: 'triceps',
    equipment: ['cable_machine'],
    description: 'A cable isolation exercise for tricep development.',
    instructions: [
      'Stand at a cable machine with a rope or bar attachment',
      'Grip the attachment with palms facing down or each other',
      'Keep your elbows pinned to your sides',
      'Push the attachment down until arms are fully extended',
      'Squeeze your triceps at the bottom',
      'Return to starting position with control'
    ],
    image: 'https://wger.de/media/exercise-images/21/Tricep-Pushdown.png',
  },
  {
    id: 'skull-crushers',
    name: 'Skull Crushers',
    muscleGroup: 'triceps',
    equipment: ['barbell', 'bench'],
    description: 'A classic tricep isolation exercise for mass.',
    instructions: [
      'Lie on a bench with an EZ-curl bar extended above you',
      'Bend your elbows to lower the bar toward your forehead',
      'Keep your upper arms stationary throughout',
      'Extend your arms back to the starting position',
      'Squeeze your triceps at the top',
      'Use a weight you can control safely'
    ],
    image: 'https://wger.de/media/exercise-images/22/Skull-Crushers.png',
  },
  {
    id: 'tricep-dips',
    name: 'Tricep Dips',
    muscleGroup: 'triceps',
    secondaryMuscles: ['chest', 'shoulders'],
    equipment: ['bench'],
    description: 'A bodyweight exercise that targets the triceps.',
    instructions: [
      'Position your hands on a bench behind you, fingers forward',
      'Extend your legs out in front of you',
      'Lower your body by bending your elbows',
      'Push back up to the starting position',
      'Keep your torso upright to emphasize triceps',
      'To add weight, place a plate on your lap'
    ],
    image: 'https://wger.de/media/exercise-images/23/Tricep-Dips.png',
  },
  {
    id: 'close-grip-bench-press',
    name: 'Close-Grip Bench Press',
    muscleGroup: 'triceps',
    secondaryMuscles: ['chest', 'shoulders'],
    equipment: ['barbell', 'bench'],
    description: 'A compound movement that emphasizes the triceps.',
    instructions: [
      'Lie on a bench and grip the bar about shoulder-width apart',
      'Unrack and lower the bar to your lower chest',
      'Keep your elbows tucked close to your body',
      'Press the bar back up to starting position',
      'Squeeze your triceps at the top',
      'Focus on the tricep contraction throughout'
    ],
    image: 'https://wger.de/media/exercise-images/24/Close-Grip-Bench.png',
  },
  {
    id: 'overhead-tricep-extension',
    name: 'Overhead Tricep Extension',
    muscleGroup: 'triceps',
    equipment: ['dumbbells'],
    description: 'Stretches and works the long head of the triceps.',
    instructions: [
      'Stand or sit with a dumbbell held overhead with both hands',
      'Lower the dumbbell behind your head by bending your elbows',
      'Keep your upper arms stationary throughout',
      'Extend your arms back to the starting position',
      'Squeeze your triceps at the top',
      'Keep your core engaged for stability'
    ],
    image: 'https://wger.de/media/exercise-images/25/Overhead-Tricep-Extension.png',
  },

  // ===== LEGS - QUADRICEPS =====
  {
    id: 'barbell-squat',
    name: 'Barbell Back Squat',
    muscleGroup: 'quadriceps',
    secondaryMuscles: ['glutes', 'hamstrings'],
    equipment: ['barbell'],
    description: 'The king of leg exercises for overall lower body development.',
    instructions: [
      'Set the bar on your upper back, not your neck',
      'Stand with feet shoulder-width apart, toes slightly out',
      'Take a deep breath and brace your core',
      'Squat down by bending your knees and hips',
      'Descend until your thighs are at least parallel',
      'Drive through your heels to stand back up'
    ],
    image: 'https://wger.de/media/exercise-images/26/Barbell-Squat.png',
  },
  {
    id: 'front-squat',
    name: 'Front Squat',
    muscleGroup: 'quadriceps',
    secondaryMuscles: ['glutes'],
    equipment: ['barbell'],
    description: 'A squat variation that emphasizes the quads and core.',
    instructions: [
      'Rest the bar on your front shoulders, fingertips under the bar',
      'Keep your elbows high throughout the movement',
      'Stand with feet shoulder-width apart',
      'Squat down, keeping your torso upright',
      'Drive through your heels to stand back up',
      'Keep your core tight and chest up throughout'
    ],
    image: 'https://wger.de/media/exercise-images/27/Front-Squat.png',
  },
  {
    id: 'leg-press',
    name: 'Leg Press',
    muscleGroup: 'quadriceps',
    secondaryMuscles: ['glutes', 'hamstrings'],
    equipment: ['none'],
    description: 'A machine exercise for building leg strength with less spinal load.',
    instructions: [
      'Sit in the leg press machine with your back flat',
      'Place feet shoulder-width apart on the platform',
      'Lower the platform by bending your knees',
      'Push the platform back up, extending your legs',
      'Do not lock your knees at the top',
      'Keep your lower back pressed into the seat'
    ],
    image: 'https://wger.de/media/exercise-images/28/Leg-Press.png',
  },
  {
    id: 'leg-extension',
    name: 'Leg Extension',
    muscleGroup: 'quadriceps',
    equipment: ['none'],
    description: 'An isolation exercise for quadriceps definition.',
    instructions: [
      'Sit in the leg extension machine',
      'Adjust the pad so it rests on your ankles',
      'Extend your legs until they are straight',
      'Squeeze your quads at the top',
      'Lower the weight with control',
      'Avoid swinging or using momentum'
    ],
    image: 'https://wger.de/media/exercise-images/29/Leg-Extension.png',
  },
  {
    id: 'bulgarian-split-squat',
    name: 'Bulgarian Split Squat',
    muscleGroup: 'quadriceps',
    secondaryMuscles: ['glutes'],
    equipment: ['dumbbells', 'bench'],
    description: 'A unilateral exercise for balanced leg development.',
    instructions: [
      'Stand facing away from a bench with one foot on it behind you',
      'Hold dumbbells at your sides or use bodyweight',
      'Lower into a lunge position, back knee toward the floor',
      'Keep your front knee in line with your toes',
      'Push through your front heel to stand back up',
      'Complete all reps on one side before switching'
    ],
    image: 'https://wger.de/media/exercise-images/30/Bulgarian-Split-Squat.png',
  },

  // ===== LEGS - HAMSTRINGS =====
  {
    id: 'romanian-deadlift',
    name: 'Romanian Deadlift',
    muscleGroup: 'hamstrings',
    secondaryMuscles: ['glutes', 'back'],
    equipment: ['barbell'],
    description: 'A hamstring-focused deadlift variation.',
    instructions: [
      'Stand with feet hip-width apart, bar at thigh height',
      'Hinge at the hips, pushing your glutes back',
      'Lower the bar down your legs, keeping it close',
      'Keep your back straight and knees slightly bent',
      'Feel the stretch in your hamstrings',
      'Drive your hips forward to stand back up'
    ],
    image: 'https://wger.de/media/exercise-images/31/Romanian-Deadlift.png',
  },
  {
    id: 'leg-curl',
    name: 'Lying Leg Curl',
    muscleGroup: 'hamstrings',
    equipment: ['none'],
    description: 'An isolation exercise for hamstring development.',
    instructions: [
      'Lie face down on the leg curl machine',
      'Adjust the pad so it rests above your heels',
      'Curl your legs up toward your glutes',
      'Squeeze your hamstrings at the top',
      'Lower the weight with control',
      'Avoid lifting your hips off the bench'
    ],
    image: 'https://wger.de/media/exercise-images/32/Leg-Curl.png',
  },
  {
    id: 'good-mornings',
    name: 'Good Mornings',
    muscleGroup: 'hamstrings',
    secondaryMuscles: ['glutes', 'back'],
    equipment: ['barbell'],
    description: 'A hip hinge exercise for posterior chain strength.',
    instructions: [
      'Place a barbell on your upper back',
      'Stand with feet hip-width apart',
      'Hinge at the hips, pushing your glutes back',
      'Lower your torso until nearly parallel to the floor',
      'Keep your back straight throughout',
      'Drive your hips forward to stand back up'
    ],
    image: 'https://wger.de/media/exercise-images/33/Good-Mornings.png',
  },

  // ===== LEGS - GLUTES =====
  {
    id: 'hip-thrust',
    name: 'Barbell Hip Thrust',
    muscleGroup: 'glutes',
    secondaryMuscles: ['hamstrings', 'quadriceps'],
    equipment: ['barbell', 'bench'],
    description: 'The premier exercise for glute development.',
    instructions: [
      'Sit on the floor with your upper back against a bench',
      'Roll a barbell over your hips',
      'Plant your feet flat on the floor, knees bent',
      'Drive through your heels to lift your hips',
      'Squeeze your glutes at the top',
      'Lower back down with control'
    ],
    image: 'https://wger.de/media/exercise-images/34/Hip-Thrust.png',
  },
  {
    id: 'glute-bridge',
    name: 'Glute Bridge',
    muscleGroup: 'glutes',
    secondaryMuscles: ['hamstrings'],
    equipment: ['none'],
    description: 'A bodyweight exercise for glute activation.',
    instructions: [
      'Lie on your back with knees bent and feet flat',
      'Drive through your heels to lift your hips',
      'Squeeze your glutes at the top',
      'Keep your core engaged throughout',
      'Lower back down with control',
      'Can be done single-leg for progression'
    ],
    image: 'https://wger.de/media/exercise-images/35/Glute-Bridge.png',
  },
  {
    id: 'cable-kickback',
    name: 'Cable Glute Kickback',
    muscleGroup: 'glutes',
    equipment: ['cable_machine'],
    description: 'An isolation exercise for glute development.',
    instructions: [
      'Attach an ankle strap to a low cable pulley',
      'Stand facing the machine, holding for balance',
      'Kick your leg back, squeezing your glute',
      'Keep your leg straight or slightly bent',
      'Return to starting position with control',
      'Complete all reps before switching legs'
    ],
    image: 'https://wger.de/media/exercise-images/36/Cable-Kickback.png',
  },

  // ===== LEGS - CALVES =====
  {
    id: 'standing-calf-raise',
    name: 'Standing Calf Raise',
    muscleGroup: 'calves',
    equipment: ['none'],
    description: 'A calf exercise for gastrocnemius development.',
    instructions: [
      'Stand on the edge of a step or platform',
      'Let your heels drop below your toes',
      'Push up onto your toes as high as possible',
      'Squeeze your calves at the top',
      'Lower back down with control',
      'Can hold dumbbells for added resistance'
    ],
    image: 'https://wger.de/media/exercise-images/37/Standing-Calf-Raise.png',
  },
  {
    id: 'seated-calf-raise',
    name: 'Seated Calf Raise',
    muscleGroup: 'calves',
    equipment: ['none'],
    description: 'Targets the soleus muscle for calf development.',
    instructions: [
      'Sit on a calf raise machine or bench',
      'Place the weight on your knees',
      'Push up onto your toes as high as possible',
      'Squeeze your calves at the top',
      'Lower back down with control',
      'The bent knee position targets the soleus'
    ],
    image: 'https://wger.de/media/exercise-images/38/Seated-Calf-Raise.png',
  },

  // ===== ABS =====
  {
    id: 'plank',
    name: 'Plank',
    muscleGroup: 'abs',
    equipment: ['none'],
    description: 'A core stability exercise for overall abdominal strength.',
    instructions: [
      'Get into a push-up position on your forearms',
      'Keep your body in a straight line from head to heels',
      'Engage your core by pulling your navel toward your spine',
      'Hold this position for the desired time',
      'Keep your glutes squeezed and avoid sagging hips',
      'Breathe normally throughout the hold'
    ],
    image: 'https://wger.de/media/exercise-images/39/Plank.png',
  },
  {
    id: 'crunches',
    name: 'Crunches',
    muscleGroup: 'abs',
    equipment: ['none'],
    description: 'A classic abdominal exercise for the upper abs.',
    instructions: [
      'Lie on your back with knees bent and feet flat',
      'Place your hands behind your head or crossed on your chest',
      'Lift your shoulders off the ground by contracting your abs',
      'Squeeze at the top of the movement',
      'Lower back down with control',
      'Avoid pulling on your neck with your hands'
    ],
    image: 'https://wger.de/media/exercise-images/40/Crunches.png',
  },
  {
    id: 'leg-raises',
    name: 'Hanging Leg Raises',
    muscleGroup: 'abs',
    equipment: ['pull_up_bar'],
    description: 'An advanced exercise for lower abdominal development.',
    instructions: [
      'Hang from a pull-up bar with arms extended',
      'Keep your legs straight throughout the movement',
      'Raise your legs up until they are parallel to the floor',
      'Lower your legs back down with control',
      'Avoid swinging your body',
      'Bend knees for an easier variation'
    ],
    image: 'https://wger.de/media/exercise-images/41/Leg-Raises.png',
  },
  {
    id: 'russian-twist',
    name: 'Russian Twist',
    muscleGroup: 'abs',
    secondaryMuscles: ['obliques'],
    equipment: ['none'],
    description: 'A rotational exercise for the obliques.',
    instructions: [
      'Sit on the floor with knees bent and feet elevated',
      'Lean back slightly to engage your core',
      'Hold your hands together in front of you',
      'Rotate your torso to touch the floor on each side',
      'Keep your core engaged throughout',
      'Can hold a weight for added resistance'
    ],
    image: 'https://wger.de/media/exercise-images/42/Russian-Twist.png',
  },
  {
    id: 'mountain-climbers',
    name: 'Mountain Climbers',
    muscleGroup: 'abs',
    secondaryMuscles: ['cardio'],
    equipment: ['none'],
    description: 'A dynamic exercise combining core work and cardio.',
    instructions: [
      'Start in a high plank position',
      'Drive one knee toward your chest',
      'Quickly switch legs in a running motion',
      'Keep your core tight and hips low',
      'Maintain a steady rhythm',
      'Move as fast as possible with good form'
    ],
    image: 'https://wger.de/media/exercise-images/43/Mountain-Climbers.png',
  },

  // ===== CARDIO =====
  {
    id: 'running',
    name: 'Running',
    muscleGroup: 'cardio',
    equipment: ['none'],
    description: 'A fundamental cardiovascular exercise.',
    instructions: [
      'Start with a light warm-up walk or jog',
      'Maintain an upright posture with relaxed shoulders',
      'Land on your midfoot, not your heels',
      'Swing your arms naturally at your sides',
      'Breathe rhythmically, matching your stride',
      'Cool down with a slow walk after'
    ],
    image: 'https://wger.de/media/exercise-images/44/Running.png',
  },
  {
    id: 'jumping-jacks',
    name: 'Jumping Jacks',
    muscleGroup: 'cardio',
    equipment: ['none'],
    description: 'A classic cardio exercise for warming up.',
    instructions: [
      'Stand with feet together and arms at your sides',
      'Jump while spreading your legs and raising your arms',
      'Land with feet wider than shoulder-width',
      'Jump back to the starting position',
      'Maintain a steady rhythm',
      'Keep your core engaged throughout'
    ],
    image: 'https://wger.de/media/exercise-images/45/Jumping-Jacks.png',
  },
  {
    id: 'burpees',
    name: 'Burpees',
    muscleGroup: 'cardio',
    secondaryMuscles: ['chest', 'legs'],
    equipment: ['none'],
    description: 'A full-body conditioning exercise.',
    instructions: [
      'Start standing with feet shoulder-width apart',
      'Drop into a squat and place your hands on the floor',
      'Jump your feet back into a plank position',
      'Perform a push-up',
      'Jump your feet forward to your hands',
      'Explosively jump up with arms overhead'
    ],
    image: 'https://wger.de/media/exercise-images/46/Burpees.png',
  },
  {
    id: 'jump-rope',
    name: 'Jump Rope',
    muscleGroup: 'cardio',
    equipment: ['none'],
    description: 'A cardio exercise that also improves coordination.',
    instructions: [
      'Hold the rope handles at hip height',
      'Swing the rope overhead and jump over it',
      'Stay on the balls of your feet',
      'Keep jumps small and controlled',
      'Rotate from your wrists, not your shoulders',
      'Maintain a steady rhythm'
    ],
    image: 'https://wger.de/media/exercise-images/47/Jump-Rope.png',
  },
  {
    id: 'high-knees',
    name: 'High Knees',
    muscleGroup: 'cardio',
    equipment: ['none'],
    description: 'A high-intensity cardio exercise.',
    instructions: [
      'Stand with feet hip-width apart',
      'Run in place, lifting knees to hip height',
      'Pump your arms quickly for momentum',
      'Stay on the balls of your feet',
      'Keep your core engaged',
      'Move as fast as possible with control'
    ],
    image: 'https://wger.de/media/exercise-images/48/High-Knees.png',
  },

  // ===== BODYWEIGHT / NO EQUIPMENT =====
  {
    id: 'lunges',
    name: 'Lunges',
    muscleGroup: 'quadriceps',
    secondaryMuscles: ['glutes', 'hamstrings'],
    equipment: ['none'],
    description: 'A unilateral leg exercise for strength and balance.',
    instructions: [
      'Stand with feet hip-width apart',
      'Step forward with one leg',
      'Lower until both knees are at 90 degrees',
      'Push through your front heel to return',
      'Alternate legs or complete all on one side',
      'Keep your torso upright throughout'
    ],
    image: 'https://wger.de/media/exercise-images/49/Lunges.png',
  },
  {
    id: 'wall-sit',
    name: 'Wall Sit',
    muscleGroup: 'quadriceps',
    equipment: ['none'],
    description: 'An isometric exercise for quad endurance.',
    instructions: [
      'Stand with your back against a wall',
      'Walk your feet out and slide down the wall',
      'Bend your knees to 90 degrees',
      'Hold this position for the desired time',
      'Keep your back flat against the wall',
      'Breathe normally throughout'
    ],
    image: 'https://wger.de/media/exercise-images/50/Wall-Sit.png',
  },
  {
    id: 'pistol-squat',
    name: 'Pistol Squat',
    muscleGroup: 'quadriceps',
    secondaryMuscles: ['glutes'],
    equipment: ['none'],
    description: 'An advanced single-leg squat variation.',
    instructions: [
      'Stand on one leg with the other extended in front',
      'Lower into a squat on your standing leg',
      'Keep your extended leg off the ground',
      'Go as deep as possible while maintaining balance',
      'Push back up to the starting position',
      'Hold onto something for balance if needed'
    ],
    image: 'https://wger.de/media/exercise-images/51/Pistol-Squat.png',
  },
];

// Helper function to get exercises by muscle group
export function getExercisesByMuscle(muscle: string): Exercise[] {
  return COMPREHENSIVE_EXERCISES.filter(e => e.muscleGroup === muscle);
}

// Helper function to get exercises by equipment
export function getExercisesByEquipment(equipment: string): Exercise[] {
  return COMPREHENSIVE_EXERCISES.filter(e => e.equipment.includes(equipment as never));
}

// Helper function to search exercises
export function searchExercises(query: string): Exercise[] {
  const lowerQuery = query.toLowerCase();
  return COMPREHENSIVE_EXERCISES.filter(e => 
    e.name.toLowerCase().includes(lowerQuery) ||
    e.muscleGroup.toLowerCase().includes(lowerQuery) ||
    e.description.toLowerCase().includes(lowerQuery)
  );
}

// Workout templates
export const WORKOUT_TEMPLATES = {
  push: {
    name: 'Push Day',
    exercises: ['bench-press', 'overhead-press', 'incline-bench-press', 'tricep-pushdown', 'lateral-raises', 'close-grip-bench-press'],
    duration: 60,
    intensity: 'high' as const,
  },
  pull: {
    name: 'Pull Day',
    exercises: ['pull-ups', 'barbell-row', 'lat-pulldown', 'barbell-curl', 'seated-cable-row', 'hammer-curl'],
    duration: 60,
    intensity: 'high' as const,
  },
  legs: {
    name: 'Leg Day',
    exercises: ['barbell-squat', 'romanian-deadlift', 'leg-press', 'leg-curl', 'leg-extension', 'standing-calf-raise'],
    duration: 60,
    intensity: 'high' as const,
  },
  full_body: {
    name: 'Full Body',
    exercises: ['barbell-squat', 'bench-press', 'barbell-row', 'overhead-press', 'barbell-curl', 'tricep-pushdown'],
    duration: 75,
    intensity: 'high' as const,
  },
  cardio: {
    name: 'Cardio Session',
    exercises: ['burpees', 'mountain-climbers', 'jumping-jacks', 'high-knees', 'running'],
    duration: 30,
    intensity: 'medium' as const,
  },
  bodyweight: {
    name: 'Bodyweight Workout',
    exercises: ['push-ups', 'pull-ups', 'lunges', 'plank', 'mountain-climbers', 'burpees'],
    duration: 45,
    intensity: 'medium' as const,
  },
};
