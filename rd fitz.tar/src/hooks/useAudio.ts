import { useCallback, useRef, useEffect } from 'react';
import { useAppStore } from '@/store/useAppStore';

type SoundType = 'achievement' | 'notification' | 'success' | 'streak' | 'click' | 'error';

// Audio context singleton
let audioContext: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
  }
  return audioContext;
}

// Generate different tones programmatically
function playTone(
  ctx: AudioContext,
  frequency: number,
  duration: number,
  type: OscillatorType = 'sine',
  volume: number = 0.3
): Promise<void> {
  return new Promise((resolve) => {
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();
    
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, ctx.currentTime);
    
    gainNode.gain.setValueAtTime(volume, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);
    
    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + duration);
    
    setTimeout(resolve, duration * 1000);
  });
}

async function playAchievementSound(ctx: AudioContext): Promise<void> {
  // Triumphant ascending arpeggio
  const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
  for (const note of notes) {
    await playTone(ctx, note, 0.15, 'sine', 0.25);
  }
}

async function playNotificationSound(ctx: AudioContext): Promise<void> {
  // Gentle two-tone alert
  await playTone(ctx, 880, 0.1, 'sine', 0.2);
  await new Promise(r => setTimeout(r, 50));
  await playTone(ctx, 1100, 0.15, 'sine', 0.2);
}

async function playSuccessSound(ctx: AudioContext): Promise<void> {
  // Pleasant success melody
  await playTone(ctx, 440, 0.1, 'sine', 0.25);
  await playTone(ctx, 554.37, 0.1, 'sine', 0.25);
  await playTone(ctx, 659.25, 0.2, 'sine', 0.25);
}

async function playStreakSound(ctx: AudioContext): Promise<void> {
  // Encouraging chime
  await playTone(ctx, 587.33, 0.1, 'sine', 0.2);
  await playTone(ctx, 783.99, 0.1, 'sine', 0.2);
  await playTone(ctx, 880, 0.15, 'sine', 0.25);
}

async function playClickSound(ctx: AudioContext): Promise<void> {
  // Quick click
  await playTone(ctx, 1200, 0.03, 'square', 0.1);
}

async function playErrorSound(ctx: AudioContext): Promise<void> {
  // Error buzz
  await playTone(ctx, 200, 0.15, 'sawtooth', 0.15);
  await new Promise(r => setTimeout(r, 50));
  await playTone(ctx, 150, 0.2, 'sawtooth', 0.15);
}

export function useAudio() {
  const { settings } = useAppStore();
  const contextRef = useRef<AudioContext | null>(null);
  
  useEffect(() => {
    // Initialize audio context on first user interaction
    const initContext = () => {
      if (!contextRef.current) {
        contextRef.current = getAudioContext();
      }
      document.removeEventListener('click', initContext);
      document.removeEventListener('touchstart', initContext);
    };
    
    document.addEventListener('click', initContext);
    document.addEventListener('touchstart', initContext);
    
    return () => {
      document.removeEventListener('click', initContext);
      document.removeEventListener('touchstart', initContext);
    };
  }, []);
  
  const playSound = useCallback(async (type: SoundType) => {
    if (!settings.audioFeedback) return;
    
    try {
      const ctx = contextRef.current || getAudioContext();
      
      // Resume context if suspended (iOS requirement)
      if (ctx.state === 'suspended') {
        await ctx.resume();
      }
      
      switch (type) {
        case 'achievement':
          await playAchievementSound(ctx);
          break;
        case 'notification':
          await playNotificationSound(ctx);
          break;
        case 'success':
          await playSuccessSound(ctx);
          break;
        case 'streak':
          await playStreakSound(ctx);
          break;
        case 'click':
          await playClickSound(ctx);
          break;
        case 'error':
          await playErrorSound(ctx);
          break;
      }
    } catch (error) {
      console.error('Audio playback error:', error);
    }
  }, [settings.audioFeedback]);
  
  return { playSound };
}
