import { useCallback } from 'react';
import { useAppStore } from '@/store/useAppStore';

export function useHaptic() {
  const { settings } = useAppStore();
  
  const vibrate = useCallback((pattern: number | number[]) => {
    if (!settings.hapticFeedback) return;
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(pattern);
    }
  }, [settings.hapticFeedback]);
  
  const light = useCallback(() => {
    vibrate(10);
  }, [vibrate]);
  
  const medium = useCallback(() => {
    vibrate(25);
  }, [vibrate]);
  
  const heavy = useCallback(() => {
    vibrate(50);
  }, [vibrate]);
  
  const achievement = useCallback(() => {
    vibrate([100, 50, 100]);
  }, [vibrate]);
  
  const success = useCallback(() => {
    vibrate([50, 30, 50, 30, 50]);
  }, [vibrate]);
  
  const error = useCallback(() => {
    vibrate([30, 20, 30]);
  }, [vibrate]);
  
  const celebration = useCallback(() => {
    vibrate([50, 50, 50, 50, 100, 50, 100]);
  }, [vibrate]);
  
  return {
    vibrate,
    light,
    medium,
    heavy,
    achievement,
    success,
    error,
    celebration,
  };
}
