import { useCallback, useEffect, useState, useSyncExternalStore } from 'react';
import { useAppStore } from '@/store/useAppStore';

export interface NotificationPermissionState {
  granted: boolean;
  denied: boolean;
  default: boolean;
}

// Get initial permission state
function getPermissionState(): NotificationPermissionState {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return { granted: false, denied: false, default: true };
  }
  const permission = Notification.permission;
  return {
    granted: permission === 'granted',
    denied: permission === 'denied',
    default: permission === 'default',
  };
}

export function useNotifications() {
  const { settings, reminders } = useAppStore();
  const [permissionState, setPermissionState] = useState<NotificationPermissionState>(getPermissionState);
  
  const requestPermission = useCallback(async (): Promise<boolean> => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return false;
    }
    
    try {
      const permission = await Notification.requestPermission();
      const granted = permission === 'granted';
      setPermissionState({
        granted,
        denied: permission === 'denied',
        default: permission === 'default',
      });
      return granted;
    } catch {
      return false;
    }
  }, []);
  
  const showNotification = useCallback(
    (title: string, options?: NotificationOptions) => {
      if (!settings.notifications || !permissionState.granted) {
        return null;
      }
      
      try {
        const notification = new Notification(title, {
          icon: '/icons/icon-192x192.png',
          badge: '/icons/badge-72x72.png',
          vibrate: [100, 50, 100],
          requireInteraction: false,
          silent: false,
          ...options,
        });
        
        notification.onclick = () => {
          window.focus();
          notification.close();
        };
        
        return notification;
      } catch (error) {
        console.error('Failed to show notification:', error);
        return null;
      }
    },
    [settings.notifications, permissionState.granted]
  );
  
  const scheduleReminder = useCallback(
    (reminder: { id: string; title: string; message: string; time: string }) => {
      // For a PWA without a service worker push, we can use a simple approach
      // that shows notifications when the app is open
      const [hours, minutes] = reminder.time.split(':').map(Number);
      const now = new Date();
      const scheduledTime = new Date();
      scheduledTime.setHours(hours, minutes, 0, 0);
      
      if (scheduledTime <= now) {
        scheduledTime.setDate(scheduledTime.getDate() + 1);
      }
      
      const delay = scheduledTime.getTime() - now.getTime();
      
      const timeoutId = setTimeout(() => {
        showNotification(reminder.title, {
          body: reminder.message,
          tag: reminder.id,
        });
      }, delay);
      
      return timeoutId;
    },
    [showNotification]
  );
  
  // Set up scheduled reminders
  useEffect(() => {
    if (!permissionState.granted || !settings.notifications) return;
    
    const timeoutIds: NodeJS.Timeout[] = [];
    
    reminders.filter(r => r.enabled).forEach(reminder => {
      const timeoutId = scheduleReminder(reminder);
      timeoutIds.push(timeoutId);
    });
    
    return () => {
      timeoutIds.forEach(clearTimeout);
    };
  }, [reminders, permissionState.granted, settings.notifications, scheduleReminder]);
  
  return {
    permissionState,
    requestPermission,
    showNotification,
    scheduleReminder,
  };
}
