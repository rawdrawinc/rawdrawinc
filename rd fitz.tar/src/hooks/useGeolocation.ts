import { useState, useCallback, useRef, useEffect } from 'react';
import type { Coordinate, TrackingSession } from '@/types';

interface GeolocationState {
  isLoading: boolean;
  error: string | null;
  currentPosition: Coordinate | null;
  isTracking: boolean;
}

interface GeolocationOptions {
  enableHighAccuracy?: boolean;
  timeout?: number;
  maximumAge?: number;
}

const DEFAULT_OPTIONS: GeolocationOptions = {
  enableHighAccuracy: true,
  timeout: 10000,
  maximumAge: 0,
};

export function useGeolocation() {
  const [state, setState] = useState<GeolocationState>({
    isLoading: false,
    error: null,
    currentPosition: null,
    isTracking: false,
  });
  
  const watchIdRef = useRef<number | null>(null);
  const sessionRef = useRef<TrackingSession | null>(null);
  
  const getCurrentPosition = useCallback(
    (options: GeolocationOptions = DEFAULT_OPTIONS): Promise<Coordinate | null> => {
      return new Promise((resolve) => {
        if (!navigator.geolocation) {
          setState(prev => ({ ...prev, error: 'Geolocation not supported' }));
          resolve(null);
          return;
        }
        
        setState(prev => ({ ...prev, isLoading: true, error: null }));
        
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const coord: Coordinate = {
              lat: position.coords.latitude,
              lng: position.coords.longitude,
              timestamp: position.timestamp,
              altitude: position.coords.altitude ?? undefined,
              speed: position.coords.speed ?? undefined,
            };
            setState(prev => ({ ...prev, isLoading: false, currentPosition: coord }));
            resolve(coord);
          },
          (error) => {
            let errorMessage = 'Unknown error';
            switch (error.code) {
              case error.PERMISSION_DENIED:
                errorMessage = 'Location permission denied';
                break;
              case error.POSITION_UNAVAILABLE:
                errorMessage = 'Position unavailable';
                break;
              case error.TIMEOUT:
                errorMessage = 'Location request timed out';
                break;
            }
            setState(prev => ({ ...prev, isLoading: false, error: errorMessage }));
            resolve(null);
          },
          options
        );
      });
    },
    []
  );
  
  const startTracking = useCallback(
    (type: TrackingSession['type'] = 'run'): Promise<void> => {
      return new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
          setState(prev => ({ ...prev, error: 'Geolocation not supported' }));
          reject(new Error('Geolocation not supported'));
          return;
        }
        
        if (watchIdRef.current !== null) {
          resolve();
          return;
        }
        
        setState(prev => ({ ...prev, isLoading: true, error: null }));
        
        sessionRef.current = {
          id: `session-${Date.now()}`,
          startTime: Date.now(),
          coordinates: [],
          isActive: true,
          type,
        };
        
        watchIdRef.current = navigator.geolocation.watchPosition(
          (position) => {
            const coord: Coordinate = {
              lat: position.coords.latitude,
              lng: position.coords.longitude,
              timestamp: position.timestamp,
              altitude: position.coords.altitude ?? undefined,
              speed: position.coords.speed ?? undefined,
            };
            
            if (sessionRef.current) {
              sessionRef.current.coordinates.push(coord);
            }
            
            setState(prev => ({
              ...prev,
              isLoading: false,
              isTracking: true,
              currentPosition: coord,
            }));
            
            resolve();
          },
          (error) => {
            let errorMessage = 'Unknown error';
            switch (error.code) {
              case error.PERMISSION_DENIED:
                errorMessage = 'Location permission denied';
                break;
              case error.POSITION_UNAVAILABLE:
                errorMessage = 'Position unavailable';
                break;
              case error.TIMEOUT:
                errorMessage = 'Location request timed out';
                break;
            }
            setState(prev => ({ ...prev, isLoading: false, error: errorMessage, isTracking: false }));
            reject(new Error(errorMessage));
          },
          {
            enableHighAccuracy: true,
            timeout: 30000,
            maximumAge: 0,
          }
        );
      });
    },
    []
  );
  
  const stopTracking = useCallback((): TrackingSession | null => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    
    setState(prev => ({ ...prev, isTracking: false }));
    
    if (sessionRef.current) {
      sessionRef.current.isActive = false;
      const session = { ...sessionRef.current };
      sessionRef.current = null;
      return session;
    }
    
    return null;
  }, []);
  
  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);
  
  const calculateDistance = useCallback((coords: Coordinate[]): number => {
    if (coords.length < 2) return 0;
    
    let totalDistance = 0;
    
    for (let i = 1; i < coords.length; i++) {
      const prev = coords[i - 1];
      const curr = coords[i];
      
      // Haversine formula
      const R = 6371000; // Earth radius in meters
      const lat1 = (prev.lat * Math.PI) / 180;
      const lat2 = (curr.lat * Math.PI) / 180;
      const deltaLat = ((curr.lat - prev.lat) * Math.PI) / 180;
      const deltaLng = ((curr.lng - prev.lng) * Math.PI) / 180;
      
      const a =
        Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
        Math.cos(lat1) * Math.cos(lat2) * Math.sin(deltaLng / 2) * Math.sin(deltaLng / 2);
      
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      
      totalDistance += R * c;
    }
    
    return totalDistance;
  }, []);
  
  const calculatePace = useCallback((distance: number, durationMs: number): number => {
    if (distance === 0 || durationMs === 0) return 0;
    const durationSec = durationMs / 1000;
    const distanceKm = distance / 1000;
    return durationSec / distanceKm; // seconds per km
  }, []);
  
  return {
    ...state,
    getCurrentPosition,
    startTracking,
    stopTracking,
    calculateDistance,
    calculatePace,
    session: sessionRef.current,
  };
}
