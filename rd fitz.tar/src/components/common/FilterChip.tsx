'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';

interface FilterChipProps {
  label: string;
  selected?: boolean;
  onClick?: () => void;
  icon?: React.ReactNode;
  className?: string;
}

export function FilterChip({
  label,
  selected = false,
  onClick,
  icon,
  className,
}: FilterChipProps) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200',
        'touch-target min-h-[36px] border',
        selected
          ? 'bg-primary text-primary-foreground border-primary'
          : 'bg-background text-foreground border-border hover:border-primary'
      , className)}
    >
      {icon && <span className="w-4 h-4">{icon}</span>}
      {label}
    </button>
  );
}

interface FilterChipGroupProps {
  options: { value: string; label: string; icon?: React.ReactNode }[];
  value: string[];
  onChange: (value: string[]) => void;
  multiSelect?: boolean;
  className?: string;
}

export function FilterChipGroup({
  options,
  value,
  onChange,
  multiSelect = true,
  className,
}: FilterChipGroupProps) {
  const handleClick = (optionValue: string) => {
    if (multiSelect) {
      if (value.includes(optionValue)) {
        onChange(value.filter(v => v !== optionValue));
      } else {
        onChange([...value, optionValue]);
      }
    } else {
      onChange([optionValue]);
    }
  };

  return (
    <div className={cn('flex flex-wrap gap-2', className)}>
      {options.map((option) => (
        <FilterChip
          key={option.value}
          label={option.label}
          selected={value.includes(option.value)}
          onClick={() => handleClick(option.value)}
          icon={option.icon}
        />
      ))}
    </div>
  );
}
