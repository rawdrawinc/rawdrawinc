'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';
import { useHaptic } from '@/hooks/useHaptic';
import { useAudio } from '@/hooks/useAudio';

interface HapticButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  hapticStyle?: 'light' | 'medium' | 'heavy';
  soundType?: 'click' | 'success' | 'error' | 'achievement' | 'none';
  children: React.ReactNode;
}

export function HapticButton({
  variant = 'primary',
  size = 'md',
  hapticStyle = 'light',
  soundType = 'click',
  children,
  className,
  onClick,
  disabled,
  ...props
}: HapticButtonProps) {
  const { light, medium, heavy } = useHaptic();
  const { playSound } = useAudio();
  
  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (disabled) return;
    
    // Trigger haptic feedback
    switch (hapticStyle) {
      case 'light':
        light();
        break;
      case 'medium':
        medium();
        break;
      case 'heavy':
        heavy();
        break;
    }
    
    // Play sound
    if (soundType !== 'none') {
      playSound(soundType);
    }
    
    onClick?.(e);
  };
  
  const baseStyles = 'inline-flex items-center justify-center font-medium transition-all duration-200 active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none touch-target';
  
  const variantStyles = {
    primary: 'bg-primary text-primary-foreground hover:bg-primary/90 active:bg-primary/80',
    secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/80 active:bg-secondary/70',
    ghost: 'bg-transparent text-foreground hover:bg-secondary active:bg-secondary/70',
    danger: 'bg-destructive text-destructive-foreground hover:bg-destructive/90 active:bg-destructive/80',
  };
  
  const sizeStyles = {
    sm: 'text-sm px-3 py-2 rounded-md min-h-[36px]',
    md: 'text-sm px-4 py-3 rounded-lg min-h-[44px]',
    lg: 'text-base px-6 py-4 rounded-lg min-h-[52px]',
  };
  
  return (
    <button
      onClick={handleClick}
      disabled={disabled}
      className={cn(
        baseStyles,
        variantStyles[variant],
        sizeStyles[size],
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}
