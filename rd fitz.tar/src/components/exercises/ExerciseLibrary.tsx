'use client';

import * as React from 'react';
import { useState, useMemo } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { HapticButton } from '@/components/common/HapticButton';
import { FilterChip } from '@/components/common/FilterChip';
import { cn } from '@/lib/utils';
import { getExerciseSVG } from '@/components/exercises/ExerciseSVGs';
import type { Exercise, MuscleGroup } from '@/types';
import { COMPREHENSIVE_EXERCISES } from '@/data/exercises';
import { Search, X, ChevronRight, Dumbbell, Filter, Play, Clock, Target, Zap, Plus } from 'lucide-react';

const MUSCLE_GROUPS: { value: MuscleGroup; label: string }[] = [
  { value: 'chest', label: 'Chest' },
  { value: 'back', label: 'Back' },
  { value: 'shoulders', label: 'Shoulders' },
  { value: 'biceps', label: 'Biceps' },
  { value: 'triceps', label: 'Triceps' },
  { value: 'abs', label: 'Abs' },
  { value: 'quadriceps', label: 'Quads' },
  { value: 'hamstrings', label: 'Hamstrings' },
  { value: 'glutes', label: 'Glutes' },
  { value: 'calves', label: 'Calves' },
  { value: 'cardio', label: 'Cardio' },
];

export function ExerciseLibrary() {
  const { exercises, setExercises } = useAppStore();
  const [search, setSearch] = useState('');
  const [selectedMuscle, setSelectedMuscle] = useState<MuscleGroup | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);
  
  // Use local comprehensive database (always available)
  const displayExercises = useMemo(() => {
    return COMPREHENSIVE_EXERCISES;
  }, []);
  
  // Filter exercises
  const filteredExercises = useMemo(() => {
    return displayExercises.filter(ex => {
      const matchesSearch = search === '' || 
        ex.name.toLowerCase().includes(search.toLowerCase()) ||
        ex.muscleGroup.toLowerCase().includes(search.toLowerCase()) ||
        ex.description.toLowerCase().includes(search.toLowerCase());
      
      const matchesMuscle = !selectedMuscle || ex.muscleGroup === selectedMuscle;
      
      return matchesSearch && matchesMuscle;
    });
  }, [displayExercises, search, selectedMuscle]);
  
  // Group by muscle group
  const groupedExercises = useMemo(() => {
    return filteredExercises.reduce((acc, ex) => {
      const group = ex.muscleGroup;
      if (!acc[group]) acc[group] = [];
      acc[group].push(ex);
      return acc;
    }, {} as Record<string, Exercise[]>);
  }, [filteredExercises]);
  
  return (
    <div className="flex flex-col h-full">
      {/* Search bar */}
      <div className="px-4 py-3 border-b border-border">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search exercises..."
            className="w-full pl-10 pr-10 py-3 bg-secondary rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-3 top-1/2 -translate-y-1/2"
            >
              <X className="w-5 h-5 text-muted-foreground" />
            </button>
          )}
        </div>
      </div>
      
      {/* Quick stats */}
      <div className="px-4 py-2 bg-primary/5 border-b border-border">
        <p className="text-sm text-muted-foreground">
          <span className="font-semibold text-foreground">{filteredExercises.length}</span> exercises available
          {selectedMuscle && (
            <span> in <span className="font-medium text-primary capitalize">{selectedMuscle}</span></span>
          )}
        </p>
      </div>
      
      {/* Muscle group filters */}
      <div className="px-4 py-3">
        <div className="flex items-center justify-between mb-2">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2 text-sm font-medium text-muted-foreground"
          >
            <Filter className="w-4 h-4" />
            Filter by muscle group
          </button>
          {selectedMuscle && (
            <button
              onClick={() => setSelectedMuscle(null)}
              className="text-sm text-primary font-medium"
            >
              Clear filter
            </button>
          )}
        </div>
        {showFilters && (
          <div className="flex flex-wrap gap-2 mt-2">
            {MUSCLE_GROUPS.map(({ value, label }) => (
              <FilterChip
                key={value}
                label={label}
                selected={selectedMuscle === value}
                onClick={() => setSelectedMuscle(selectedMuscle === value ? null : value)}
              />
            ))}
          </div>
        )}
      </div>
      
      {/* Exercise list */}
      <div className="flex-1 overflow-y-auto custom-scrollbar px-4 pb-4">
        {Object.keys(groupedExercises).length === 0 ? (
          <div className="text-center py-12">
            <Dumbbell className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
            <p className="text-muted-foreground mb-2">No exercises found</p>
            <p className="text-small text-muted-foreground">Try a different search term</p>
          </div>
        ) : (
          Object.entries(groupedExercises).map(([muscle, exs]) => (
            <div key={muscle} className="mb-6">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3 capitalize flex items-center gap-2">
                <MuscleIcon muscle={muscle} />
                {muscle}
                <span className="text-xs font-normal">({exs.length})</span>
              </h3>
              <div className="space-y-2">
                {exs.map((exercise) => (
                  <ExerciseCard 
                    key={exercise.id} 
                    exercise={exercise} 
                    onClick={() => setSelectedExercise(exercise)}
                  />
                ))}
              </div>
            </div>
          ))
        )}
      </div>
      
      {/* Exercise Detail Modal */}
      {selectedExercise && (
        <ExerciseDetailModal 
          exercise={selectedExercise} 
          onClose={() => setSelectedExercise(null)} 
        />
      )}
    </div>
  );
}

// Muscle group icon helper
function MuscleIcon({ muscle }: { muscle: string }) {
  const iconClass = "w-4 h-4";
  switch (muscle) {
    case 'chest': return <Target className={iconClass} />;
    case 'cardio': return <Zap className={iconClass} />;
    default: return <Dumbbell className={iconClass} />;
  }
}

interface ExerciseCardProps {
  exercise: Exercise;
  onClick?: () => void;
}

export function ExerciseCard({ exercise, onClick }: ExerciseCardProps) {
  // Use embedded SVG instead of external URL
  const exerciseSVG = getExerciseSVG(exercise.id);
  
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-3 p-3 bg-card border border-border rounded-xl hover:border-primary/50 active:scale-[0.98] transition-all text-left"
    >
      <div className="w-14 h-14 flex items-center justify-center bg-secondary rounded-lg overflow-hidden flex-shrink-0">
        {exerciseSVG}
      </div>
      <div className="flex-1 min-w-0">
        <h4 className="font-medium text-foreground truncate">{exercise.name}</h4>
        <p className="text-small text-muted-foreground capitalize">
          {exercise.muscleGroup}
          {exercise.equipment && exercise.equipment.length > 0 && (
            <span className="text-muted-foreground/60">
              {' '}| {exercise.equipment[0].replace('_', ' ')}
            </span>
          )}
        </p>
        <p className="text-xs text-muted-foreground/80 truncate mt-0.5">
          {exercise.description.substring(0, 50)}...
        </p>
      </div>
      <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0" />
    </button>
  );
}

interface ExerciseDetailModalProps {
  exercise: Exercise;
  onClose: () => void;
  onAdd?: () => void;
}

function ExerciseDetailModal({ exercise, onClose, onAdd }: ExerciseDetailModalProps) {
  // Use embedded SVG instead of external URL
  const exerciseSVG = getExerciseSVG(exercise.id);
  
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end animate-fade-in">
      <div 
        className="bg-background w-full max-h-[90vh] rounded-t-3xl animate-slide-up overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-2">
          <div className="w-12 h-1.5 bg-border rounded-full" />
        </div>
        
        {/* Header */}
        <div className="flex items-center justify-between px-4 pb-3 border-b border-border">
          <button onClick={onClose} className="p-2 -ml-2 text-muted-foreground">
            <X className="w-6 h-6" />
          </button>
          <h2 className="font-semibold text-lg">Exercise Details</h2>
          <div className="w-10" />
        </div>
        
        {/* Content */}
        <div className="overflow-y-auto max-h-[calc(90vh-100px)]">
          {/* SVG Illustration */}
          <div className="aspect-square bg-secondary mx-4 mt-4 rounded-xl overflow-hidden flex items-center justify-center p-8">
            {exerciseSVG}
          </div>
          
          <div className="p-4">
            {/* Title and tags */}
            <h1 className="text-2xl font-bold mb-3">{exercise.name}</h1>
            
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="px-3 py-1.5 bg-primary/10 text-primary rounded-full text-sm font-medium capitalize">
                {exercise.muscleGroup}
              </span>
              {exercise.secondaryMuscles?.map((muscle) => (
                <span 
                  key={muscle} 
                  className="px-3 py-1.5 bg-secondary text-secondary-foreground rounded-full text-sm capitalize"
                >
                  {muscle}
                </span>
              ))}
            </div>
            
            {/* Equipment */}
            {exercise.equipment && exercise.equipment.length > 0 && (
              <div className="mb-4 p-3 bg-secondary/50 rounded-lg">
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Equipment</p>
                <p className="text-sm font-medium capitalize">
                  {exercise.equipment.map(e => e.replace('_', ' ')).join(', ')}
                </p>
              </div>
            )}
            
            {/* Description */}
            <div className="mb-6">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-2">About</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {exercise.description}
              </p>
            </div>
            
            {/* Instructions */}
            <div className="mb-6">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-3">How to Perform</h3>
              <ol className="space-y-3">
                {exercise.instructions.map((instruction, i) => (
                  <li key={i} className="flex gap-3">
                    <span className="flex-shrink-0 w-7 h-7 flex items-center justify-center bg-primary text-primary-foreground rounded-full text-sm font-bold">
                      {i + 1}
                    </span>
                    <span className="text-sm pt-0.5 leading-relaxed">{instruction}</span>
                  </li>
                ))}
              </ol>
            </div>
            
            {/* Pro Tips */}
            <div className="mb-6 p-4 bg-primary/5 border border-primary/20 rounded-xl">
              <h3 className="text-sm font-semibold text-primary mb-2">Pro Tips</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary">+</span>
                  Start with lighter weight to master form
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">+</span>
                  Breathe out during exertion, in during release
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">+</span>
                  Focus on the muscle being worked
                </li>
              </ul>
            </div>
          </div>
          
          {/* Add button */}
          {onAdd && (
            <div className="sticky bottom-0 p-4 bg-background border-t border-border">
              <HapticButton onClick={onAdd} className="w-full" size="lg">
                <Plus className="w-5 h-5 mr-2" />
                Add to Workout
              </HapticButton>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
