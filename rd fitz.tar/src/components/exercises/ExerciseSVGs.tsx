// Inline SVG Exercise Illustrations - These WILL render
// No external URLs, all images are embedded SVGs
import React from 'react';

export const EXERCISE_SVGS: Record<string, React.ReactNode> = {
  // ===== CHEST EXERCISES =====
  'bench-press': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Bench */}
      <rect x="20" y="140" width="160" height="10" fill="#424242" rx="2"/>
      <rect x="40" y="150" width="10" height="30" fill="#616161"/>
      <rect x="150" y="150" width="10" height="30" fill="#616161"/>
      
      {/* Person lying down */}
      <ellipse cx="100" cy="130" rx="50" ry="15" fill="#00C853"/>
      <circle cx="55" cy="125" r="15" fill="#00C853"/>
      
      {/* Arms holding barbell */}
      <line x1="70" y1="115" x2="50" y2="95" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="130" y1="115" x2="150" y2="95" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Barbell */}
      <line x1="30" y1="90" x2="170" y2="90" stroke="#757575" strokeWidth="6" strokeLinecap="round"/>
      <rect x="25" y="85" width="15" height="15" fill="#424242" rx="2"/>
      <rect x="160" y="85" width="15" height="15" fill="#424242" rx="2"/>
    </svg>
  ),
  
  'incline-bench-press': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Incline bench */}
      <polygon points="20,160 180,160 150,100 50,100" fill="#424242"/>
      <rect x="40" y="160" width="10" height="25" fill="#616161"/>
      <rect x="150" y="160" width="10" height="25" fill="#616161"/>
      
      {/* Person on incline */}
      <ellipse cx="100" cy="90" rx="40" ry="15" fill="#00C853" transform="rotate(-15 100 90)"/>
      <circle cx="60" cy="75" r="14" fill="#00C853"/>
      
      {/* Arms pressing up */}
      <line x1="75" y1="70" x2="60" y2="40" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      <line x1="115" y1="80" x2="140" y2="50" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      
      {/* Barbell */}
      <line x1="30" y1="35" x2="170" y2="45" stroke="#757575" strokeWidth="5" strokeLinecap="round"/>
      <circle cx="40" cy="36" r="10" fill="#424242"/>
      <circle cx="160" cy="44" r="10" fill="#424242"/>
    </svg>
  ),
  
  'dumbbell-flyes': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Bench */}
      <rect x="20" y="140" width="160" height="10" fill="#424242" rx="2"/>
      
      {/* Person lying down */}
      <ellipse cx="100" cy="130" rx="50" ry="15" fill="#00C853"/>
      <circle cx="55" cy="125" r="15" fill="#00C853"/>
      
      {/* Arms spread out with dumbbells */}
      <line x1="70" y1="115" x2="30" y2="100" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      <line x1="130" y1="115" x2="170" y2="100" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      
      {/* Dumbbells */}
      <rect x="15" y="92" width="20" height="16" fill="#424242" rx="2"/>
      <rect x="165" y="92" width="20" height="16" fill="#424242" rx="2"/>
    </svg>
  ),
  
  'push-ups': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Floor */}
      <line x1="20" y1="170" x2="180" y2="170" stroke="#E0E0E0" strokeWidth="2"/>
      
      {/* Person in push-up position */}
      <circle cx="55" cy="130" r="15" fill="#00C853"/>
      <ellipse cx="110" cy="140" rx="50" ry="12" fill="#00C853"/>
      
      {/* Arms */}
      <line x1="70" y1="135" x2="80" y2="165" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="150" y1="135" x2="140" y2="165" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Legs */}
      <line x1="155" y1="140" x2="175" y2="145" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="160" y1="142" x2="180" y2="147" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
    </svg>
  ),
  
  'chest-dips': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Parallel bars */}
      <rect x="30" y="80" width="8" height="100" fill="#424242"/>
      <rect x="162" y="80" width="8" height="100" fill="#424242"/>
      <line x1="34" y1="85" x2="166" y2="85" stroke="#616161" strokeWidth="6"/>
      
      {/* Person doing dips */}
      <circle cx="100" cy="50" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="90" rx="25" ry="25" fill="#00C853"/>
      
      {/* Arms supporting */}
      <line x1="80" y1="85" x2="45" y2="80" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="120" y1="85" x2="155" y2="80" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Legs */}
      <line x1="90" y1="110" x2="85" y2="150" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="110" y1="110" x2="115" y2="150" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
    </svg>
  ),
  
  // ===== BACK EXERCISES =====
  'deadlift': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person bent over */}
      <circle cx="140" cy="50" r="18" fill="#00C853"/>
      <ellipse cx="110" cy="85" rx="35" ry="20" fill="#00C853" transform="rotate(-45 110 85)"/>
      
      {/* Legs */}
      <line x1="90" y1="100" x2="75" y2="150" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="75" y1="150" x2="85" y2="180" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="100" y1="100" x2="115" y2="150" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="115" y1="150" x2="105" y2="180" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Arms reaching to barbell */}
      <line x1="80" y1="90" x2="70" y2="140" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="100" y1="95" x2="100" y2="140" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Barbell on ground */}
      <line x1="30" y1="145" x2="140" y2="145" stroke="#757575" strokeWidth="6" strokeLinecap="round"/>
      <circle cx="40" cy="145" r="15" fill="#424242"/>
      <circle cx="130" cy="145" r="15" fill="#424242"/>
    </svg>
  ),
  
  'pull-ups': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Pull-up bar */}
      <line x1="40" y1="30" x2="160" y2="30" stroke="#424242" strokeWidth="8" strokeLinecap="round"/>
      <line x1="50" y1="30" x2="50" y2="10" stroke="#616161" strokeWidth="4"/>
      <line x1="150" y1="30" x2="150" y2="10" stroke="#616161" strokeWidth="4"/>
      
      {/* Arms reaching up */}
      <line x1="75" y1="70" x2="70" y2="35" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="125" y1="70" x2="130" y2="35" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Torso */}
      <ellipse cx="100" cy="100" rx="30" ry="40" fill="#00C853"/>
      <circle cx="100" cy="50" r="18" fill="#00C853"/>
      
      {/* Legs hanging */}
      <line x1="85" y1="135" x2="80" y2="180" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="115" y1="135" x2="120" y2="180" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
    </svg>
  ),
  
  'barbell-row': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person bent over */}
      <circle cx="140" cy="55" r="16" fill="#00C853"/>
      <ellipse cx="105" cy="90" rx="35" ry="18" fill="#00C853" transform="rotate(-50 105 90)"/>
      
      {/* Legs */}
      <line x1="85" y1="100" x2="75" y2="150" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="75" y1="150" x2="85" y2="180" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="95" y1="105" x2="105" y2="150" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="105" y1="150" x2="100" y2="180" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Arms rowing */}
      <line x1="80" y1="85" x2="70" y2="110" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      <line x1="100" y1="90" x2="100" y2="110" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      
      {/* Barbell */}
      <line x1="40" y1="115" x2="130" y2="115" stroke="#757575" strokeWidth="5" strokeLinecap="round"/>
      <circle cx="50" cy="115" r="12" fill="#424242"/>
      <circle cx="120" cy="115" r="12" fill="#424242"/>
    </svg>
  ),
  
  'lat-pulldown': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Machine top */}
      <rect x="70" y="10" width="60" height="8" fill="#424242" rx="2"/>
      <line x1="100" y1="18" x2="100" y2="40" stroke="#757575" strokeWidth="2"/>
      
      {/* Person seated */}
      <circle cx="100" cy="90" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="125" rx="25" ry="20" fill="#00C853"/>
      
      {/* Seat */}
      <rect x="60" y="145" width="80" height="15" fill="#616161" rx="3"/>
      
      {/* Legs */}
      <line x1="80" y1="145" x2="75" y2="180" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="120" y1="145" x2="125" y2="180" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Arms pulling bar down */}
      <line x1="82" y1="100" x2="75" y2="50" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="118" y1="100" x2="125" y2="50" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Bar */}
      <line x1="50" y1="50" x2="150" y2="50" stroke="#757575" strokeWidth="6" strokeLinecap="round"/>
    </svg>
  ),
  
  'seated-cable-row': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Machine base */}
      <rect x="10" y="150" width="50" height="30" fill="#424242" rx="3"/>
      <line x1="60" y1="165" x2="120" y2="165" stroke="#757575" strokeWidth="3"/>
      
      {/* Seat */}
      <rect x="120" y="130" width="60" height="15" fill="#616161" rx="3"/>
      
      {/* Person seated */}
      <circle cx="150" cy="90" r="18" fill="#00C853"/>
      <ellipse cx="145" cy="125" rx="25" ry="18" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="135" y1="130" x2="130" y2="155" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="155" y1="130" x2="160" y2="155" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Arms pulling cable */}
      <line x1="125" y1="110" x2="90" y2="130" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="125" y1="125" x2="90" y2="140" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
    </svg>
  ),
  
  // ===== SHOULDER EXERCISES =====
  'overhead-press': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person standing */}
      <circle cx="100" cy="50" r="20" fill="#00C853"/>
      <ellipse cx="100" cy="100" rx="30" ry="35" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="85" y1="130" x2="80" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="115" y1="130" x2="120" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Arms extended up */}
      <line x1="75" y1="90" x2="65" y2="45" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="125" y1="90" x2="135" y2="45" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Barbell overhead */}
      <line x1="30" y1="35" x2="170" y2="35" stroke="#757575" strokeWidth="6" strokeLinecap="round"/>
      <circle cx="40" cy="35" r="12" fill="#424242"/>
      <circle cx="160" cy="35" r="12" fill="#424242"/>
    </svg>
  ),
  
  'dumbbell-shoulder-press': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person standing */}
      <circle cx="100" cy="55" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="100" rx="28" ry="30" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="88" y1="125" x2="85" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="112" y1="125" x2="115" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Arms pressing dumbbells up */}
      <line x1="72" y1="90" x2="55" y2="45" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="128" y1="90" x2="145" y2="45" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Dumbbells overhead */}
      <rect x="35" y="30" width="25" height="20" fill="#424242" rx="3"/>
      <rect x="140" y="30" width="25" height="20" fill="#424242" rx="3"/>
    </svg>
  ),
  
  'lateral-raises': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person standing */}
      <circle cx="100" cy="50" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="95" rx="25" ry="30" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="88" y1="120" x2="85" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="112" y1="120" x2="115" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Arms raised to sides */}
      <line x1="75" y1="85" x2="30" y2="70" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="125" y1="85" x2="170" y2="70" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Dumbbells at shoulder height */}
      <rect x="10" y="60" width="25" height="18" fill="#424242" rx="3"/>
      <rect x="165" y="60" width="25" height="18" fill="#424242" rx="3"/>
    </svg>
  ),
  
  'front-raises': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person standing */}
      <circle cx="100" cy="50" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="95" rx="25" ry="30" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="88" y1="120" x2="85" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="112" y1="120" x2="115" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Arms raised to front */}
      <line x1="75" y1="85" x2="65" y2="50" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="125" y1="85" x2="135" y2="50" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Dumbbells at front */}
      <rect x="50" y="38" width="25" height="18" fill="#424242" rx="3"/>
      <rect x="125" y="38" width="25" height="18" fill="#424242" rx="3"/>
    </svg>
  ),
  
  'face-pulls': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Cable machine */}
      <rect x="10" y="60" width="15" height="120" fill="#424242"/>
      <rect x="10" y="75" width="30" height="10" fill="#616161" rx="2"/>
      
      {/* Rope */}
      <line x1="40" y1="80" x2="70" y2="95" stroke="#757575" strokeWidth="3"/>
      
      {/* Person */}
      <circle cx="120" cy="75" r="18" fill="#00C853"/>
      <ellipse cx="115" cy="115" rx="25" ry="25" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="100" y1="135" x2="95" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="125" y1="135" x2="130" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Arms pulling rope to face */}
      <line x1="90" y1="100" x2="60" y2="90" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="90" y1="85" x2="55" y2="75" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
    </svg>
  ),
  
  // ===== BICEPS EXERCISES =====
  'barbell-curl': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person standing */}
      <circle cx="100" cy="45" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="90" rx="28" ry="30" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="88" y1="115" x2="85" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="112" y1="115" x2="115" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Arms curling barbell */}
      <line x1="72" y1="85" x2="65" y2="110" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="128" y1="85" x2="135" y2="110" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Barbell at chest level */}
      <line x1="40" y1="85" x2="160" y2="85" stroke="#757575" strokeWidth="6" strokeLinecap="round"/>
      <circle cx="50" cy="85" r="12" fill="#424242"/>
      <circle cx="150" cy="85" r="12" fill="#424242"/>
    </svg>
  ),
  
  'dumbbell-curl': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person standing */}
      <circle cx="100" cy="45" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="90" rx="25" ry="30" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="88" y1="115" x2="85" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="112" y1="115" x2="115" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Arms with dumbbells */}
      <line x1="75" y1="85" x2="65" y2="70" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="125" y1="85" x2="135" y2="70" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Dumbbells */}
      <rect x="50" y="55" width="25" height="20" fill="#424242" rx="3"/>
      <rect x="125" y="55" width="25" height="20" fill="#424242" rx="3"/>
    </svg>
  ),
  
  'hammer-curl': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person standing */}
      <circle cx="100" cy="45" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="90" rx="25" ry="30" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="88" y1="115" x2="85" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="112" y1="115" x2="115" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Arms in neutral grip */}
      <line x1="75" y1="85" x2="70" y2="60" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="125" y1="85" x2="130" y2="60" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Dumbbells vertical (hammer grip) */}
      <rect x="60" y="42" width="18" height="28" fill="#424242" rx="3"/>
      <rect x="122" y="42" width="18" height="28" fill="#424242" rx="3"/>
    </svg>
  ),
  
  'preacher-curl': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Preacher bench */}
      <polygon points="40,120 160,120 140,180 60,180" fill="#424242"/>
      <ellipse cx="100" cy="115" rx="50" ry="15" fill="#616161"/>
      
      {/* Arms on pad */}
      <ellipse cx="100" cy="95" rx="35" ry="12" fill="#00C853"/>
      
      {/* Forearms curling */}
      <ellipse cx="100" cy="75" rx="25" ry="10" fill="#00C853"/>
      
      {/* Person behind */}
      <circle cx="100" cy="40" r="20" fill="#00C853"/>
      <ellipse cx="100" cy="70" rx="25" ry="20" fill="#00C853"/>
      
      {/* EZ bar */}
      <path d="M 50 65 Q 70 55 100 60 Q 130 55 150 65" stroke="#757575" strokeWidth="5" fill="none"/>
      <circle cx="55" cy="66" r="10" fill="#424242"/>
      <circle cx="145" cy="66" r="10" fill="#424242"/>
    </svg>
  ),
  
  'concentration-curl': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Bench */}
      <rect x="80" y="140" width="80" height="40" fill="#424242" rx="3"/>
      
      {/* Person seated */}
      <circle cx="100" cy="55" r="18" fill="#00C853"/>
      <ellipse cx="110" cy="95" rx="25" ry="30" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="95" y1="120" x2="90" y2="145" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="125" y1="120" x2="145" y2="145" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Arm on inner thigh */}
      <ellipse cx="95" cy="135" rx="20" ry="8" fill="#00C853"/>
      
      {/* Curling arm */}
      <line x1="95" y1="110" x2="75" y2="80" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Dumbbell */}
      <rect x="60" y="65" width="20" height="25" fill="#424242" rx="3"/>
    </svg>
  ),
  
  // ===== TRICEPS EXERCISES =====
  'tricep-pushdown': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Cable machine */}
      <rect x="85" y="10" width="30" height="8" fill="#424242" rx="2"/>
      <line x1="100" y1="18" x2="100" y2="50" stroke="#757575" strokeWidth="2"/>
      
      {/* Person */}
      <circle cx="100" cy="70" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="110" rx="25" ry="30" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="88" y1="135" x2="85" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="112" y1="135" x2="115" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Arms pushing down */}
      <line x1="75" y1="95" x2="75" y2="130" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="125" y1="95" x2="125" y2="130" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Rope attachment */}
      <line x1="95" y1="50" x2="75" y2="95" stroke="#757575" strokeWidth="3"/>
      <line x1="105" y1="50" x2="125" y2="95" stroke="#757575" strokeWidth="3"/>
    </svg>
  ),
  
  'skull-crushers': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Bench */}
      <rect x="20" y="140" width="160" height="10" fill="#424242" rx="2"/>
      
      {/* Person lying down */}
      <ellipse cx="100" cy="130" rx="50" ry="15" fill="#00C853"/>
      <circle cx="55" cy="125" r="15" fill="#00C853"/>
      
      {/* Arms extended */}
      <line x1="75" y1="120" x2="70" y2="95" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      <line x1="125" y1="120" x2="130" y2="95" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      
      {/* Forearms bent back */}
      <line x1="70" y1="95" x2="75" y2="115" stroke="#00C853" strokeWidth="6" strokeLinecap="round"/>
      <line x1="130" y1="95" x2="125" y2="115" stroke="#00C853" strokeWidth="6" strokeLinecap="round"/>
      
      {/* EZ bar */}
      <path d="M 55 115 Q 80 120 100 118 Q 120 120 145 115" stroke="#757575" strokeWidth="5" fill="none"/>
      <circle cx="60" cy="116" r="8" fill="#424242"/>
      <circle cx="140" cy="116" r="8" fill="#424242"/>
    </svg>
  ),
  
  'tricep-dips': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Bench */}
      <rect x="20" y="130" width="60" height="15" fill="#424242" rx="3"/>
      
      {/* Person doing dip */}
      <circle cx="60" cy="70" r="18" fill="#00C853"/>
      <ellipse cx="70" cy="105" rx="25" ry="25" fill="#00C853"/>
      
      {/* Arms on bench */}
      <line x1="50" y1="100" x2="50" y2="130" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="70" y1="120" x2="65" y2="130" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Legs extended */}
      <line x1="90" y1="100" x2="160" y2="90" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="95" y1="95" x2="165" y2="85" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
    </svg>
  ),
  
  'close-grip-bench-press': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Bench */}
      <rect x="20" y="140" width="160" height="10" fill="#424242" rx="2"/>
      
      {/* Person lying down */}
      <ellipse cx="100" cy="130" rx="50" ry="15" fill="#00C853"/>
      <circle cx="55" cy="125" r="15" fill="#00C853"/>
      
      {/* Arms close together */}
      <line x1="85" y1="115" x2="90" y2="90" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="115" y1="115" x2="110" y2="90" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Barbell */}
      <line x1="60" y1="85" x2="140" y2="85" stroke="#757575" strokeWidth="6" strokeLinecap="round"/>
      <circle cx="70" cy="85" r="10" fill="#424242"/>
      <circle cx="130" cy="85" r="10" fill="#424242"/>
    </svg>
  ),
  
  'overhead-tricep-extension': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person standing */}
      <circle cx="100" cy="45" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="90" rx="25" ry="30" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="88" y1="115" x2="85" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="112" y1="115" x2="115" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Arms holding dumbbell overhead */}
      <line x1="100" y1="75" x2="100" y2="35" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Dumbbell behind head */}
      <rect x="88" y="15" width="24" height="30" fill="#424242" rx="3"/>
    </svg>
  ),
  
  // ===== LEGS - QUADRICEPS =====
  'barbell-squat': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person squatting */}
      <circle cx="100" cy="45" r="20" fill="#00C853"/>
      <ellipse cx="100" cy="90" rx="25" ry="35" fill="#00C853"/>
      
      {/* Legs in squat position */}
      <line x1="85" y1="120" x2="60" y2="150" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="60" y1="150" x2="75" y2="175" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="115" y1="120" x2="140" y2="150" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="140" y1="150" x2="125" y2="175" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Arms holding barbell */}
      <line x1="75" y1="80" x2="45" y2="70" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="125" y1="80" x2="155" y2="70" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Barbell on shoulders */}
      <line x1="20" y1="65" x2="180" y2="65" stroke="#757575" strokeWidth="6" strokeLinecap="round"/>
      <circle cx="30" cy="65" r="12" fill="#424242"/>
      <circle cx="170" cy="65" r="12" fill="#424242"/>
    </svg>
  ),
  
  'front-squat': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person squatting */}
      <circle cx="100" cy="50" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="95" rx="25" ry="30" fill="#00C853"/>
      
      {/* Legs in squat */}
      <line x1="85" y1="120" x2="60" y2="150" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="60" y1="150" x2="75" y2="175" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="115" y1="120" x2="140" y2="150" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="140" y1="150" x2="125" y2="175" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Arms crossed in front */}
      <line x1="80" y1="80" x2="100" y2="75" stroke="#00C853" strokeWidth="6" strokeLinecap="round"/>
      <line x1="120" y1="80" x2="100" y2="75" stroke="#00C853" strokeWidth="6" strokeLinecap="round"/>
      
      {/* Barbell on front shoulders */}
      <line x1="40" y1="75" x2="160" y2="75" stroke="#757575" strokeWidth="5" strokeLinecap="round"/>
      <circle cx="48" cy="75" r="10" fill="#424242"/>
      <circle cx="152" cy="75" r="10" fill="#424242"/>
    </svg>
  ),
  
  'leg-press': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Leg press machine seat */}
      <rect x="60" y="130" width="80" height="40" fill="#424242" rx="5"/>
      <rect x="40" y="170" width="120" height="10" fill="#616161"/>
      
      {/* Platform */}
      <rect x="20" y="60" width="30" height="80" fill="#424242" rx="3"/>
      
      {/* Person */}
      <circle cx="100" cy="110" r="15" fill="#00C853"/>
      <ellipse cx="100" cy="140" rx="20" ry="15" fill="#00C853"/>
      
      {/* Legs pressing */}
      <line x1="85" y1="145" x2="55" y2="100" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="115" y1="145" x2="145" y2="100" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
    </svg>
  ),
  
  'leg-extension': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Machine seat */}
      <rect x="50" y="100" width="70" height="40" fill="#424242" rx="3"/>
      <rect x="60" y="140" width="50" height="35" fill="#616161"/>
      
      {/* Person seated */}
      <circle cx="85" cy="70" r="18" fill="#00C853"/>
      <ellipse cx="85" cy="100" rx="20" ry="20" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="75" y1="115" x2="70" y2="145" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Leg extension pad and lever */}
      <line x1="70" y1="145" x2="40" y2="160" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <rect x="25" y="155" width="25" height="12" fill="#616161" rx="2"/>
      <ellipse cx="55" cy="145" rx="18" ry="8" fill="#757575"/>
    </svg>
  ),
  
  'bulgarian-split-squat': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Bench behind */}
      <rect x="130" y="130" width="50" height="20" fill="#424242" rx="3"/>
      
      {/* Person in split squat */}
      <circle cx="80" cy="45" r="18" fill="#00C853"/>
      <ellipse cx="85" cy="85" rx="25" ry="25" fill="#00C853"/>
      
      {/* Front leg */}
      <line x1="75" y1="105" x2="55" y2="145" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="55" y1="145" x2="75" y2="175" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Back leg on bench */}
      <line x1="100" y1="105" x2="145" y2="120" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Arms holding dumbbells */}
      <line x1="65" y1="80" x2="45" y2="95" stroke="#00C853" strokeWidth="6" strokeLinecap="round"/>
      <line x1="105" y1="80" x2="125" y2="95" stroke="#00C853" strokeWidth="6" strokeLinecap="round"/>
      
      {/* Dumbbells */}
      <rect x="35" y="90" width="18" height="20" fill="#424242" rx="2"/>
      <rect x="120" y="90" width="18" height="20" fill="#424242" rx="2"/>
    </svg>
  ),
  
  // ===== LEGS - HAMSTRINGS =====
  'romanian-deadlift': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person bent forward */}
      <circle cx="145" cy="50" r="18" fill="#00C853"/>
      <ellipse cx="115" cy="80" rx="35" ry="18" fill="#00C853" transform="rotate(-40 115 80)"/>
      
      {/* Legs straight */}
      <line x1="90" y1="95" x2="80" y2="150" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="80" y1="150" x2="90" y2="180" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="100" y1="95" x2="110" y2="150" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="110" y1="150" x2="100" y2="180" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Arms holding barbell at knee level */}
      <line x1="85" y1="85" x2="75" y2="130" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="100" y1="90" x2="100" y2="130" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Barbell */}
      <line x1="45" y1="130" x2="130" y2="130" stroke="#757575" strokeWidth="5" strokeLinecap="round"/>
      <circle cx="55" cy="130" r="12" fill="#424242"/>
      <circle cx="120" cy="130" r="12" fill="#424242"/>
    </svg>
  ),
  
  'leg-curl': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Machine bench */}
      <rect x="30" y="80" width="140" height="25" fill="#424242" rx="3"/>
      
      {/* Person lying face down */}
      <ellipse cx="100" cy="80" rx="50" ry="12" fill="#00C853"/>
      <circle cx="50" cy="75" r="15" fill="#00C853"/>
      
      {/* Legs curled up */}
      <line x1="140" y1="80" x2="170" y2="60" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="170" y1="60" x2="160" y2="100" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Machine pad */}
      <ellipse cx="165" cy="55" rx="15" ry="8" fill="#616161"/>
    </svg>
  ),
  
  'good-mornings': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person bent forward with bar on back */}
      <circle cx="145" cy="55" r="16" fill="#00C853"/>
      <ellipse cx="115" cy="85" rx="35" ry="18" fill="#00C853" transform="rotate(-45 115 85)"/>
      
      {/* Legs */}
      <line x1="90" y1="100" x2="80" y2="150" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="80" y1="150" x2="90" y2="180" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="100" y1="100" x2="110" y2="150" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="110" y1="150" x2="100" y2="180" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Barbell on upper back */}
      <line x1="50" y1="50" x2="160" y2="50" stroke="#757575" strokeWidth="5" strokeLinecap="round"/>
      <circle cx="60" cy="50" r="10" fill="#424242"/>
      <circle cx="150" cy="50" r="10" fill="#424242"/>
    </svg>
  ),
  
  // ===== LEGS - GLUTES =====
  'hip-thrust': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Bench */}
      <rect x="10" y="100" width="50" height="20" fill="#424242" rx="3"/>
      
      {/* Person with back on bench */}
      <circle cx="45" cy="90" r="15" fill="#00C853"/>
      <ellipse cx="90" cy="120" rx="40" ry="15" fill="#00C853"/>
      
      {/* Legs bent */}
      <line x1="110" y1="125" x2="120" y2="160" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="120" y1="160" x2="95" y2="175" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Barbell on hips */}
      <line x1="60" y1="115" x2="130" y2="115" stroke="#757575" strokeWidth="5" strokeLinecap="round"/>
      <circle cx="70" cy="115" r="10" fill="#424242"/>
      <circle cx="120" cy="115" r="10" fill="#424242"/>
    </svg>
  ),
  
  'glute-bridge': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Floor */}
      <line x1="20" y1="175" x2="180" y2="175" stroke="#E0E0E0" strokeWidth="2"/>
      
      {/* Person on back with hips up */}
      <ellipse cx="100" cy="130" rx="50" ry="15" fill="#00C853"/>
      <circle cx="55" cy="135" r="15" fill="#00C853"/>
      
      {/* Legs bent, feet on floor */}
      <line x1="135" y1="130" x2="155" y2="160" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="155" y1="160" x2="140" y2="175" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
    </svg>
  ),
  
  'cable-kickback': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Cable machine */}
      <rect x="10" y="100" width="20" height="80" fill="#424242"/>
      <rect x="10" y="150" width="30" height="10" fill="#616161"/>
      
      {/* Person */}
      <circle cx="120" cy="60" r="18" fill="#00C853"/>
      <ellipse cx="115" cy="100" rx="25" ry="25" fill="#00C853"/>
      
      {/* Support leg */}
      <line x1="100" y1="120" x2="95" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Kicking leg back */}
      <line x1="130" y1="120" x2="60" y2="130" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Cable */}
      <line x1="40" y1="155" x2="60" y2="130" stroke="#757575" strokeWidth="3"/>
      
      {/* Arms holding machine */}
      <line x1="95" y1="85" x2="50" y2="110" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
    </svg>
  ),
  
  // ===== LEGS - CALVES =====
  'standing-calf-raise': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Step/platform */}
      <rect x="60" y="170" width="80" height="15" fill="#424242" rx="2"/>
      
      {/* Person standing on toes */}
      <circle cx="100" cy="45" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="90" rx="25" ry="30" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="88" y1="115" x2="85" y2="165" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="112" y1="115" x2="115" y2="165" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Feet on toes */}
      <polygon points="80,165 90,170 90,170 80,170" fill="#00C853"/>
      <polygon points="110,165 120,170 120,170 110,170" fill="#00C853"/>
      
      {/* Arms at sides */}
      <line x1="75" y1="85" x2="65" y2="120" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      <line x1="125" y1="85" x2="135" y2="120" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
    </svg>
  ),
  
  'seated-calf-raise': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Seat */}
      <rect x="50" y="100" width="80" height="20" fill="#424242" rx="3"/>
      
      {/* Weight on knees */}
      <rect x="70" y="75" width="60" height="25" fill="#616161" rx="5"/>
      
      {/* Person seated */}
      <circle cx="90" cy="50" r="18" fill="#00C853"/>
      <ellipse cx="90" cy="85" rx="22" ry="20" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="80" y1="100" x2="75" y2="145" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="100" y1="100" x2="105" y2="145" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Feet platform */}
      <rect x="55" y="150" width="70" height="25" fill="#616161" rx="3"/>
      
      {/* Toes pointed down */}
      <polygon points="70,175 85,180 85,175" fill="#00C853"/>
      <polygon points="95,175 110,180 110,175" fill="#00C853"/>
    </svg>
  ),
  
  // ===== ABS =====
  'plank': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Floor */}
      <line x1="20" y1="160" x2="180" y2="160" stroke="#E0E0E0" strokeWidth="2"/>
      
      {/* Person in plank position */}
      <circle cx="55" cy="125" r="15" fill="#00C853"/>
      <ellipse cx="115" cy="130" rx="55" ry="10" fill="#00C853"/>
      
      {/* Forearms */}
      <ellipse cx="60" cy="155" rx="20" ry="6" fill="#00C853"/>
      
      {/* Legs */}
      <line x1="165" y1="130" x2="180" y2="155" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
    </svg>
  ),
  
  'crunches': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Floor/mat */}
      <rect x="30" y="150" width="140" height="8" fill="#E0E0E0" rx="2"/>
      
      {/* Person doing crunch */}
      <ellipse cx="100" cy="130" rx="50" ry="15" fill="#00C853"/>
      <circle cx="70" cy="100" r="18" fill="#00C853"/>
      
      {/* Torso raised */}
      <ellipse cx="110" cy="115" rx="30" ry="20" fill="#00C853" transform="rotate(-30 110 115)"/>
      
      {/* Legs bent */}
      <line x1="140" y1="130" x2="160" y2="110" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="160" y1="110" x2="170" y2="130" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
    </svg>
  ),
  
  'leg-raises': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Hanging bar */}
      <line x1="40" y1="25" x2="160" y2="25" stroke="#424242" strokeWidth="6"/>
      
      {/* Person hanging */}
      <circle cx="100" cy="55" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="90" rx="25" ry="25" fill="#00C853"/>
      
      {/* Arms */}
      <line x1="80" y1="60" x2="75" y2="30" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="120" y1="60" x2="125" y2="30" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Legs raised */}
      <line x1="90" y1="110" x2="60" y2="70" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="110" y1="110" x2="140" y2="70" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
    </svg>
  ),
  
  'russian-twist': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Floor */}
      <line x1="20" y1="170" x2="180" y2="170" stroke="#E0E0E0" strokeWidth="2"/>
      
      {/* Person seated, leaning back */}
      <circle cx="100" cy="80" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="115" rx="30" ry="25" fill="#00C853"/>
      
      {/* Legs elevated */}
      <line x1="100" y1="135" x2="60" y2="120" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="100" y1="135" x2="140" y2="120" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Arms twisted to side holding weight */}
      <line x1="115" y1="95" x2="145" y2="85" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      <circle cx="150" cy="80" r="10" fill="#424242"/>
    </svg>
  ),
  
  'mountain-climbers': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Floor */}
      <line x1="20" y1="165" x2="180" y2="165" stroke="#E0E0E0" strokeWidth="2"/>
      
      {/* Person in plank */}
      <circle cx="55" cy="125" r="15" fill="#00C853"/>
      <ellipse cx="115" cy="135" rx="50" ry="12" fill="#00C853"/>
      
      {/* Arms */}
      <line x1="70" y1="130" x2="60" y2="160" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      <line x1="150" y1="130" x2="160" y2="160" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      
      {/* Legs in running motion */}
      <line x1="155" y1="135" x2="175" y2="160" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="165" y1="135" x2="150" y2="110" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Motion lines */}
      <line x1="130" y1="100" x2="145" y2="105" stroke="#BDBDBD" strokeWidth="2"/>
    </svg>
  ),
  
  // ===== CARDIO =====
  'running': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person running */}
      <circle cx="80" cy="50" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="90" rx="25" ry="25" fill="#00C853"/>
      
      {/* Arms in running motion */}
      <line x1="85" y1="80" x2="60" y2="60" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="115" y1="80" x2="140" y2="100" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Legs in stride */}
      <line x1="90" y1="110" x2="60" y2="150" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="60" y1="150" x2="75" y2="180" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="110" y1="110" x2="145" y2="120" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="145" y1="120" x2="150" y2="155" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Motion lines */}
      <line x1="40" y1="70" x2="55" y2="75" stroke="#BDBDBD" strokeWidth="2"/>
      <line x1="35" y1="90" x2="50" y2="95" stroke="#BDBDBD" strokeWidth="2"/>
    </svg>
  ),
  
  'jumping-jacks': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person in star position */}
      <circle cx="100" cy="60" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="100" rx="25" ry="25" fill="#00C853"/>
      
      {/* Arms out to sides */}
      <line x1="75" y1="90" x2="35" y2="70" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="125" y1="90" x2="165" y2="70" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Legs spread */}
      <line x1="85" y1="120" x2="55" y2="175" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="115" y1="120" x2="145" y2="175" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
    </svg>
  ),
  
  'burpees': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Floor */}
      <line x1="20" y1="150" x2="180" y2="150" stroke="#E0E0E0" strokeWidth="2"/>
      
      {/* Person in squat/jump position */}
      <circle cx="100" cy="55" r="16" fill="#00C853"/>
      <ellipse cx="100" cy="90" rx="25" ry="25" fill="#00C853"/>
      
      {/* Arms reaching down */}
      <line x1="80" y1="85" x2="55" y2="115" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      <line x1="120" y1="85" x2="145" y2="115" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      
      {/* Legs in squat */}
      <line x1="85" y1="110" x2="60" y2="140" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="115" y1="110" x2="140" y2="140" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Jump lines */}
      <line x1="95" y1="40" x2="105" y2="25" stroke="#BDBDBD" strokeWidth="2"/>
    </svg>
  ),
  
  'jump-rope': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person jumping */}
      <circle cx="100" cy="65" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="105" rx="25" ry="25" fill="#00C853"/>
      
      {/* Arms holding rope */}
      <line x1="75" y1="95" x2="50" y2="80" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      <line x1="125" y1="95" x2="150" y2="80" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      
      {/* Legs together in air */}
      <line x1="100" y1="125" x2="95" y2="160" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="100" y1="125" x2="105" y2="160" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Jump rope arc */}
      <path d="M 50 80 Q 100 180 150 80" stroke="#757575" strokeWidth="3" fill="none"/>
      
      {/* Handles */}
      <circle cx="50" cy="80" r="6" fill="#424242"/>
      <circle cx="150" cy="80" r="6" fill="#424242"/>
    </svg>
  ),
  
  'high-knees': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person running with high knees */}
      <circle cx="100" cy="50" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="90" rx="25" ry="25" fill="#00C853"/>
      
      {/* Arms pumping */}
      <line x1="80" y1="80" x2="55" y2="100" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      <line x1="120" y1="80" x2="145" y2="100" stroke="#00C853" strokeWidth="8" strokeLinecap="round"/>
      
      {/* Legs with high knees */}
      <line x1="90" y1="110" x2="65" y2="75" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="65" y1="75" x2="75" y2="90" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="110" y1="110" x2="135" y2="160" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Motion blur */}
      <line x1="45" y1="95" x2="55" y2="100" stroke="#BDBDBD" strokeWidth="2"/>
    </svg>
  ),
  
  // ===== OTHER BODYWEIGHT =====
  'lunges': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person in lunge position */}
      <circle cx="100" cy="45" r="18" fill="#00C853"/>
      <ellipse cx="100" cy="85" rx="25" ry="25" fill="#00C853"/>
      
      {/* Front leg bent */}
      <line x1="90" y1="105" x2="70" y2="140" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="70" y1="140" x2="95" y2="175" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Back leg extended */}
      <line x1="110" y1="105" x2="140" y2="145" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="140" y1="145" x2="150" y2="175" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
    </svg>
  ),
  
  'wall-sit': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Wall */}
      <rect x="10" y="30" width="30" height="150" fill="#616161"/>
      
      {/* Person against wall in seated position */}
      <circle cx="80" cy="60" r="16" fill="#00C853"/>
      <ellipse cx="80" cy="100" rx="25" ry="25" fill="#00C853"/>
      
      {/* Back against wall */}
      <rect x="35" y="50" width="10" height="80" fill="#00C853" opacity="0.3"/>
      
      {/* Legs at 90 degrees */}
      <line x1="80" y1="120" x2="130" y2="120" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="130" y1="120" x2="130" y2="160" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
    </svg>
  ),
  
  'pistol-squat': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Person in single leg squat */}
      <circle cx="100" cy="50" r="16" fill="#00C853"/>
      <ellipse cx="100" cy="85" rx="22" ry="22" fill="#00C853"/>
      
      {/* Standing leg bent */}
      <line x1="95" y1="105" x2="75" y2="140" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="75" y1="140" x2="95" y2="175" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Other leg extended forward */}
      <line x1="105" y1="105" x2="160" y2="115" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Arms forward for balance */}
      <line x1="85" y1="80" x2="50" y2="85" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
      <line x1="115" y1="80" x2="150" y2="85" stroke="#00C853" strokeWidth="7" strokeLinecap="round"/>
    </svg>
  ),
  
  // DEFAULT
  'default': (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      {/* Generic exercise figure */}
      <circle cx="100" cy="50" r="20" fill="#00C853"/>
      <ellipse cx="100" cy="100" rx="30" ry="35" fill="#00C853"/>
      
      {/* Arms */}
      <line x1="70" y1="90" x2="45" y2="110" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      <line x1="130" y1="90" x2="155" y2="110" stroke="#00C853" strokeWidth="10" strokeLinecap="round"/>
      
      {/* Legs */}
      <line x1="85" y1="130" x2="75" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      <line x1="115" y1="130" x2="125" y2="180" stroke="#00C853" strokeWidth="12" strokeLinecap="round"/>
      
      {/* Dumbbell icon */}
      <rect x="30" y="100" width="20" height="25" fill="#424242" rx="3"/>
      <rect x="150" y="100" width="20" height="25" fill="#424242" rx="3"/>
    </svg>
  ),
};

// Get SVG by exercise ID or name
export function getExerciseSVG(exerciseId: string): React.ReactNode {
  // Try direct ID match
  if (EXERCISE_SVGS[exerciseId]) {
    return EXERCISE_SVGS[exerciseId];
  }
  
  // Try name-based matching
  const nameMap: Record<string, string> = {
    'bench': 'bench-press',
    'squat': 'barbell-squat',
    'deadlift': 'deadlift',
    'pull': 'pull-ups',
    'push': 'push-ups',
    'overhead': 'overhead-press',
    'curl': 'barbell-curl',
    'tricep': 'tricep-pushdown',
    'press': 'leg-press',
    'plank': 'plank',
    'lunge': 'lunges',
    'run': 'running',
    'crunch': 'crunches',
    'dumbbell': 'dumbbell-curl',
    'lat': 'lat-pulldown',
    'row': 'barbell-row',
    'dip': 'tricep-dips',
    'fly': 'dumbbell-flyes',
    'raise': 'lateral-raises',
    'extension': 'leg-extension',
    'curl': 'leg-curl',
    'thrust': 'hip-thrust',
    'calf': 'standing-calf-raise',
    'burpee': 'burpees',
    'jump': 'jumping-jacks',
    'knee': 'high-knees',
    'rope': 'jump-rope',
    'twist': 'russian-twist',
    'climb': 'mountain-climbers',
    'bridge': 'glute-bridge',
    'good': 'good-mornings',
    'romanian': 'romanian-deadlift',
    'front': 'front-squat',
    'incline': 'incline-bench-press',
    'close': 'close-grip-bench-press',
    'skull': 'skull-crushers',
    'preacher': 'preacher-curl',
    'concentration': 'concentration-curl',
    'hammer': 'hammer-curl',
    'face': 'face-pulls',
    'bulgarian': 'bulgarian-split-squat',
    'wall': 'wall-sit',
    'pistol': 'pistol-squat',
    'kickback': 'cable-kickback',
  };
  
  const lowerId = exerciseId.toLowerCase();
  for (const [key, svgId] of Object.entries(nameMap)) {
    if (lowerId.includes(key)) {
      return EXERCISE_SVGS[svgId] || EXERCISE_SVGS['default'];
    }
  }
  
  return EXERCISE_SVGS['default'];
}
