'use client';

import * as React from 'react';
import { useState } from 'react';
import { HapticButton } from '@/components/common/HapticButton';
import { FilterChipGroup } from '@/components/common/FilterChip';
import { useHaptic } from '@/hooks/useHaptic';
import { useAudio } from '@/hooks/useAudio';
import { cn } from '@/lib/utils';
import type { FitnessGoal, DayOfWeek, Equipment } from '@/types';
import { Dumbbell, Heart, Target, Flame, Check } from 'lucide-react';

interface OnboardingStepProps {
  onNext: () => void;
  onBack?: () => void;
}

function WelcomeStep({ onNext }: OnboardingStepProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] px-6 text-center">
      <div className="w-24 h-24 mb-8 flex items-center justify-center bg-primary/10 rounded-2xl">
        <Dumbbell className="w-12 h-12 text-primary" strokeWidth={2} />
      </div>
      <h1 className="text-h1 mb-4">Welcome to RD FITZ</h1>
      <p className="text-body-lg text-muted-foreground mb-8 max-w-sm">
        Your personal gym copilot. Plan workouts, track progress, and achieve your fitness goals.
      </p>
      <HapticButton onClick={onNext} size="lg" className="w-full max-w-xs">
        Get Started
      </HapticButton>
    </div>
  );
}

function NameStep({ onNext, data, setData }: OnboardingStepProps & { data: string; setData: (name: string) => void }) {
  const isValid = data.trim().length >= 2;
  
  return (
    <div className="flex flex-col px-6 py-8 min-h-[70vh]">
      <div className="flex-1">
        <h1 className="text-h1 mb-2">What should we call you?</h1>
        <p className="text-body text-muted-foreground mb-8">
          Enter your name to personalize your experience
        </p>
        <input
          type="text"
          value={data}
          onChange={(e) => setData(e.target.value)}
          placeholder="Your name"
          className="w-full px-4 py-4 text-lg bg-background border border-border rounded-xl focus:outline-none focus:border-primary transition-colors"
          autoFocus
        />
      </div>
      <HapticButton 
        onClick={onNext} 
        disabled={!isValid} 
        size="lg" 
        className="w-full"
      >
        Continue
      </HapticButton>
    </div>
  );
}

function GoalsStep({ onNext, onBack, data, setData }: OnboardingStepProps & { data: FitnessGoal[]; setData: (goals: FitnessGoal[]) => void }) {
  const goalOptions = [
    { value: 'weight_loss', label: 'Weight Loss', icon: <Flame className="w-4 h-4" /> },
    { value: 'strength', label: 'Build Strength', icon: <Dumbbell className="w-4 h-4" /> },
    { value: 'endurance', label: 'Endurance', icon: <Heart className="w-4 h-4" /> },
    { value: 'muscle_gain', label: 'Muscle Gain', icon: <Target className="w-4 h-4" /> },
  ];
  
  const isValid = data.length > 0;
  
  return (
    <div className="flex flex-col px-6 py-8 min-h-[70vh]">
      <div className="flex-1">
        <h1 className="text-h1 mb-2">What are your goals?</h1>
        <p className="text-body text-muted-foreground mb-8">
          Select all that apply. We will tailor your workouts accordingly.
        </p>
        <FilterChipGroup
          options={goalOptions}
          value={data}
          onChange={(values) => setData(values as FitnessGoal[])}
          className="gap-3"
        />
      </div>
      <div className="flex gap-3">
        {onBack && (
          <HapticButton onClick={onBack} variant="secondary" size="lg" className="flex-1">
            Back
          </HapticButton>
        )}
        <HapticButton 
          onClick={onNext} 
          disabled={!isValid} 
          size="lg" 
          className="flex-1"
        >
          Continue
        </HapticButton>
      </div>
    </div>
  );
}

function DaysStep({ onNext, onBack, data, setData }: OnboardingStepProps & { data: DayOfWeek[]; setData: (days: DayOfWeek[]) => void }) {
  const dayOptions = [
    { value: 'monday', label: 'Mon' },
    { value: 'tuesday', label: 'Tue' },
    { value: 'wednesday', label: 'Wed' },
    { value: 'thursday', label: 'Thu' },
    { value: 'friday', label: 'Fri' },
    { value: 'saturday', label: 'Sat' },
    { value: 'sunday', label: 'Sun' },
  ];
  
  const isValid = data.length > 0;
  
  return (
    <div className="flex flex-col px-6 py-8 min-h-[70vh]">
      <div className="flex-1">
        <h1 className="text-h1 mb-2">When do you work out?</h1>
        <p className="text-body text-muted-foreground mb-8">
          Select your preferred workout days
        </p>
        <FilterChipGroup
          options={dayOptions}
          value={data}
          onChange={(values) => setData(values as DayOfWeek[])}
          className="gap-3"
        />
      </div>
      <div className="flex gap-3">
        {onBack && (
          <HapticButton onClick={onBack} variant="secondary" size="lg" className="flex-1">
            Back
          </HapticButton>
        )}
        <HapticButton 
          onClick={onNext} 
          disabled={!isValid} 
          size="lg" 
          className="flex-1"
        >
          Continue
        </HapticButton>
      </div>
    </div>
  );
}

function EquipmentStep({ onNext, onBack, data, setData }: OnboardingStepProps & { data: Equipment[]; setData: (equipment: Equipment[]) => void }) {
  const equipmentOptions = [
    { value: 'none', label: 'No Equipment' },
    { value: 'dumbbells', label: 'Dumbbells' },
    { value: 'barbell', label: 'Barbell' },
    { value: 'kettlebell', label: 'Kettlebell' },
    { value: 'resistance_bands', label: 'Resistance Bands' },
    { value: 'pull_up_bar', label: 'Pull-up Bar' },
    { value: 'bench', label: 'Bench' },
    { value: 'cable_machine', label: 'Cable Machine' },
    { value: 'treadmill', label: 'Treadmill' },
    { value: 'bike', label: 'Exercise Bike' },
    { value: 'rower', label: 'Rowing Machine' },
  ];
  
  const isValid = data.length > 0;
  
  return (
    <div className="flex flex-col px-6 py-8 min-h-[70vh]">
      <div className="flex-1">
        <h1 className="text-h1 mb-2">What equipment do you have?</h1>
        <p className="text-body text-muted-foreground mb-8">
          Select all available equipment for your workouts
        </p>
        <FilterChipGroup
          options={equipmentOptions}
          value={data}
          onChange={(values) => setData(values as Equipment[])}
          className="gap-3"
        />
      </div>
      <div className="flex gap-3">
        {onBack && (
          <HapticButton onClick={onBack} variant="secondary" size="lg" className="flex-1">
            Back
          </HapticButton>
        )}
        <HapticButton 
          onClick={onNext} 
          disabled={!isValid} 
          size="lg" 
          className="flex-1"
        >
          Continue
        </HapticButton>
      </div>
    </div>
  );
}

function CompleteStep({ onNext }: OnboardingStepProps) {
  const { celebration } = useHaptic();
  const { playSound } = useAudio();
  
  React.useEffect(() => {
    celebration();
    playSound('success');
  }, [celebration, playSound]);
  
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] px-6 text-center">
      <div className="w-24 h-24 mb-8 flex items-center justify-center bg-primary rounded-full animate-bounce-in">
        <Check className="w-12 h-12 text-white" strokeWidth={2} />
      </div>
      <h1 className="text-h1 mb-4">You are all set!</h1>
      <p className="text-body-lg text-muted-foreground mb-8 max-w-sm">
        Your personalized fitness journey begins now. Let us start crushing those goals.
      </p>
      <HapticButton onClick={onNext} size="lg" className="w-full max-w-xs">
        Start Training
      </HapticButton>
    </div>
  );
}

interface OnboardingFlowProps {
  onComplete: (profile: { name: string; goals: FitnessGoal[]; preferredDays: DayOfWeek[]; equipment: Equipment[] }) => void;
}

export function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  const [step, setStep] = useState(0);
  const [name, setName] = useState('');
  const [goals, setGoals] = useState<FitnessGoal[]>([]);
  const [preferredDays, setPreferredDays] = useState<DayOfWeek[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  
  const totalSteps = 5;
  
  const handleNext = () => {
    if (step < totalSteps - 1) {
      setStep(step + 1);
    } else {
      onComplete({
        name,
        goals,
        preferredDays,
        equipment,
      });
    }
  };
  
  const handleBack = () => {
    if (step > 0) {
      setStep(step - 1);
    }
  };
  
  const renderStep = () => {
    switch (step) {
      case 0:
        return <WelcomeStep onNext={handleNext} />;
      case 1:
        return (
          <NameStep 
            onNext={handleNext} 
            onBack={handleBack} 
            data={name} 
            setData={setName} 
          />
        );
      case 2:
        return (
          <GoalsStep 
            onNext={handleNext} 
            onBack={handleBack} 
            data={goals} 
            setData={setGoals} 
          />
        );
      case 3:
        return (
          <DaysStep 
            onNext={handleNext} 
            onBack={handleBack} 
            data={preferredDays} 
            setData={setPreferredDays} 
          />
        );
      case 4:
        return (
          <EquipmentStep 
            onNext={handleNext} 
            onBack={handleBack} 
            data={equipment} 
            setData={setEquipment} 
          />
        );
      case 5:
        return <CompleteStep onNext={handleNext} />;
      default:
        return null;
    }
  };
  
  return (
    <div className="flex flex-col h-full">
      {/* Progress indicator */}
      {step > 0 && step < totalSteps && (
        <div className="px-6 pt-6">
          <div className="flex gap-2">
            {Array.from({ length: totalSteps - 1 }).map((_, i) => (
              <div
                key={i}
                className={cn(
                  'h-1 flex-1 rounded-full transition-colors',
                  i < step ? 'bg-primary' : 'bg-border'
                )}
              />
            ))}
          </div>
        </div>
      )}
      
      {/* Step content */}
      <div className="flex-1 overflow-auto">
        {renderStep()}
      </div>
    </div>
  );
}
