'use client';

import * as React from 'react';
import { useMemo } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { cn } from '@/lib/utils';
import { getAchievementProgress } from '@/lib/milestones';
import type { Achievement } from '@/types';
import { 
  Trophy, Flame, Zap, Medal, Crown, MapPin, Mountain, Star, Rocket,
  Lock, CheckCircle
} from 'lucide-react';

const ACHIEVEMENT_ICONS: Record<string, React.ElementType> = {
  trophy: Trophy,
  flame: Flame,
  zap: Zap,
  medal: Medal,
  crown: Crown,
  'map-pin': MapPin,
  mountain: Mountain,
  star: Star,
  rocket: Rocket,
};

const TIER_COLORS = {
  bronze: 'from-orange-600 to-orange-800',
  silver: 'from-gray-400 to-gray-600',
  gold: 'from-yellow-500 to-yellow-700',
  platinum: 'from-cyan-400 to-cyan-600',
};

export function AchievementsDisplay() {
  const { achievements, streak, workouts, routes } = useAppStore();
  
  // Use useMemo instead of useEffect + useState
  const displayAchievements = useMemo(() => {
    const state = { workouts, routes, streak, achievements };
    return achievements.map(a => ({
      ...a,
      progress: getAchievementProgress(a, state),
    }));
  }, [achievements, workouts, routes, streak]);
  
  const unlockedCount = displayAchievements.filter(a => a.unlockedAt).length;
  const totalCount = displayAchievements.length;
  
  // Group by tier
  const byTier = displayAchievements.reduce((acc, a) => {
    if (!acc[a.tier]) acc[a.tier] = [];
    acc[a.tier].push(a);
    return acc;
  }, {} as Record<string, Achievement[]>);
  
  return (
    <div className="flex flex-col h-full">
      {/* Stats header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-h2">Achievements</h2>
            <p className="text-small text-muted-foreground">
              {unlockedCount} of {totalCount} unlocked
            </p>
          </div>
          <div className="flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-xl">
            <Flame className="w-5 h-5 text-primary" />
            <span className="text-xl font-bold text-primary">{streak.currentStreak}</span>
            <span className="text-small text-muted-foreground">day streak</span>
          </div>
        </div>
        
        {/* Overall progress */}
        <div className="h-2 bg-secondary rounded-full overflow-hidden">
          <div
            className="h-full bg-primary transition-all duration-500"
            style={{ width: `${(unlockedCount / totalCount) * 100}%` }}
          />
        </div>
      </div>
      
      {/* Achievements list */}
      <div className="flex-1 overflow-y-auto px-4 py-4">
        {(['bronze', 'silver', 'gold', 'platinum'] as const).map((tier) => {
          const tierAchievements = byTier[tier] || [];
          if (tierAchievements.length === 0) return null;
          
          return (
            <div key={tier} className="mb-6">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-3 capitalize">
                {tier} Tier
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {tierAchievements.map((achievement) => (
                  <AchievementCard key={achievement.id} achievement={achievement} />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

interface AchievementCardProps {
  achievement: Achievement;
}

function AchievementCard({ achievement }: AchievementCardProps) {
  const isUnlocked = !!achievement.unlockedAt;
  const Icon = ACHIEVEMENT_ICONS[achievement.icon] || Trophy;
  const progress = Math.min(achievement.progress / achievement.target, 1);
  
  return (
    <div
      className={cn(
        'relative bg-card border border-border rounded-xl p-4 transition-all',
        isUnlocked ? 'border-primary/50' : 'opacity-75'
      )}
    >
      {/* Icon */}
      <div
        className={cn(
          'w-12 h-12 flex items-center justify-center rounded-full mb-3 mx-auto',
          isUnlocked
            ? `bg-gradient-to-br ${TIER_COLORS[achievement.tier]}`
            : 'bg-secondary'
        )}
      >
        {isUnlocked ? (
          <Icon className="w-6 h-6 text-white" />
        ) : (
          <Lock className="w-5 h-5 text-muted-foreground" />
        )}
      </div>
      
      {/* Content */}
      <h4 className="font-semibold text-sm text-center mb-1">{achievement.title}</h4>
      <p className="text-small text-muted-foreground text-center mb-2">
        {achievement.description}
      </p>
      
      {/* Progress bar */}
      {!isUnlocked && (
        <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
          <div
            className="h-full bg-primary transition-all duration-300"
            style={{ width: `${progress * 100}%` }}
          />
        </div>
      )}
      
      {/* Status */}
      <div className="flex items-center justify-center mt-2">
        {isUnlocked ? (
          <div className="flex items-center gap-1 text-primary">
            <CheckCircle className="w-4 h-4" />
            <span className="text-small font-medium">Unlocked</span>
          </div>
        ) : (
          <span className="text-small text-muted-foreground">
            {achievement.progress} / {achievement.target}
          </span>
        )}
      </div>
    </div>
  );
}

export function StreakCounter() {
  const { streak } = useAppStore();
  
  const today = new Date().getDay();
  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Flame className="w-6 h-6 text-primary" />
          <span className="text-xl font-bold">{streak.currentStreak}</span>
          <span className="text-small text-muted-foreground">day streak</span>
        </div>
        <div className="text-small text-muted-foreground">
          Best: {streak.longestStreak}
        </div>
      </div>
      
      {/* Weekly activity */}
      <div className="flex justify-between">
        {weekDays.map((day, i) => (
          <div
            key={day}
            className={cn(
              'flex flex-col items-center',
              i === today && 'text-primary'
            )}
          >
            <span className="text-xs text-muted-foreground mb-1">{day}</span>
            <div
              className={cn(
                'w-8 h-8 flex items-center justify-center rounded-full',
                streak.weeklyActivity[i]
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-muted-foreground'
              )}
            >
              {streak.weeklyActivity[i] ? (
                <CheckCircle className="w-4 h-4" />
              ) : (
                <span className="text-xs">{i === today ? '!' : ''}</span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
