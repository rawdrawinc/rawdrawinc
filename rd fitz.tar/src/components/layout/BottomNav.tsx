'use client';

import * as React from 'react';
import { useAppStore } from '@/store/useAppStore';
import { useHaptic } from '@/hooks/useHaptic';
import { cn } from '@/lib/utils';
import type { TabName } from '@/types';
import { 
  Calendar, 
  Dumbbell, 
  Map, 
  Utensils, 
  BookOpen, 
  Trophy, 
  User 
} from 'lucide-react';

interface NavItem {
  id: TabName;
  label: string;
  icon: React.ElementType;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'planner', label: 'Planner', icon: Calendar },
  { id: 'workouts', label: 'Workouts', icon: Dumbbell },
  { id: 'tracking', label: 'Track', icon: Map },
  { id: 'nutrition', label: 'Nutrition', icon: Utensils },
  { id: 'journal', label: 'Journal', icon: BookOpen },
  { id: 'achievements', label: 'Awards', icon: Trophy },
];

export function BottomNav() {
  const { currentTab, setCurrentTab, streak } = useAppStore();
  const { light } = useHaptic();
  
  const handleTabChange = (tab: TabName) => {
    light();
    setCurrentTab(tab);
  };
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background border-t border-border safe-area-bottom z-50">
      <div className="flex justify-around items-center h-16 max-w-lg mx-auto px-1">
        {NAV_ITEMS.slice(0, 5).map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => handleTabChange(item.id)}
              className={cn(
                'flex flex-col items-center justify-center py-2 px-3 min-w-[48px] touch-target',
                'transition-colors duration-200'
              )}
            >
              <div className="relative">
                <Icon
                  className={cn(
                    'w-6 h-6 transition-colors',
                    isActive ? 'text-primary' : 'text-muted-foreground'
                  )}
                  strokeWidth={isActive ? 2.5 : 2}
                />
                {item.id === 'achievements' && streak.currentStreak > 0 && (
                  <span className="absolute -top-1 -right-2 min-w-[16px] h-4 flex items-center justify-center bg-primary text-white text-[10px] font-bold rounded-full px-1">
                    {streak.currentStreak}
                  </span>
                )}
              </div>
              <span
                className={cn(
                  'text-[10px] mt-1 transition-colors',
                  isActive ? 'text-primary font-medium' : 'text-muted-foreground'
                )}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

export function Header() {
  const { profile, streak, currentTab } = useAppStore();
  
  const getTabTitle = () => {
    switch (currentTab) {
      case 'planner':
        return 'Schedule';
      case 'workouts':
        return 'Exercises';
      case 'tracking':
        return 'GPS Tracking';
      case 'nutrition':
        return 'Nutrition';
      case 'journal':
        return 'Journal';
      case 'achievements':
        return 'Achievements';
      case 'profile':
        return 'Profile';
      default:
        return 'RD FITZ';
    }
  };
  
  return (
    <header className="sticky top-0 left-0 right-0 bg-background border-b border-border safe-area-top z-40">
      <div className="flex items-center justify-between h-14 px-4 max-w-lg mx-auto">
        <div className="flex items-center gap-3">
          <h1 className="text-h2">{getTabTitle()}</h1>
        </div>
        <div className="flex items-center gap-3">
          {streak.currentStreak > 0 && (
            <div className="flex items-center gap-1.5 bg-primary/10 px-3 py-1.5 rounded-full">
              <span className="text-lg">🔥</span>
              <span className="text-sm font-semibold text-primary">{streak.currentStreak}</span>
            </div>
          )}
          {profile && (
            <button 
              onClick={() => useAppStore.getState().setCurrentTab('profile')}
              className="w-9 h-9 flex items-center justify-center bg-primary/10 rounded-full"
            >
              <span className="text-sm font-semibold text-primary">
                {profile.name.charAt(0).toUpperCase()}
              </span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
