'use client';

import * as React from 'react';
import { useState, useMemo } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { HapticButton } from '@/components/common/HapticButton';
import { cn } from '@/lib/utils';
import type { JournalEntry } from '@/types';
import { Plus, X, Calendar, Search, ChevronRight, Smile, Meh, Frown } from 'lucide-react';
import { format, isToday, isYesterday, isThisWeek, parseISO } from 'date-fns';

const MOOD_ICONS = {
  great: { icon: '😊', label: 'Great' },
  good: { icon: '🙂', label: 'Good' },
  okay: { icon: '😐', label: 'Okay' },
  bad: { icon: '😔', label: 'Bad' },
  terrible: { icon: '😢', label: 'Terrible' },
};

function formatDateLabel(dateStr: string): string {
  const date = parseISO(dateStr);
  if (isToday(date)) return 'Today';
  if (isYesterday(date)) return 'Yesterday';
  if (isThisWeek(date)) return format(date, 'EEEE');
  return format(date, 'MMM d, yyyy');
}

export function NotesJournal() {
  const { journalEntries, addJournalEntry, updateJournalEntry } = useAppStore();
  const [search, setSearch] = useState('');
  const [showEditor, setShowEditor] = useState(false);
  const [editingEntry, setEditingEntry] = useState<JournalEntry | null>(null);
  
  // Sort entries by date using useMemo
  const entries = useMemo(() => {
    return [...journalEntries].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  }, [journalEntries]);
  
  // Filter entries by search
  const filteredEntries = search
    ? entries.filter(
        e =>
          e.title?.toLowerCase().includes(search.toLowerCase()) ||
          e.content.toLowerCase().includes(search.toLowerCase()) ||
          e.tags.some(t => t.toLowerCase().includes(search.toLowerCase()))
      )
    : entries;
  
  // Group entries by date
  const groupedEntries = filteredEntries.reduce((acc, entry) => {
    const dateKey = entry.date.split('T')[0];
    if (!acc[dateKey]) acc[dateKey] = [];
    acc[dateKey].push(entry);
    return acc;
  }, {} as Record<string, JournalEntry[]>);
  
  const handleNewEntry = () => {
    setEditingEntry(null);
    setShowEditor(true);
  };
  
  const handleEditEntry = (entry: JournalEntry) => {
    setEditingEntry(entry);
    setShowEditor(true);
  };
  
  const handleSaveEntry = (entry: Partial<JournalEntry>) => {
    const now = new Date().toISOString();
    const today = now.split('T')[0];
    
    if (editingEntry) {
      updateJournalEntry({
        ...editingEntry,
        ...entry,
        updatedAt: now,
      });
    } else {
      addJournalEntry({
        id: `journal-${Date.now()}`,
        date: entry.date || today,
        title: entry.title,
        content: entry.content || '',
        mood: entry.mood,
        tags: entry.tags || [],
        createdAt: now,
        updatedAt: now,
      });
    }
    
    setShowEditor(false);
    setEditingEntry(null);
  };
  
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search entries..."
              className="w-full pl-10 py-2.5 bg-secondary rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <HapticButton onClick={handleNewEntry} size="sm">
            <Plus className="w-5 h-5" />
          </HapticButton>
        </div>
      </div>
      
      {/* Entries list */}
      <div className="flex-1 overflow-y-auto px-4 py-4">
        {Object.keys(groupedEntries).length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            {search ? 'No entries found' : 'No journal entries yet'}
          </div>
        ) : (
          Object.entries(groupedEntries).map(([date, dateEntries]) => (
            <div key={date} className="mb-6">
              <h3 className="text-sm font-semibold text-muted-foreground mb-3">
                {formatDateLabel(date)}
              </h3>
              <div className="space-y-2">
                {dateEntries.map((entry) => (
                  <JournalEntryCard
                    key={entry.id}
                    entry={entry}
                    onClick={() => handleEditEntry(entry)}
                  />
                ))}
              </div>
            </div>
          ))
        )}
      </div>
      
      {/* Editor modal */}
      {showEditor && (
        <JournalEditor
          entry={editingEntry}
          onSave={handleSaveEntry}
          onClose={() => {
            setShowEditor(false);
            setEditingEntry(null);
          }}
        />
      )}
    </div>
  );
}

interface JournalEntryCardProps {
  entry: JournalEntry;
  onClick: () => void;
}

function JournalEntryCard({ entry, onClick }: JournalEntryCardProps) {
  const moodInfo = entry.mood ? MOOD_ICONS[entry.mood] : null;
  
  return (
    <button
      onClick={onClick}
      className="w-full bg-card border border-border rounded-xl p-4 text-left hover:border-primary/50 transition-colors"
    >
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          {moodInfo && (
            <span className="text-lg">{moodInfo.icon}</span>
          )}
          {entry.title && (
            <h4 className="font-medium">{entry.title}</h4>
          )}
        </div>
        <ChevronRight className="w-5 h-5 text-muted-foreground" />
      </div>
      <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
        {entry.content}
      </p>
      {entry.tags.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {entry.tags.slice(0, 3).map((tag) => (
            <span
              key={tag}
              className="text-xs bg-secondary text-secondary-foreground px-2 py-0.5 rounded"
            >
              {tag}
            </span>
          ))}
          {entry.tags.length > 3 && (
            <span className="text-xs text-muted-foreground">
              +{entry.tags.length - 3}
            </span>
          )}
        </div>
      )}
    </button>
  );
}

interface JournalEditorProps {
  entry: JournalEntry | null;
  onSave: (entry: Partial<JournalEntry>) => void;
  onClose: () => void;
}

function JournalEditor({ entry, onSave, onClose }: JournalEditorProps) {
  const [title, setTitle] = useState(entry?.title || '');
  const [content, setContent] = useState(entry?.content || '');
  const [mood, setMood] = useState<JournalEntry['mood']>(entry?.mood);
  const [tags, setTags] = useState<string[]>(entry?.tags || []);
  const [newTag, setNewTag] = useState('');
  
  const handleSave = () => {
    if (!content.trim()) return;
    
    onSave({
      title: title.trim() || undefined,
      content: content.trim(),
      mood,
      tags,
    });
  };
  
  const handleAddTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags([...tags, newTag.trim()]);
      setNewTag('');
    }
  };
  
  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter(t => t !== tag));
  };
  
  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <button onClick={onClose} className="text-muted-foreground">
          <X className="w-6 h-6" />
        </button>
        <h2 className="font-semibold">
          {entry ? 'Edit Entry' : 'New Entry'}
        </h2>
        <HapticButton onClick={handleSave} size="sm" disabled={!content.trim()}>
          Save
        </HapticButton>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4">
        {/* Mood selector */}
        <div className="mb-6">
          <label className="text-sm font-medium text-muted-foreground mb-2 block">
            How are you feeling?
          </label>
          <div className="flex gap-2">
            {(Object.keys(MOOD_ICONS) as JournalEntry['mood'][]).map((m) => (
              <button
                key={m}
                onClick={() => setMood(mood === m ? undefined : m)}
                className={cn(
                  'flex-1 py-3 rounded-xl text-2xl transition-all',
                  mood === m
                    ? 'bg-primary/20 ring-2 ring-primary'
                    : 'bg-secondary hover:bg-secondary/80'
                )}
              >
                {MOOD_ICONS[m].icon}
              </button>
            ))}
          </div>
        </div>
        
        {/* Title */}
        <div className="mb-4">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Title (optional)"
            className="w-full px-4 py-3 bg-secondary rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        
        {/* Content */}
        <div className="mb-4">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Write your thoughts..."
            className="w-full px-4 py-3 bg-secondary rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary min-h-[200px] resize-none"
          />
        </div>
        
        {/* Tags */}
        <div className="mb-4">
          <label className="text-sm font-medium text-muted-foreground mb-2 block">
            Tags
          </label>
          <div className="flex flex-wrap gap-2 mb-2">
            {tags.map((tag) => (
              <span
                key={tag}
                className="flex items-center gap-1 text-sm bg-primary/10 text-primary px-3 py-1 rounded-full"
              >
                {tag}
                <button onClick={() => handleRemoveTag(tag)}>
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              value={newTag}
              onChange={(e) => setNewTag(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
              placeholder="Add tag..."
              className="flex-1 px-4 py-2 bg-secondary rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <HapticButton onClick={handleAddTag} variant="secondary" size="sm">
              Add
            </HapticButton>
          </div>
        </div>
      </div>
    </div>
  );
}
