'use client';

import * as React from 'react';
import { useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { HapticButton } from '@/components/common/HapticButton';
import { cn } from '@/lib/utils';
import type { Workout, WorkoutType } from '@/types';
import { Plus, Dumbbell, Flame, Heart, Zap, Clock, MoreVertical, Check, Play, Target } from 'lucide-react';
import { format, startOfWeek, addDays, isToday, isSameDay } from 'date-fns';

const WORKOUT_TYPE_COLORS: Record<WorkoutType, string> = {
  push: 'bg-blue-500',
  pull: 'bg-purple-500',
  legs: 'bg-orange-500',
  full_body: 'bg-primary',
  cardio: 'bg-red-500',
  rest: 'bg-gray-400',
  custom: 'bg-cyan-500',
};

const WORKOUT_TYPE_ICONS: Record<WorkoutType, React.ElementType> = {
  push: Dumbbell,
  pull: Dumbbell,
  legs: Dumbbell,
  full_body: Zap,
  cardio: Heart,
  rest: null,
  custom: Dumbbell,
};

interface WeeklyCalendarProps {
  onSelectDay?: (date: Date) => void;
}

export function WeeklyCalendar({ onSelectDay }: WeeklyCalendarProps) {
  const { workouts } = useAppStore();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
  
  const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  
  const getWorkoutForDay = (date: Date): Workout | undefined => {
    return workouts.find(w => isSameDay(new Date(w.date), date));
  };
  
  const handleDaySelect = (date: Date) => {
    setSelectedDate(date);
    onSelectDay?.(date);
  };
  
  return (
    <div className="px-4 py-3">
      <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-2">
        {days.map((day) => {
          const workout = getWorkoutForDay(day);
          const isSelected = isSameDay(day, selectedDate);
          const today = isToday(day);
          
          return (
            <button
              key={day.toISOString()}
              onClick={() => handleDaySelect(day)}
              className={cn(
                'flex flex-col items-center min-w-[52px] py-2 px-2 rounded-xl transition-all',
                'touch-target',
                isSelected ? 'bg-primary text-white' : 'bg-card border border-border',
                today && !isSelected && 'border-primary'
              )}
            >
              <span className={cn(
                'text-[10px] font-medium uppercase',
                isSelected ? 'text-white/80' : 'text-muted-foreground'
              )}>
                {format(day, 'EEE')}
              </span>
              <span className={cn(
                'text-lg font-semibold mt-0.5',
                isSelected ? 'text-white' : ''
              )}>
                {format(day, 'd')}
              </span>
              {workout && (
                <div className={cn(
                  'w-2 h-2 rounded-full mt-1',
                  WORKOUT_TYPE_COLORS[workout.type]
                )} />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

interface WorkoutCardProps {
  workout: Workout;
  onStart: () => void;
  onComplete?: () => void;
  onEdit?: () => void;
}

export function WorkoutCard({ workout, onStart, onComplete, onEdit }: WorkoutCardProps) {
  const Icon = WORKOUT_TYPE_ICONS[workout.type] || Dumbbell;
  const totalSets = workout.exercises.reduce((sum, ex) => sum + ex.sets.length, 0);
  
  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      {/* Header */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className={cn(
              'w-12 h-12 flex items-center justify-center rounded-xl',
              WORKOUT_TYPE_COLORS[workout.type]
            )}>
              {Icon && <Icon className="w-6 h-6 text-white" />}
            </div>
            <div>
              <h3 className="font-bold text-lg">{workout.name}</h3>
              <p className="text-sm text-muted-foreground capitalize">{workout.type.replace('_', ' ')}</p>
            </div>
          </div>
          {onEdit && (
            <button className="p-2 text-muted-foreground hover:text-foreground">
              <MoreVertical className="w-5 h-5" />
            </button>
          )}
        </div>
        
        {/* Stats */}
        <div className="flex items-center gap-4 mb-4">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span className="text-sm font-medium">{workout.duration} min</span>
          </div>
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Dumbbell className="w-4 h-4" />
            <span className="text-sm font-medium">{workout.exercises.length} exercises</span>
          </div>
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Target className="w-4 h-4" />
            <span className="text-sm font-medium">{totalSets} sets</span>
          </div>
        </div>
        
        {/* Exercise preview */}
        {workout.exercises.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {workout.exercises.slice(0, 4).map((ex, i) => (
              <span key={i} className="text-xs bg-secondary text-secondary-foreground px-2 py-1 rounded-md">
                {ex.exerciseName || 'Exercise'}
              </span>
            ))}
            {workout.exercises.length > 4 && (
              <span className="text-xs text-muted-foreground">+{workout.exercises.length - 4} more</span>
            )}
          </div>
        )}
      </div>
      
      {/* Action buttons */}
      <div className="px-4 pb-4">
        {workout.completed ? (
          <div className="flex items-center justify-center gap-2 py-3 bg-primary/10 text-primary rounded-xl">
            <Check className="w-5 h-5" />
            <span className="font-semibold">Completed Today</span>
          </div>
        ) : (
          <HapticButton 
            onClick={onStart} 
            className="w-full h-12"
            size="lg"
          >
            <Play className="w-5 h-5 mr-2" />
            Start Workout
          </HapticButton>
        )}
      </div>
    </div>
  );
}

interface QuickAddWorkoutProps {
  date: Date;
  onAdd: (type: WorkoutType) => void;
  onClose: () => void;
}

export function QuickAddWorkout({ date, onAdd, onClose }: QuickAddWorkoutProps) {
  const types: { type: WorkoutType; label: string }[] = [
    { type: 'push', label: 'Push' },
    { type: 'pull', label: 'Pull' },
    { type: 'legs', label: 'Legs' },
    { type: 'full_body', label: 'Full Body' },
    { type: 'cardio', label: 'Cardio' },
    { type: 'rest', label: 'Rest Day' },
  ];
  
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end" onClick={onClose}>
      <div 
        className="bg-background w-full rounded-t-2xl p-6 animate-slide-up"
        onClick={e => e.stopPropagation()}
      >
        <div className="w-12 h-1 bg-border rounded-full mx-auto mb-4" />
        <h2 className="text-xl font-bold mb-4">Add Workout for {format(date, 'MMM d')}</h2>
        <div className="grid grid-cols-2 gap-3">
          {types.map(({ type, label }) => (
            <HapticButton
              key={type}
              onClick={() => onAdd(type)}
              variant="secondary"
              className="h-16"
            >
              <div className={cn('w-3 h-3 rounded-full mr-2', WORKOUT_TYPE_COLORS[type])} />
              {label}
            </HapticButton>
          ))}
        </div>
        <HapticButton onClick={onClose} variant="ghost" className="w-full mt-4">
          Cancel
        </HapticButton>
      </div>
    </div>
  );
}
