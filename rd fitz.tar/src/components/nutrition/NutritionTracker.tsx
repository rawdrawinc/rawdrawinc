'use client';

import * as React from 'react';
import { useState, useEffect } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { HapticButton } from '@/components/common/HapticButton';
import { cn } from '@/lib/utils';
import type { FoodEntry, MealType } from '@/types';
import { Search, X, Plus, Trash2, Utensils, Coffee, Apple, Cookie } from 'lucide-react';

const MEAL_ICONS: Record<MealType, React.ElementType> = {
  breakfast: Coffee,
  lunch: Apple,
  dinner: Utensils,
  snack: Cookie,
};

const DEFAULT_TARGETS = {
  calories: 2000,
  protein: 150,
  carbs: 250,
  fat: 65,
};

export function NutritionTracker() {
  const { foodEntries, addFoodEntry, settings } = useAppStore();
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState<FoodEntry[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedMeal, setSelectedMeal] = useState<MealType>('breakfast');
  const [showAddModal, setShowAddModal] = useState(false);
  const [todayEntries, setTodayEntries] = useState<FoodEntry[]>([]);
  
  const today = new Date().toISOString().split('T')[0];
  
  // Filter today's entries
  useEffect(() => {
    const todayFoods = foodEntries.filter(entry => entry.date === today);
    setTodayEntries(todayFoods);
  }, [foodEntries, today]);
  
  // Calculate totals
  const totals = todayEntries.reduce(
    (acc, entry) => ({
      calories: acc.calories + entry.calories,
      protein: acc.protein + entry.protein,
      carbs: acc.carbs + entry.carbs,
      fat: acc.fat + entry.fat,
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );
  
  // Search food
  const handleSearch = async (query: string) => {
    setSearch(query);
    if (query.length < 2) {
      setSearchResults([]);
      return;
    }
    
    setIsSearching(true);
    try {
      const response = await fetch(`/api/food?search=${encodeURIComponent(query)}`);
      if (response.ok) {
        const data = await response.json();
        setSearchResults(data.results.slice(0, 10));
      }
    } catch (error) {
      console.error('Food search error:', error);
    } finally {
      setIsSearching(false);
    }
  };
  
  // Add food to log
  const handleAddFood = (food: Partial<FoodEntry> & { name: string }) => {
    const entry: FoodEntry = {
      id: `food-${Date.now()}`,
      name: food.name,
      barcode: food.barcode,
      calories: food.calories || 0,
      protein: food.protein || 0,
      carbs: food.carbs || 0,
      fat: food.fat || 0,
      fiber: food.fiber,
      sugar: food.sugar,
      sodium: food.sodium,
      servingSize: food.servingSize || 100,
      servingUnit: food.servingUnit || 'g',
      date: today,
      meal: selectedMeal,
      createdAt: new Date().toISOString(),
    };
    
    addFoodEntry(entry);
    setShowAddModal(false);
    setSearch('');
    setSearchResults([]);
  };
  
  return (
    <div className="flex flex-col h-full">
      {/* Macro overview */}
      <div className="p-4 border-b border-border">
        <MacroProgress 
          label="Calories" 
          current={totals.calories} 
          target={DEFAULT_TARGETS.calories}
          unit="kcal"
          color="bg-primary"
        />
        <div className="grid grid-cols-3 gap-4 mt-4">
          <MacroProgress 
            label="Protein" 
            current={totals.protein} 
            target={DEFAULT_TARGETS.protein}
            unit="g"
            color="bg-blue-500"
            compact
          />
          <MacroProgress 
            label="Carbs" 
            current={totals.carbs} 
            target={DEFAULT_TARGETS.carbs}
            unit="g"
            color="bg-yellow-500"
            compact
          />
          <MacroProgress 
            label="Fat" 
            current={totals.fat} 
            target={DEFAULT_TARGETS.fat}
            unit="g"
            color="bg-red-500"
            compact
          />
        </div>
      </div>
      
      {/* Add food button */}
      <div className="p-4">
        <HapticButton
          onClick={() => setShowAddModal(true)}
          className="w-full"
        >
          <Plus className="w-4 h-4 mr-2" />
          Log Food
        </HapticButton>
      </div>
      
      {/* Today's entries by meal */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {(['breakfast', 'lunch', 'dinner', 'snack'] as MealType[]).map((meal) => {
          const mealEntries = todayEntries.filter(e => e.meal === meal);
          const Icon = MEAL_ICONS[meal];
          
          return (
            <div key={meal} className="mb-4">
              <div className="flex items-center gap-2 mb-2">
                <Icon className="w-4 h-4 text-muted-foreground" />
                <h3 className="text-sm font-semibold text-muted-foreground uppercase capitalize">
                  {meal}
                </h3>
                {mealEntries.length > 0 && (
                  <span className="text-small text-muted-foreground">
                    {mealEntries.reduce((sum, e) => sum + e.calories, 0)} kcal
                  </span>
                )}
              </div>
              
              {mealEntries.length === 0 ? (
                <p className="text-small text-muted-foreground pl-6">No entries</p>
              ) : (
                <div className="space-y-2">
                  {mealEntries.map((entry) => (
                    <FoodEntryCard key={entry.id} entry={entry} />
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
      
      {/* Add food modal */}
      {showAddModal && (
        <AddFoodModal
          search={search}
          onSearch={handleSearch}
          searchResults={searchResults}
          isSearching={isSearching}
          selectedMeal={selectedMeal}
          onSelectMeal={setSelectedMeal}
          onAddFood={handleAddFood}
          onClose={() => {
            setShowAddModal(false);
            setSearch('');
            setSearchResults([]);
          }}
        />
      )}
    </div>
  );
}

interface MacroProgressProps {
  label: string;
  current: number;
  target: number;
  unit: string;
  color: string;
  compact?: boolean;
}

function MacroProgress({ label, current, target, unit, color, compact }: MacroProgressProps) {
  const percentage = Math.min((current / target) * 100, 100);
  
  return (
    <div className={compact ? '' : 'mb-2'}>
      <div className="flex justify-between items-center mb-1">
        <span className={compact ? 'text-small text-muted-foreground' : 'text-sm font-medium'}>{label}</span>
        <span className={compact ? 'text-small' : 'text-sm'}>
          {Math.round(current)} / {target} {unit}
        </span>
      </div>
      <div className="h-2 bg-secondary rounded-full overflow-hidden">
        <div
          className={cn('h-full rounded-full transition-all duration-300', color)}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}

interface FoodEntryCardProps {
  entry: FoodEntry;
}

function FoodEntryCard({ entry }: FoodEntryCardProps) {
  return (
    <div className="flex items-center justify-between bg-card border border-border rounded-lg p-3">
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">{entry.name}</p>
        <p className="text-small text-muted-foreground">
          {entry.servingSize}{entry.servingUnit}
        </p>
      </div>
      <div className="text-right">
        <p className="font-medium text-sm">{entry.calories} kcal</p>
        <p className="text-small text-muted-foreground">
          P: {entry.protein}g | C: {entry.carbs}g | F: {entry.fat}g
        </p>
      </div>
    </div>
  );
}

interface AddFoodModalProps {
  search: string;
  onSearch: (query: string) => void;
  searchResults: FoodEntry[];
  isSearching: boolean;
  selectedMeal: MealType;
  onSelectMeal: (meal: MealType) => void;
  onAddFood: (food: Partial<FoodEntry> & { name: string }) => void;
  onClose: () => void;
}

function AddFoodModal({
  search,
  onSearch,
  searchResults,
  isSearching,
  selectedMeal,
  onSelectMeal,
  onAddFood,
  onClose,
}: AddFoodModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
      <div 
        className="bg-background w-full max-h-[80vh] rounded-t-2xl animate-slide-up"
        onClick={e => e.stopPropagation()}
      >
        <div className="p-4 border-b border-border">
          <div className="w-12 h-1 bg-border rounded-full mx-auto mb-4" />
          <div className="flex items-center gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                value={search}
                onChange={(e) => onSearch(e.target.value)}
                placeholder="Search food..."
                className="w-full pl-10 pr-10 py-3 bg-secondary rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                autoFocus
              />
              {search && (
                <button
                  onClick={() => onSearch('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                >
                  <X className="w-5 h-5 text-muted-foreground" />
                </button>
              )}
            </div>
            <button onClick={onClose} className="p-2">
              <X className="w-6 h-6 text-muted-foreground" />
            </button>
          </div>
          
          {/* Meal selector */}
          <div className="flex gap-2">
            {(['breakfast', 'lunch', 'dinner', 'snack'] as MealType[]).map((meal) => {
              const Icon = MEAL_ICONS[meal];
              return (
                <button
                  key={meal}
                  onClick={() => onSelectMeal(meal)}
                  className={cn(
                    'flex-1 py-2 rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-1',
                    selectedMeal === meal
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-secondary-foreground'
                  )}
                >
                  <Icon className="w-3 h-3" />
                  <span className="capitalize">{meal}</span>
                </button>
              );
            })}
          </div>
        </div>
        
        <div className="overflow-y-auto max-h-96 p-4">
          {isSearching ? (
            <div className="flex items-center justify-center py-8">
              <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            </div>
          ) : search.length < 2 ? (
            <p className="text-center text-muted-foreground py-8">
              Type at least 2 characters to search
            </p>
          ) : searchResults.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              No results found
            </p>
          ) : (
            <div className="space-y-2">
              {searchResults.map((food) => (
                <button
                  key={food.id}
                  onClick={() => onAddFood(food)}
                  className="w-full flex items-center justify-between bg-card border border-border rounded-lg p-3 hover:border-primary/50 transition-colors"
                >
                  <div className="text-left">
                    <p className="font-medium text-sm">{food.name}</p>
                    <p className="text-small text-muted-foreground">
                      {food.calories} kcal | P: {food.protein}g | C: {food.carbs}g | F: {food.fat}g
                    </p>
                  </div>
                  <Plus className="w-5 h-5 text-muted-foreground" />
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
