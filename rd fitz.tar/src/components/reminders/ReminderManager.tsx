'use client';

import * as React from 'react';
import { useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { HapticButton } from '@/components/common/HapticButton';
import { useNotifications } from '@/hooks/useNotifications';
import { cn } from '@/lib/utils';
import type { Reminder, DayOfWeek } from '@/types';
import { Plus, X, Bell, BellOff, Clock, Trash2, ChevronRight } from 'lucide-react';

const DAYS: { value: DayOfWeek; label: string }[] = [
  { value: 'monday', label: 'Mon' },
  { value: 'tuesday', label: 'Tue' },
  { value: 'wednesday', label: 'Wed' },
  { value: 'thursday', label: 'Thu' },
  { value: 'friday', label: 'Fri' },
  { value: 'saturday', label: 'Sat' },
  { value: 'sunday', label: 'Sun' },
];

export function ReminderManager() {
  const { reminders, addReminder, updateReminder, deleteReminder } = useAppStore();
  const { permissionState, requestPermission } = useNotifications();
  const [showEditor, setShowEditor] = useState(false);
  const [editingReminder, setEditingReminder] = useState<Reminder | null>(null);
  
  const handleNewReminder = () => {
    if (!permissionState.granted) {
      requestPermission();
    }
    setEditingReminder(null);
    setShowEditor(true);
  };
  
  const handleEditReminder = (reminder: Reminder) => {
    setEditingReminder(reminder);
    setShowEditor(true);
  };
  
  const handleSaveReminder = (reminder: Partial<Reminder>) => {
    const now = new Date().toISOString();
    
    if (editingReminder) {
      updateReminder({
        ...editingReminder,
        ...reminder,
      });
    } else {
      addReminder({
        id: `reminder-${Date.now()}`,
        title: reminder.title || 'Workout Reminder',
        message: reminder.message || 'Time for your workout!',
        time: reminder.time || '09:00',
        days: reminder.days || ['monday', 'wednesday', 'friday'],
        enabled: true,
        sound: true,
        vibration: true,
        createdAt: now,
      });
    }
    
    setShowEditor(false);
    setEditingReminder(null);
  };
  
  const handleToggleReminder = (reminder: Reminder) => {
    updateReminder({
      ...reminder,
      enabled: !reminder.enabled,
    });
  };
  
  return (
    <div className="flex flex-col h-full">
      {/* Permission warning */}
      {!permissionState.granted && (
        <div className="p-4 bg-warning/10 border-b border-warning/20">
          <div className="flex items-center gap-3">
            <BellOff className="w-5 h-5 text-warning" />
            <div className="flex-1">
              <p className="text-sm font-medium">Notifications disabled</p>
              <p className="text-small text-muted-foreground">
                Enable notifications to receive reminders
              </p>
            </div>
            <HapticButton onClick={requestPermission} size="sm">
              Enable
            </HapticButton>
          </div>
        </div>
      )}
      
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-h2">Reminders</h2>
            <p className="text-small text-muted-foreground">
              {reminders.filter(r => r.enabled).length} active
            </p>
          </div>
          <HapticButton onClick={handleNewReminder} size="sm">
            <Plus className="w-5 h-5" />
          </HapticButton>
        </div>
      </div>
      
      {/* Reminders list */}
      <div className="flex-1 overflow-y-auto px-4 py-4">
        {reminders.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Bell className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No reminders set</p>
            <p className="text-small mt-1">Create a reminder to stay on track</p>
          </div>
        ) : (
          <div className="space-y-3">
            {reminders.map((reminder) => (
              <ReminderCard
                key={reminder.id}
                reminder={reminder}
                onToggle={() => handleToggleReminder(reminder)}
                onEdit={() => handleEditReminder(reminder)}
                onDelete={() => deleteReminder(reminder.id)}
              />
            ))}
          </div>
        )}
      </div>
      
      {/* Editor modal */}
      {showEditor && (
        <ReminderEditor
          reminder={editingReminder}
          onSave={handleSaveReminder}
          onClose={() => {
            setShowEditor(false);
            setEditingReminder(null);
          }}
        />
      )}
    </div>
  );
}

interface ReminderCardProps {
  reminder: Reminder;
  onToggle: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

function ReminderCard({ reminder, onToggle, onEdit, onDelete }: ReminderCardProps) {
  return (
    <div
      className={cn(
        'bg-card border border-border rounded-xl p-4 transition-opacity',
        !reminder.enabled && 'opacity-60'
      )}
    >
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <Bell className={cn(
              'w-4 h-4',
              reminder.enabled ? 'text-primary' : 'text-muted-foreground'
            )} />
            <span className="font-medium">{reminder.title}</span>
          </div>
          <p className="text-small text-muted-foreground">{reminder.message}</p>
        </div>
        <button
          onClick={onToggle}
          className={cn(
            'w-12 h-6 rounded-full transition-colors',
            reminder.enabled ? 'bg-primary' : 'bg-secondary'
          )}
        >
          <div
            className={cn(
              'w-5 h-5 bg-white rounded-full shadow transition-transform',
              reminder.enabled ? 'translate-x-6' : 'translate-x-0.5'
            )}
          />
        </button>
      </div>
      
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span className="text-sm">{reminder.time}</span>
          </div>
          <div className="flex gap-1">
            {DAYS.map((day) => (
              <span
                key={day.value}
                className={cn(
                  'w-6 h-6 flex items-center justify-center rounded text-xs',
                  reminder.days.includes(day.value)
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-muted-foreground'
                )}
              >
                {day.label.charAt(0)}
              </span>
            ))}
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button onClick={onEdit} className="p-2 text-muted-foreground hover:text-foreground">
            <ChevronRight className="w-4 h-4" />
          </button>
          <button onClick={onDelete} className="p-2 text-muted-foreground hover:text-destructive">
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

interface ReminderEditorProps {
  reminder: Reminder | null;
  onSave: (reminder: Partial<Reminder>) => void;
  onClose: () => void;
}

function ReminderEditor({ reminder, onSave, onClose }: ReminderEditorProps) {
  const [title, setTitle] = useState(reminder?.title || 'Workout Reminder');
  const [message, setMessage] = useState(reminder?.message || 'Time for your workout!');
  const [time, setTime] = useState(reminder?.time || '09:00');
  const [days, setDays] = useState<DayOfWeek[]>(reminder?.days || ['monday', 'wednesday', 'friday']);
  
  const toggleDay = (day: DayOfWeek) => {
    if (days.includes(day)) {
      setDays(days.filter(d => d !== day));
    } else {
      setDays([...days, day]);
    }
  };
  
  const handleSave = () => {
    onSave({
      title,
      message,
      time,
      days,
    });
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
      <div className="bg-background w-full max-h-[80vh] rounded-t-2xl animate-slide-up">
        <div className="p-4 border-b border-border">
          <div className="w-12 h-1 bg-border rounded-full mx-auto mb-4" />
          <div className="flex items-center justify-between">
            <button onClick={onClose} className="text-muted-foreground">
              <X className="w-6 h-6" />
            </button>
            <h2 className="font-semibold">
              {reminder ? 'Edit Reminder' : 'New Reminder'}
            </h2>
            <HapticButton onClick={handleSave} size="sm">
              Save
            </HapticButton>
          </div>
        </div>
        
        <div className="p-4 space-y-6">
          {/* Title */}
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-3 bg-secondary rounded-xl text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          
          {/* Message */}
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Message
            </label>
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-4 py-3 bg-secondary rounded-xl text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          
          {/* Time */}
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Time
            </label>
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full px-4 py-3 bg-secondary rounded-xl text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          
          {/* Days */}
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Repeat on
            </label>
            <div className="flex gap-2">
              {DAYS.map((day) => (
                <button
                  key={day.value}
                  onClick={() => toggleDay(day.value)}
                  className={cn(
                    'flex-1 py-2 rounded-lg text-sm font-medium transition-colors',
                    days.includes(day.value)
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-secondary-foreground'
                  )}
                >
                  {day.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
