'use client';

import * as React from 'react';
import { useState, useEffect, useCallback } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { useGeolocation } from '@/hooks/useGeolocation';
import { useHaptic } from '@/hooks/useHaptic';
import { useAudio } from '@/hooks/useAudio';
import { HapticButton } from '@/components/common/HapticButton';
import { cn } from '@/lib/utils';
import type { Route, TrackingSession, Coordinate } from '@/types';
import { Play, Square, MapPin, Clock, Flame, Navigation, Pause, RotateCcw } from 'lucide-react';

// Format time as MM:SS
function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Format distance
function formatDistance(meters: number, units: 'metric' | 'imperial'): string {
  if (units === 'imperial') {
    const miles = meters * 0.000621371;
    return `${miles.toFixed(2)} mi`;
  }
  if (meters >= 1000) {
    return `${(meters / 1000).toFixed(2)} km`;
  }
  return `${Math.round(meters)} m`;
}

// Format pace
function formatPace(secondsPerKm: number, units: 'metric' | 'imperial'): string {
  if (secondsPerKm === 0) return '--:--';
  if (units === 'imperial') {
    const secondsPerMile = secondsPerKm * 1.60934;
    const mins = Math.floor(secondsPerMile / 60);
    const secs = Math.floor(secondsPerMile % 60);
    return `${mins}:${secs.toString().padStart(2, '0')} /mi`;
  }
  const mins = Math.floor(secondsPerKm / 60);
  const secs = Math.floor(secondsPerKm % 60);
  return `${mins}:${secs.toString().padStart(2, '0')} /km`;
}

export function GPSTracker() {
  const { settings, addRoute, routes } = useAppStore();
  const { 
    startTracking, 
    stopTracking, 
    isTracking, 
    currentPosition,
    calculateDistance,
    calculatePace,
    isLoading: geoLoading,
    error: geoError
  } = useGeolocation();
  const { success, error: errorVibrate } = useHaptic();
  const { playSound } = useAudio();
  
  const [session, setSession] = useState<TrackingSession | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [activityType, setActivityType] = useState<'run' | 'walk' | 'cycle' | 'hike'>('run');
  const [savedRoutes, setSavedRoutes] = useState<Route[]>([]);
  
  // Load saved routes
  useEffect(() => {
    setSavedRoutes(routes);
  }, [routes]);
  
  // Timer for tracking duration
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (session?.isActive) {
      interval = setInterval(() => {
        setElapsedTime(Math.floor((Date.now() - session.startTime) / 1000));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [session]);
  
  const handleStart = async () => {
    try {
      await startTracking(activityType);
      setSession({
        id: `session-${Date.now()}`,
        startTime: Date.now(),
        coordinates: [],
        isActive: true,
        type: activityType,
      });
      setElapsedTime(0);
      playSound('click');
    } catch (err) {
      errorVibrate();
      console.error('Failed to start tracking:', err);
    }
  };
  
  const handleStop = useCallback(() => {
    const completedSession = stopTracking();
    if (completedSession && completedSession.coordinates.length > 0) {
      const distance = calculateDistance(completedSession.coordinates);
      const pace = calculatePace(distance, Date.now() - completedSession.startTime);
      const calories = Math.round(distance * 0.0625); // Rough estimate
      
      const route: Route = {
        id: `route-${Date.now()}`,
        name: `${activityType.charAt(0).toUpperCase() + activityType.slice(1)} - ${new Date().toLocaleDateString()}`,
        type: activityType,
        coordinates: completedSession.coordinates,
        distance,
        duration: elapsedTime,
        pace,
        calories,
        date: new Date().toISOString(),
        startTime: new Date(completedSession.startTime).toISOString(),
        endTime: new Date().toISOString(),
      };
      
      addRoute(route);
      success();
      playSound('success');
    }
    
    setSession(null);
    setElapsedTime(0);
  }, [stopTracking, calculateDistance, calculatePace, elapsedTime, activityType, addRoute, success, playSound]);
  
  // Calculate current stats
  const currentDistance = session?.coordinates 
    ? calculateDistance(session.coordinates) 
    : 0;
  const currentPace = elapsedTime > 0 && currentDistance > 0
    ? calculatePace(currentDistance, elapsedTime * 1000)
    : 0;
  const estimatedCalories = Math.round(currentDistance * 0.0625);
  
  return (
    <div className="flex flex-col h-full">
      {/* Activity type selector */}
      {!isTracking && (
        <div className="px-4 py-3 border-b border-border">
          <div className="flex gap-2">
            {(['run', 'walk', 'cycle', 'hike'] as const).map((type) => (
              <button
                key={type}
                onClick={() => setActivityType(type)}
                className={cn(
                  'flex-1 py-2 px-3 rounded-lg text-sm font-medium transition-colors',
                  activityType === type
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-secondary-foreground'
                )}
              >
                {type.charAt(0).toUpperCase() + type.slice(1)}
              </button>
            ))}
          </div>
        </div>
      )}
      
      {/* Stats display */}
      <div className="p-4">
        {geoError && (
          <div className="bg-destructive/10 text-destructive p-3 rounded-lg mb-4">
            {geoError}
          </div>
        )}
        
        <div className="grid grid-cols-2 gap-4 mb-6">
          {/* Distance */}
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <MapPin className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="text-2xl font-bold">
              {formatDistance(currentDistance, settings.units)}
            </p>
            <p className="text-small text-muted-foreground">Distance</p>
          </div>
          
          {/* Duration */}
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <Clock className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="text-2xl font-bold">{formatTime(elapsedTime)}</p>
            <p className="text-small text-muted-foreground">Duration</p>
          </div>
          
          {/* Pace */}
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <Navigation className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="text-2xl font-bold">{formatPace(currentPace, settings.units)}</p>
            <p className="text-small text-muted-foreground">Pace</p>
          </div>
          
          {/* Calories */}
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <Flame className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="text-2xl font-bold">{estimatedCalories}</p>
            <p className="text-small text-muted-foreground">Calories</p>
          </div>
        </div>
        
        {/* Control buttons */}
        <div className="flex justify-center">
          {!isTracking ? (
            <HapticButton
              onClick={handleStart}
              disabled={geoLoading}
              className="w-20 h-20 rounded-full"
              size="lg"
              hapticStyle="medium"
            >
              <Play className="w-8 h-8" fill="currentColor" />
            </HapticButton>
          ) : (
            <HapticButton
              onClick={handleStop}
              variant="danger"
              className="w-20 h-20 rounded-full"
              size="lg"
              hapticStyle="heavy"
              soundType="success"
            >
              <Square className="w-8 h-8" fill="currentColor" />
            </HapticButton>
          )}
        </div>
      </div>
      
      {/* Route history */}
      {!isTracking && savedRoutes.length > 0 && (
        <div className="flex-1 overflow-y-auto px-4 pb-4">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
            Recent Activity
          </h3>
          <div className="space-y-3">
            {savedRoutes.slice(0, 5).map((route) => (
              <RouteCard key={route.id} route={route} units={settings.units} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

interface RouteCardProps {
  route: Route;
  units: 'metric' | 'imperial';
}

function RouteCard({ route, units }: RouteCardProps) {
  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="font-medium capitalize">{route.type}</span>
        <span className="text-small text-muted-foreground">
          {new Date(route.date).toLocaleDateString()}
        </span>
      </div>
      <div className="flex items-center gap-4 text-sm text-muted-foreground">
        <span>{formatDistance(route.distance, units)}</span>
        <span>{formatTime(route.duration)}</span>
        <span>{formatPace(route.pace, units)}</span>
        <span className="flex items-center gap-1">
          <Flame className="w-3 h-3" />
          {route.calories}
        </span>
      </div>
    </div>
  );
}
