'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { useHaptic } from '@/hooks/useHaptic';
import { useAudio } from '@/hooks/useAudio';
import { HapticButton } from '@/components/common/HapticButton';
import { cn } from '@/lib/utils';
import { getExerciseSVG } from '@/components/exercises/ExerciseSVGs';
import type { Workout, WorkoutExercise } from '@/types';
import { Play, Pause, SkipForward, RotateCcw, Check, ChevronLeft, Clock, Flame, Target, Volume2, VolumeX } from 'lucide-react';

interface ActiveWorkoutSessionProps {
  workout: Workout;
  onComplete: (workout: Workout) => void;
  onExit: () => void;
}

type WorkoutPhase = 'exercise' | 'rest' | 'complete';

const REST_TIME = 60;

export function ActiveWorkoutSession({ workout, onComplete, onExit }: ActiveWorkoutSessionProps) {
  const { updateStreak, unlockAchievement, achievements } = useAppStore();
  const { light, medium, celebration } = useHaptic();
  const { playSound } = useAudio();
  
  // Workout state
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [currentSetIndex, setCurrentSetIndex] = useState(0);
  const [phase, setPhase] = useState<WorkoutPhase>('exercise');
  const [exerciseSeconds, setExerciseSeconds] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(true);
  const [completedSets, setCompletedSets] = useState<Set<string>>(new Set());
  const [totalTime, setTotalTime] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);
  
  const exerciseTimerRef = useRef<NodeJS.Timeout | null>(null);
  const totalTimerRef = useRef<NodeJS.Timeout | null>(null);
  
  const exercises = workout.exercises;
  const currentExercise = exercises[currentExerciseIndex];
  
  // Total timer - always running
  useEffect(() => {
    totalTimerRef.current = setInterval(() => {
      setTotalTime(prev => prev + 1);
    }, 1000);
    
    return () => {
      if (totalTimerRef.current) clearInterval(totalTimerRef.current);
    };
  }, []);
  
  // Exercise timer - counts up
  useEffect(() => {
    if (isTimerRunning && phase === 'exercise') {
      exerciseTimerRef.current = setInterval(() => {
        setExerciseSeconds(prev => prev + 1);
      }, 1000);
    } else {
      if (exerciseTimerRef.current) clearInterval(exerciseTimerRef.current);
    }
    
    return () => {
      if (exerciseTimerRef.current) clearInterval(exerciseTimerRef.current);
    };
  }, [isTimerRunning, phase]);
  
  // Complete current set
  const completeSet = useCallback(() => {
    if (!currentExercise) return;
    
    const setKey = `${currentExerciseIndex}-${currentSetIndex}`;
    setCompletedSets(prev => new Set([...prev, setKey]));
    
    medium();
    if (soundEnabled) playSound('success');
    
    // Check if more sets in current exercise
    if (currentSetIndex < currentExercise.sets.length - 1) {
      setPhase('rest');
      setCurrentSetIndex(prev => prev + 1);
      setExerciseSeconds(0);
    } else if (currentExerciseIndex < exercises.length - 1) {
      setPhase('rest');
      setCurrentExerciseIndex(prev => prev + 1);
      setCurrentSetIndex(0);
      setExerciseSeconds(0);
    } else {
      // Workout complete
      setPhase('complete');
      celebration();
      if (soundEnabled) playSound('achievement');
      
      updateStreak(new Date().toISOString().split('T')[0]);
      if (!achievements.find(a => a.type === 'first_workout')?.unlockedAt) {
        unlockAchievement('first_workout');
      }
      
      if (totalTimerRef.current) clearInterval(totalTimerRef.current);
      
      onComplete({
        ...workout,
        completed: true,
        duration: Math.round(totalTime / 60),
        updatedAt: new Date().toISOString(),
      });
    }
  }, [currentExercise, currentExerciseIndex, currentSetIndex, exercises.length, medium, playSound, soundEnabled, celebration, updateStreak, achievements, unlockAchievement, totalTime, onComplete, workout]);
  
  // Handle rest complete
  const handleRestComplete = useCallback(() => {
    setPhase('exercise');
    light();
    if (soundEnabled) playSound('click');
  }, [light, playSound, soundEnabled]);
  
  // Go back
  const goBack = useCallback(() => {
    if (currentSetIndex > 0) {
      setCurrentSetIndex(prev => prev - 1);
    } else if (currentExerciseIndex > 0) {
      setCurrentExerciseIndex(prev => prev - 1);
      setCurrentSetIndex(exercises[currentExerciseIndex - 1].sets.length - 1);
    }
    setPhase('exercise');
    setExerciseSeconds(0);
    light();
  }, [currentExerciseIndex, currentSetIndex, exercises, light]);
  
  // Format time
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  // Calculate progress
  const totalSets = exercises.reduce((sum, ex) => sum + ex.sets.length, 0);
  const completedSetsCount = completedSets.size;
  const progress = totalSets > 0 ? (completedSetsCount / totalSets) * 100 : 0;
  
  // Workout complete screen
  if (phase === 'complete') {
    return (
      <WorkoutCompleteScreen
        workout={workout}
        totalTime={totalTime}
        onExit={onExit}
      />
    );
  }
  
  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <button onClick={onExit} className="text-muted-foreground text-sm font-medium">
          Exit
        </button>
        <div className="text-center">
          <p className="text-sm font-semibold">{workout.name}</p>
          <p className="text-xs text-muted-foreground">{formatTime(totalTime)}</p>
        </div>
        <button 
          onClick={() => setSoundEnabled(!soundEnabled)}
          className="p-2 text-muted-foreground"
        >
          {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
        </button>
      </div>
      
      {/* Progress bar */}
      <div className="h-2 bg-secondary">
        <div 
          className="h-full bg-primary transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>
      
      {/* Main content */}
      <div className="flex-1 overflow-y-auto">
        {phase === 'rest' ? (
          <RestPhase
            restTime={REST_TIME}
            nextExercise={exercises[currentExerciseIndex]}
            nextSetIndex={currentSetIndex}
            currentExerciseIndex={currentExerciseIndex}
            totalExercises={exercises.length}
            onComplete={handleRestComplete}
            soundEnabled={soundEnabled}
          />
        ) : (
          <ExercisePhase
            exercise={currentExercise}
            setIndex={currentSetIndex}
            timerSeconds={exerciseSeconds}
            isTimerRunning={isTimerRunning}
            onToggleTimer={() => setIsTimerRunning(!isTimerRunning)}
            currentExerciseIndex={currentExerciseIndex}
            totalExercises={exercises.length}
            completedSets={completedSets}
            onResetTimer={() => setExerciseSeconds(0)}
          />
        )}
      </div>
      
      {/* Bottom controls */}
      <div className="p-4 border-t border-border safe-area-bottom">
        {phase === 'exercise' ? (
          <div className="space-y-3">
            <div className="grid grid-cols-3 gap-2">
              <HapticButton
                variant="secondary"
                onClick={goBack}
                disabled={currentExerciseIndex === 0 && currentSetIndex === 0}
                className="h-14"
              >
                <ChevronLeft className="w-5 h-5" />
              </HapticButton>
              
              <HapticButton
                onClick={completeSet}
                className="h-14 bg-primary"
              >
                <Check className="w-5 h-5 mr-1" />
                Done
              </HapticButton>
              
              <HapticButton
                variant="secondary"
                onClick={completeSet}
                className="h-14"
              >
                <SkipForward className="w-5 h-5" />
              </HapticButton>
            </div>
          </div>
        ) : (
          <HapticButton
            onClick={handleRestComplete}
            className="w-full h-14"
          >
            <Play className="w-5 h-5 mr-2" />
            Skip Rest
          </HapticButton>
        )}
      </div>
    </div>
  );
}

// Exercise Phase Component
function ExercisePhase({
  exercise,
  setIndex,
  timerSeconds,
  isTimerRunning,
  onToggleTimer,
  currentExerciseIndex,
  totalExercises,
  completedSets,
  onResetTimer,
}: {
  exercise: WorkoutExercise;
  setIndex: number;
  timerSeconds: number;
  isTimerRunning: boolean;
  onToggleTimer: () => void;
  currentExerciseIndex: number;
  totalExercises: number;
  completedSets: Set<string>;
  onResetTimer: () => void;
}) {
  const exerciseSVG = getExerciseSVG(exercise.exerciseId || exercise.exerciseName || 'default');
  const totalSets = exercise.sets.length;
  
  return (
    <div className="p-4">
      {/* Exercise counter */}
      <div className="flex items-center justify-between mb-4">
        <span className="text-xs text-muted-foreground uppercase tracking-wide">
          Exercise {currentExerciseIndex + 1} of {totalExercises}
        </span>
        <span className="text-xs text-primary font-semibold">
          Set {setIndex + 1} of {totalSets}
        </span>
      </div>
      
      {/* Exercise illustration */}
      <div className="w-44 h-44 mx-auto mb-4 bg-secondary rounded-2xl flex items-center justify-center overflow-hidden">
        {exerciseSVG}
      </div>
      
      {/* Exercise name */}
      <h2 className="text-2xl font-bold text-center mb-6">{exercise.exerciseName}</h2>
      
      {/* Set info */}
      <div className="flex justify-center gap-6 mb-6">
        <div className="text-center">
          <p className="text-4xl font-bold text-primary">{setIndex + 1}</p>
          <p className="text-xs text-muted-foreground">Current Set</p>
        </div>
        <div className="w-px bg-border" />
        <div className="text-center">
          <p className="text-4xl font-bold">{exercise.sets[setIndex]?.reps || 10}</p>
          <p className="text-xs text-muted-foreground">Reps</p>
        </div>
      </div>
      
      {/* Timer */}
      <div className="bg-card border border-border rounded-xl p-4 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Set Timer</span>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={onResetTimer} className="text-xs text-muted-foreground">
              <RotateCcw className="w-4 h-4" />
            </button>
            <span className="text-2xl font-mono font-bold">
              {Math.floor(timerSeconds / 60)}:{(timerSeconds % 60).toString().padStart(2, '0')}
            </span>
            <button
              onClick={onToggleTimer}
              className={cn(
                'w-10 h-10 rounded-full flex items-center justify-center transition-colors',
                isTimerRunning ? 'bg-primary text-white' : 'bg-secondary'
              )}
            >
              {isTimerRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Set indicators */}
      <div className="flex justify-center gap-2 mb-4">
        {exercise.sets.map((_, i) => (
          <div
            key={i}
            className={cn(
              'w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium transition-colors',
              completedSets.has(`${currentExerciseIndex}-${i}`) ? 'bg-primary text-white' :
              i === setIndex ? 'bg-primary/20 text-primary border-2 border-primary' :
              'bg-secondary text-muted-foreground'
            )}
          >
            {completedSets.has(`${currentExerciseIndex}-${i}`) ? <Check className="w-5 h-5" /> : i + 1}
          </div>
        ))}
      </div>
      
      {/* Tips */}
      <div className="bg-primary/5 border border-primary/20 rounded-xl p-3">
        <p className="text-sm text-muted-foreground">
          <span className="font-semibold text-primary">Tip: </span>
          Focus on controlled movements. Breathe out during exertion.
        </p>
      </div>
    </div>
  );
}

// Rest Phase Component
function RestPhase({
  restTime,
  nextExercise,
  nextSetIndex,
  currentExerciseIndex,
  totalExercises,
  onComplete,
  soundEnabled,
}: {
  restTime: number;
  nextExercise: WorkoutExercise;
  nextSetIndex: number;
  currentExerciseIndex: number;
  totalExercises: number;
  onComplete: () => void;
  soundEnabled: boolean;
}) {
  const [seconds, setSeconds] = useState(restTime);
  
  useEffect(() => {
    const timer = setInterval(() => {
      setSeconds(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          onComplete();
          return restTime;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [onComplete, restTime]);
  
  const progress = ((restTime - seconds) / restTime) * 100;
  
  return (
    <div className="flex flex-col items-center justify-center p-8 h-full">
      {/* Timer circle */}
      <div className="relative w-48 h-48 mb-6">
        <svg className="w-full h-full transform -rotate-90">
          <circle cx="96" cy="96" r="88" stroke="#E0E0E0" strokeWidth="8" fill="none" />
          <circle
            cx="96"
            cy="96"
            r="88"
            stroke="#00C853"
            strokeWidth="8"
            fill="none"
            strokeDasharray={553}
            strokeDashoffset={553 - (553 * progress) / 100}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-5xl font-bold">{seconds}</span>
          <span className="text-sm text-muted-foreground">seconds rest</span>
        </div>
      </div>
      
      <h3 className="text-xl font-semibold mb-2">Rest Time</h3>
      
      {/* Next up */}
      <div className="w-full max-w-xs mt-4 p-4 bg-card border border-border rounded-xl">
        <p className="text-xs text-muted-foreground uppercase mb-2">Up Next</p>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center">
            {getExerciseSVG(nextExercise.exerciseId || 'default')}
          </div>
          <div>
            <p className="font-medium">{nextExercise.exerciseName}</p>
            <p className="text-sm text-muted-foreground">
              Set {nextSetIndex + 1} / {nextExercise.sets.length}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// Workout Complete Screen
function WorkoutCompleteScreen({ workout, totalTime, onExit }: { workout: Workout; totalTime: number; onExit: () => void }) {
  const { celebration } = useHaptic();
  const { playSound } = useAudio();
  
  useEffect(() => {
    celebration();
    playSound('achievement');
  }, [celebration, playSound]);
  
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins} min ${secs} sec`;
  };
  
  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col items-center justify-center p-6">
      <div className="w-32 h-32 bg-primary rounded-full flex items-center justify-center mb-6 animate-bounce-in">
        <Check className="w-16 h-16 text-white" />
      </div>
      
      <h1 className="text-3xl font-bold mb-2 text-center">Workout Complete!</h1>
      <p className="text-muted-foreground mb-8 text-center">{workout.name}</p>
      
      <div className="w-full max-w-xs grid grid-cols-2 gap-4 mb-8">
        <div className="bg-card border border-border rounded-xl p-4 text-center">
          <Clock className="w-6 h-6 text-primary mx-auto mb-2" />
          <p className="text-2xl font-bold">{formatDuration(totalTime)}</p>
          <p className="text-xs text-muted-foreground">Duration</p>
        </div>
        <div className="bg-card border border-border rounded-xl p-4 text-center">
          <Target className="w-6 h-6 text-primary mx-auto mb-2" />
          <p className="text-2xl font-bold">{workout.exercises.length}</p>
          <p className="text-xs text-muted-foreground">Exercises</p>
        </div>
        <div className="bg-card border border-border rounded-xl p-4 text-center">
          <Flame className="w-6 h-6 text-primary mx-auto mb-2" />
          <p className="text-2xl font-bold">
            {workout.exercises.reduce((sum, ex) => sum + ex.sets.length, 0)}
          </p>
          <p className="text-xs text-muted-foreground">Sets</p>
        </div>
        <div className="bg-card border border-border rounded-xl p-4 text-center">
          <span className="text-2xl">💪</span>
          <p className="text-2xl font-bold mt-2">+1</p>
          <p className="text-xs text-muted-foreground">Streak</p>
        </div>
      </div>
      
      <HapticButton onClick={onExit} size="lg" className="w-full max-w-xs">
        Done
      </HapticButton>
    </div>
  );
}

export default ActiveWorkoutSession;
