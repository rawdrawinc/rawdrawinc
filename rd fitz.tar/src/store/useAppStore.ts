import { create } from 'zustand';
import type { 
  TabName, 
  UserProfile, 
  AppSettings, 
  StreakData, 
  Achievement,
  Workout,
  Exercise,
  Route,
  FoodEntry,
  JournalEntry,
  Reminder
} from '@/types';
import { 
  getProfile, 
  saveProfile, 
  getSettings, 
  saveSettings, 
  getStreak, 
  saveStreak,
  isOnboardingComplete,
  setOnboardingComplete
} from '@/lib/storage';
import { dbGetAll, dbPut } from '@/lib/db-client';
import { 
  DEFAULT_ACHIEVEMENTS, 
  checkAchievements, 
  updateStreak as updateStreakLogic 
} from '@/lib/milestones';

interface AppState {
  // Navigation
  currentTab: TabName;
  setCurrentTab: (tab: TabName) => void;
  
  // Onboarding
  isOnboarded: boolean;
  setOnboarded: (value: boolean) => void;
  
  // Profile
  profile: UserProfile | null;
  setProfile: (profile: UserProfile) => void;
  updateProfile: (updates: Partial<UserProfile>) => void;
  clearProfile: () => void;
  
  // Settings
  settings: AppSettings;
  setSettings: (settings: AppSettings) => void;
  updateSettings: (updates: Partial<AppSettings>) => void;
  
  // Streak
  streak: StreakData;
  updateStreak: (workoutDate: string) => void;
  
  // Achievements
  achievements: Achievement[];
  initAchievements: () => void;
  unlockAchievement: (type: string) => void;
  
  // Workouts
  workouts: Workout[];
  setWorkouts: (workouts: Workout[]) => void;
  addWorkout: (workout: Workout) => void;
  updateWorkout: (workout: Workout) => void;
  deleteWorkout: (id: string) => void;
  
  // Exercises
  exercises: Exercise[];
  setExercises: (exercises: Exercise[]) => void;
  
  // Routes
  routes: Route[];
  setRoutes: (routes: Route[]) => void;
  addRoute: (route: Route) => void;
  
  // Nutrition
  foodEntries: FoodEntry[];
  setFoodEntries: (entries: FoodEntry[]) => void;
  addFoodEntry: (entry: FoodEntry) => void;
  
  // Journal
  journalEntries: JournalEntry[];
  setJournalEntries: (entries: JournalEntry[]) => void;
  addJournalEntry: (entry: JournalEntry) => void;
  updateJournalEntry: (entry: JournalEntry) => void;
  
  // Reminders
  reminders: Reminder[];
  setReminders: (reminders: Reminder[]) => void;
  addReminder: (reminder: Reminder) => void;
  updateReminder: (reminder: Reminder) => void;
  deleteReminder: (id: string) => void;
  
  // UI State
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  
  // Initialize from storage
  initialize: () => Promise<void>;
}

export const useAppStore = create<AppState>((set, get) => ({
  // Navigation
  currentTab: 'planner',
  setCurrentTab: (tab) => set({ currentTab: tab }),
  
  // Onboarding
  isOnboarded: false,
  setOnboarded: (value) => {
    setOnboardingComplete(value);
    set({ isOnboarded: value });
  },
  
  // Profile
  profile: null,
  setProfile: (profile) => {
    saveProfile(profile);
    set({ profile });
  },
  updateProfile: (updates) => {
    const current = get().profile;
    if (current) {
      const updated = { ...current, ...updates, updatedAt: new Date().toISOString() };
      saveProfile(updated);
      set({ profile: updated });
    }
  },
  clearProfile: () => {
    set({ profile: null });
  },
  
  // Settings
  settings: {
    theme: 'light',
    hapticFeedback: true,
    audioFeedback: true,
    notifications: true,
    units: 'metric',
    language: 'en',
  },
  setSettings: (settings) => {
    saveSettings(settings);
    set({ settings });
  },
  updateSettings: (updates) => {
    const current = get().settings;
    const updated = { ...current, ...updates };
    saveSettings(updated);
    set({ settings: updated });
  },
  
  // Streak
  streak: {
    currentStreak: 0,
    longestStreak: 0,
    lastWorkoutDate: null,
    weeklyActivity: [false, false, false, false, false, false, false],
  },
  updateStreak: (workoutDate) => {
    const current = get().streak;
    const updated = updateStreakLogic(current, workoutDate);
    saveStreak(updated);
    set({ streak: updated });
  },
  
  // Achievements
  achievements: [],
  initAchievements: () => {
    set({ achievements: [...DEFAULT_ACHIEVEMENTS] });
  },
  unlockAchievement: (type) => {
    const current = get().achievements;
    const updated = current.map(a => 
      a.type === type && !a.unlockedAt
        ? { ...a, unlockedAt: new Date().toISOString(), progress: a.target }
        : a
    );
    set({ achievements: updated });
    // Persist to IndexedDB
    updated.forEach(a => dbPut('achievements', a));
  },
  
  // Workouts
  workouts: [],
  setWorkouts: (workouts) => set({ workouts }),
  addWorkout: (workout) => {
    const current = get().workouts;
    set({ workouts: [...current, workout] });
    // Check achievements
    checkAchievements(get());
  },
  updateWorkout: (workout) => {
    const current = get().workouts;
    set({ workouts: current.map(w => w.id === workout.id ? workout : w) });
  },
  deleteWorkout: (id) => {
    const current = get().workouts;
    set({ workouts: current.filter(w => w.id !== id) });
  },
  
  // Exercises
  exercises: [],
  setExercises: (exercises) => set({ exercises }),
  
  // Routes
  routes: [],
  setRoutes: (routes) => set({ routes }),
  addRoute: (route) => {
    const current = get().routes;
    set({ routes: [...current, route] });
  },
  
  // Nutrition
  foodEntries: [],
  setFoodEntries: (entries) => set({ foodEntries: entries }),
  addFoodEntry: (entry) => {
    const current = get().foodEntries;
    set({ foodEntries: [...current, entry] });
  },
  
  // Journal
  journalEntries: [],
  setJournalEntries: (entries) => set({ journalEntries: entries }),
  addJournalEntry: (entry) => {
    const current = get().journalEntries;
    set({ journalEntries: [...current, entry] });
  },
  updateJournalEntry: (entry) => {
    const current = get().journalEntries;
    set({ journalEntries: current.map(e => e.id === entry.id ? entry : e) });
  },
  
  // Reminders
  reminders: [],
  setReminders: (reminders) => set({ reminders }),
  addReminder: (reminder) => {
    const current = get().reminders;
    set({ reminders: [...current, reminder] });
  },
  updateReminder: (reminder) => {
    const current = get().reminders;
    set({ reminders: current.map(r => r.id === reminder.id ? reminder : r) });
  },
  deleteReminder: (id) => {
    const current = get().reminders;
    set({ reminders: current.filter(r => r.id !== id) });
  },
  
  // UI State
  isLoading: true,
  setIsLoading: (loading) => set({ isLoading: loading }),
  
  // Initialize from storage
  initialize: async () => {
    try {
      // Load from localStorage
      const profile = getProfile();
      const settings = getSettings();
      const streak = getStreak();
      const onboarded = isOnboardingComplete();
      
      // Load from IndexedDB
      const [workouts, routes, foodEntries, journalEntries, reminders, achievements] = await Promise.all([
        dbGetAll<Workout>('workouts'),
        dbGetAll<Route>('routes'),
        dbGetAll<FoodEntry>('nutrition'),
        dbGetAll<JournalEntry>('journal'),
        dbGetAll<Reminder>('reminders'),
        dbGetAll<Achievement>('achievements'),
      ]);
      
      set({
        profile,
        settings,
        streak,
        isOnboarded: onboarded,
        workouts,
        routes,
        foodEntries,
        journalEntries,
        reminders,
        achievements: achievements.length > 0 ? achievements : DEFAULT_ACHIEVEMENTS,
        isLoading: false,
      });
    } catch (error) {
      console.error('Failed to initialize app:', error);
      set({ isLoading: false });
    }
  },
}));
