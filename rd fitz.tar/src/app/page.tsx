'use client';

import { useEffect, useState, useMemo } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { BottomNav, Header } from '@/components/layout/BottomNav';
import { OnboardingFlow } from '@/components/onboarding/OnboardingFlow';
import { WeeklyCalendar, WorkoutCard, QuickAddWorkout } from '@/components/planner/WeeklyCalendar';
import { ExerciseLibrary } from '@/components/exercises/ExerciseLibrary';
import { GPSTracker } from '@/components/tracking/GPSTracker';
import { NutritionTracker } from '@/components/nutrition/NutritionTracker';
import { NotesJournal } from '@/components/journal/NotesJournal';
import { AchievementsDisplay } from '@/components/achievements/AchievementsDisplay';
import { ActiveWorkoutSession } from '@/components/workout/ActiveWorkoutSession';
import { HapticButton } from '@/components/common/HapticButton';
import { cn } from '@/lib/utils';
import { WORKOUT_TEMPLATES, COMPREHENSIVE_EXERCISES } from '@/data/exercises';
import type { Workout, WorkoutType, UserProfile, WorkoutExercise } from '@/types';
import { Plus, Sparkles, Dumbbell, Target, Calendar, LogOut, Bell, Zap, BookOpen, Play } from 'lucide-react';
import { format, isToday, isSameDay } from 'date-fns';
import { v4 as uuidv4 } from 'uuid';

// Getting Started Guide
function GettingStartedGuide({ onClose }: { onClose: () => void }) {
  const steps = [
    { icon: Play, title: 'Start a Workout', desc: 'Tap Start Workout to begin with timer and exercises' },
    { icon: Calendar, title: 'Schedule', desc: 'Add workouts or generate a Smart Plan' },
    { icon: Dumbbell, title: 'Browse Exercises', desc: '50+ exercises with tutorials' },
    { icon: Target, title: 'Earn Badges', desc: 'Complete workouts to unlock achievements' },
  ];
  
  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-card w-full max-w-sm rounded-2xl overflow-hidden animate-bounce-in">
        <div className="bg-primary p-6 text-center">
          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
            <Dumbbell className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-xl font-bold text-white">Welcome to RD FITZ</h2>
          <p className="text-white/80 text-sm mt-1">Your personal gym copilot</p>
        </div>
        
        <div className="p-5">
          <h3 className="font-semibold mb-4 text-center">Quick Start Guide</h3>
          <div className="space-y-3">
            {steps.map((step, i) => (
              <div key={i} className="flex items-center gap-3 p-3 bg-secondary/50 rounded-lg">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <step.icon className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-sm">{step.title}</p>
                  <p className="text-xs text-muted-foreground">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
          
          <HapticButton onClick={onClose} className="w-full mt-5" size="lg">
            Get Started
          </HapticButton>
        </div>
      </div>
    </div>
  );
}

// Planner Tab
function PlannerTab() {
  const { workouts, addWorkout, updateWorkout, profile, updateStreak, achievements, unlockAchievement } = useAppStore();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  const [activeWorkout, setActiveWorkout] = useState<Workout | null>(null);
  
  useEffect(() => {
    const hasSeenGuide = localStorage.getItem('rdfitz_seen_guide');
    if (!hasSeenGuide) {
      setShowGuide(true);
    }
  }, []);
  
  const selectedDayWorkout = useMemo(() => {
    return workouts.find(w => isSameDay(new Date(w.date), selectedDate));
  }, [workouts, selectedDate]);
  
  const handleAddWorkout = (type: WorkoutType) => {
    const template = WORKOUT_TEMPLATES[type];
    if (!template) return;
    
    const workoutExercises: WorkoutExercise[] = template.exercises.map(exId => {
      const exercise = COMPREHENSIVE_EXERCISES.find(e => e.id === exId);
      return {
        exerciseId: exId,
        exerciseName: exercise?.name || 'Exercise',
        sets: [
          { reps: 10, completed: false },
          { reps: 10, completed: false },
          { reps: 10, completed: false }
        ],
        notes: '',
      };
    });
    
    const workout: Workout = {
      id: uuidv4(),
      date: selectedDate.toISOString(),
      name: template.name,
      type,
      exercises: workoutExercises,
      duration: template.duration,
      intensity: template.intensity,
      completed: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    addWorkout(workout);
    setShowQuickAdd(false);
  };
  
  const handleStartWorkout = (workout: Workout) => {
    setActiveWorkout(workout);
  };
  
  const handleCompleteWorkout = (completedWorkout: Workout) => {
    updateWorkout(completedWorkout);
    updateStreak(new Date().toISOString().split('T')[0]);
    
    if (!achievements.find(a => a.type === 'first_workout')?.unlockedAt) {
      unlockAchievement('first_workout');
    }
    
    setActiveWorkout(null);
  };
  
  const handleGeneratePlan = async () => {
    setIsGenerating(true);
    
    try {
      const response = await fetch('/api/generate-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          goals: profile?.goals || ['strength'],
          availableDays: profile?.preferredDays || ['monday', 'wednesday', 'friday'],
          equipment: profile?.equipment || ['none'],
          duration: 45,
        }),
      });

      if (response.ok) {
        const plan = await response.json();
        
        if (plan.weeklyPlan && Array.isArray(plan.weeklyPlan)) {
          for (const dayPlan of plan.weeklyPlan) {
            if (dayPlan.workout && dayPlan.workout.type !== 'rest') {
              const workoutExercises: WorkoutExercise[] = (dayPlan.workout.exercises || []).map((ex: { name: string; sets: number; reps: string }) => ({
                exerciseId: uuidv4(),
                exerciseName: ex.name,
                sets: Array(ex.sets || 3).fill(null).map(() => ({ reps: parseInt(ex.reps?.split('-')[0]) || 10, completed: false })),
                notes: '',
              }));
              
              const workout: Workout = {
                id: uuidv4(),
                date: getDateForDay(dayPlan.day).toISOString(),
                name: dayPlan.workout.name || 'Workout',
                type: dayPlan.workout.type || 'full_body',
                exercises: workoutExercises,
                duration: dayPlan.workout.duration || 45,
                intensity: dayPlan.workout.intensity || 'medium',
                completed: false,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
              };
              addWorkout(workout);
            }
          }
        }
      }
    } catch (error) {
      console.error('Failed to generate plan:', error);
    } finally {
      setIsGenerating(false);
    }
  };
  
  // Active workout session
  if (activeWorkout) {
    return (
      <ActiveWorkoutSession
        workout={activeWorkout}
        onComplete={handleCompleteWorkout}
        onExit={() => setActiveWorkout(null)}
      />
    );
  }
  
  return (
    <div className="flex flex-col h-full">
      <WeeklyCalendar onSelectDay={setSelectedDate} />

      <div className="px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold">
              {isToday(selectedDate) ? 'Today' : format(selectedDate, 'EEEE')}
            </h2>
            <p className="text-sm text-muted-foreground">
              {format(selectedDate, 'MMMM d, yyyy')}
            </p>
          </div>
          <HapticButton
            onClick={handleGeneratePlan}
            variant="secondary"
            size="sm"
            disabled={isGenerating}
          >
            <Sparkles className="w-4 h-4 mr-1" />
            {isGenerating ? 'Creating...' : 'Smart Plan'}
          </HapticButton>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {selectedDayWorkout ? (
          <WorkoutCard
            workout={selectedDayWorkout}
            onStart={() => handleStartWorkout(selectedDayWorkout)}
          />
        ) : (
          <div className="text-center py-8">
            <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
              <Dumbbell className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="font-semibold mb-2">No workout scheduled</h3>
            <p className="text-muted-foreground mb-6 text-sm max-w-xs mx-auto">
              Add a workout for this day or generate a Smart Plan
            </p>
            
            <div className="space-y-3">
              <HapticButton onClick={() => setShowQuickAdd(true)} className="w-full max-w-xs mx-auto">
                <Plus className="w-4 h-4 mr-2" />
                Add Workout
              </HapticButton>
              
              <button 
                onClick={handleGeneratePlan}
                className="flex items-center justify-center gap-2 text-primary text-sm font-medium w-full"
              >
                <Sparkles className="w-4 h-4" />
                Generate AI Smart Plan
              </button>
            </div>
          </div>
        )}
        
        <div className="mt-6 p-4 bg-primary/5 border border-primary/20 rounded-xl">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
              <BookOpen className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="font-medium text-sm mb-1">Quick Tip</p>
              <p className="text-xs text-muted-foreground">
                Tap "Start Workout" to begin with a timer, exercise guides, and rest periods.
              </p>
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={() => setShowQuickAdd(true)}
        className="fixed bottom-20 right-4 w-14 h-14 bg-primary text-white rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-transform z-40"
      >
        <Plus className="w-6 h-6" />
      </button>

      {showQuickAdd && (
        <QuickAddWorkout
          date={selectedDate}
          onAdd={handleAddWorkout}
          onClose={() => setShowQuickAdd(false)}
        />
      )}
      
      {showGuide && (
        <GettingStartedGuide onClose={() => {
          setShowGuide(false);
          localStorage.setItem('rdfitz_seen_guide', 'true');
        }} />
      )}
    </div>
  );
}

// Profile Tab
function ProfileTab() {
  const { profile, settings, updateSettings, setOnboarded, streak, achievements } = useAppStore();
  const unlockedCount = achievements.filter(a => a.unlockedAt).length;

  const handleResetOnboarding = () => {
    if (confirm('Reset app and start over? All data will be lost.')) {
      localStorage.clear();
      indexedDB.deleteDatabase('rdfitz-db');
      setOnboarded(false);
      window.location.reload();
    }
  };

  if (!profile) return null;

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <div className="p-6 border-b border-border">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
            <span className="text-2xl font-bold text-primary">
              {profile.name.charAt(0).toUpperCase()}
            </span>
          </div>
          <div>
            <h2 className="text-xl font-bold">{profile.name}</h2>
            <p className="text-muted-foreground text-sm">Member since {format(new Date(profile.createdAt), 'MMM yyyy')}</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="bg-card border border-border rounded-xl p-3 text-center">
            <Zap className="w-5 h-5 mx-auto mb-1 text-primary" />
            <p className="text-xl font-bold">{streak.currentStreak}</p>
            <p className="text-xs text-muted-foreground">Streak</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-3 text-center">
            <Target className="w-5 h-5 mx-auto mb-1 text-primary" />
            <p className="text-xl font-bold">{unlockedCount}</p>
            <p className="text-xs text-muted-foreground">Badges</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-3 text-center">
            <Calendar className="w-5 h-5 mx-auto mb-1 text-primary" />
            <p className="text-xl font-bold">{streak.longestStreak}</p>
            <p className="text-xs text-muted-foreground">Best</p>
          </div>
        </div>
      </div>

      <div className="p-4 border-b border-border">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-3">Your Goals</h3>
        <div className="flex flex-wrap gap-2">
          {profile.goals.map((goal) => (
            <span key={goal} className="px-3 py-1.5 bg-primary/10 text-primary rounded-full text-sm capitalize">
              {goal.replace('_', ' ')}
            </span>
          ))}
        </div>
      </div>

      <div className="p-4">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-3">Settings</h3>

        <div className="space-y-2">
          <SettingRow
            icon={<Bell className="w-5 h-5" />}
            label="Notifications"
            description="Push notifications"
            value={settings.notifications}
            onChange={(v) => updateSettings({ notifications: v })}
          />
          <SettingRow
            icon={<Zap className="w-5 h-5" />}
            label="Haptic Feedback"
            description="Vibration on interactions"
            value={settings.hapticFeedback}
            onChange={(v) => updateSettings({ hapticFeedback: v })}
          />
          <SettingRow
            icon={<Sparkles className="w-5 h-5" />}
            label="Sound Effects"
            description="Audio feedback"
            value={settings.audioFeedback}
            onChange={(v) => updateSettings({ audioFeedback: v })}
          />
        </div>

        <div className="mt-6 pt-6 border-t border-border">
          <HapticButton
            onClick={handleResetOnboarding}
            variant="ghost"
            className="w-full text-destructive"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Reset App
          </HapticButton>
        </div>
      </div>
    </div>
  );
}

interface SettingRowProps {
  icon: React.ReactNode;
  label: string;
  description: string;
  value: boolean;
  onChange: (value: boolean) => void;
}

function SettingRow({ icon, label, description, value, onChange }: SettingRowProps) {
  return (
    <div className="flex items-center justify-between py-3">
      <div className="flex items-center gap-3">
        <div className="text-muted-foreground">{icon}</div>
        <div>
          <p className="font-medium">{label}</p>
          <p className="text-small text-muted-foreground">{description}</p>
        </div>
      </div>
      <button
        onClick={() => onChange(!value)}
        className={cn(
          'w-12 h-6 rounded-full transition-colors',
          value ? 'bg-primary' : 'bg-secondary'
        )}
      >
        <div
          className={cn(
            'w-5 h-5 bg-white rounded-full shadow transition-transform',
            value ? 'translate-x-6' : 'translate-x-0.5'
          )}
        />
      </button>
    </div>
  );
}

function getDateForDay(dayName: string): Date {
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const today = new Date();
  const targetDay = days.indexOf(dayName.toLowerCase());
  const currentDay = today.getDay();
  const diff = targetDay - currentDay;
  const targetDate = new Date(today);
  targetDate.setDate(today.getDate() + diff);
  return targetDate;
}

// Main App
export default function Home() {
  const { isOnboarded, setOnboarded, setProfile, initialize, isLoading, currentTab } = useAppStore();

  useEffect(() => {
    initialize();
    
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(console.error);
    }
  }, [initialize]);

  const handleOnboardingComplete = (data: { name: string; goals: string[]; preferredDays: string[]; equipment: string[] }) => {
    const profile: UserProfile = {
      id: uuidv4(),
      name: data.name,
      goals: data.goals as UserProfile['goals'],
      preferredDays: data.preferredDays as UserProfile['preferredDays'],
      equipment: data.equipment as UserProfile['equipment'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      onboardingCompleted: true,
    };
    setProfile(profile);
    setOnboarded(true);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isOnboarded) {
    return (
      <div className="min-h-screen bg-background">
        <OnboardingFlow onComplete={handleOnboardingComplete} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pb-16 max-w-lg mx-auto" style={{ height: 'calc(100vh - 60px)' }}>
        {currentTab === 'planner' && <PlannerTab />}
        {currentTab === 'workouts' && <ExerciseLibrary />}
        {currentTab === 'tracking' && <GPSTracker />}
        {currentTab === 'nutrition' && <NutritionTracker />}
        {currentTab === 'journal' && <NotesJournal />}
        {currentTab === 'achievements' && <AchievementsDisplay />}
        {currentTab === 'profile' && <ProfileTab />}
      </main>

      <BottomNav />
    </div>
  );
}
