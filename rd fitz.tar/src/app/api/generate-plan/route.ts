import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { COMPREHENSIVE_EXERCISES, WORKOUT_TEMPLATES } from '@/data/exercises';

interface GeneratedPlan {
  weeklyPlan: Array<{
    day: string;
    workout: {
      name: string;
      type: string;
      exercises: Array<{
        name: string;
        sets: number;
        reps: string;
        muscleGroup: string;
      }>;
      duration: number;
      intensity: string;
    };
  }>;
  tips: string[];
}

// Fallback plan generator using templates
function generateFallbackPlan(
  goals: string[],
  availableDays: string[],
  equipment: string[],
  duration: number
): GeneratedPlan {
  const days = availableDays.length;
  const hasEquipment = !equipment.includes('none') || equipment.length > 1;
  
  // Determine workout split based on days
  let workoutTypes: string[] = [];
  
  if (days <= 2) {
    workoutTypes = ['full_body', 'full_body'];
  } else if (days === 3) {
    workoutTypes = ['push', 'pull', 'legs'];
  } else if (days === 4) {
    workoutTypes = ['push', 'pull', 'legs', 'full_body'];
  } else if (days >= 5) {
    workoutTypes = ['push', 'pull', 'legs', 'push', 'pull'];
  }
  
  // Filter by goals
  if (goals.includes('weight_loss')) {
    workoutTypes = workoutTypes.map((t, i) => 
      i % 2 === 0 ? t : 'cardio'
    );
  }
  
  // Filter exercises by equipment
  const availableExercises = hasEquipment 
    ? COMPREHENSIVE_EXERCISES 
    : COMPREHENSIVE_EXERCISES.filter(e => 
        e.equipment.includes('none') || e.equipment.length === 0
      );
  
  const weeklyPlan = availableDays.slice(0, workoutTypes.length).map((day, index) => {
    const type = workoutTypes[index] || 'full_body';
    const template = WORKOUT_TEMPLATES[type as keyof typeof WORKOUT_TEMPLATES] || WORKOUT_TEMPLATES.full_body;
    
    // Get exercises for this workout
    const workoutExercises = template.exercises
      .map(exId => availableExercises.find(e => e.id === exId))
      .filter(Boolean)
      .slice(0, 6)
      .map((exercise, i) => ({
        name: exercise!.name,
        sets: 3 + (i < 2 ? 1 : 0),
        reps: type === 'cardio' ? '30 sec' : (goals.includes('strength') ? '5-8' : '8-12'),
        muscleGroup: exercise!.muscleGroup,
      }));
    
    return {
      day,
      workout: {
        name: template.name,
        type,
        exercises: workoutExercises,
        duration: template.duration,
        intensity: template.intensity,
      },
    };
  });
  
  const tips = [
    'Rest 60-90 seconds between sets',
    'Stay hydrated throughout your workout',
    'Focus on proper form over heavy weights',
    'Track your progress to see improvements',
  ];
  
  return { weeklyPlan, tips };
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      goals = ['strength'], 
      availableDays = ['monday', 'wednesday', 'friday'], 
      equipment = ['none'], 
      experienceLevel = 'intermediate', 
      duration = 45 
    } = body;
    
    // Try AI generation first
    try {
      const zai = await ZAI.create();
      
      // Build exercise list for context
      const exerciseList = COMPREHENSIVE_EXERCISES
        .filter(e => equipment.includes('none') || e.equipment.some(eq => equipment.includes(eq)))
        .slice(0, 30)
        .map(e => `${e.name} (${e.muscleGroup})`)
        .join(', ');
      
      const prompt = `You are a professional fitness coach. Create a weekly workout plan.

User Profile:
- Goals: ${Array.isArray(goals) ? goals.join(', ') : goals}
- Available days: ${Array.isArray(availableDays) ? availableDays.join(', ') : availableDays}
- Equipment: ${Array.isArray(equipment) ? equipment.join(', ') : equipment}
- Experience: ${experienceLevel}
- Duration per workout: ${duration} minutes

Available exercises: ${exerciseList}

Create a specific, actionable weekly plan. For each workout day, provide exercises from the list above.

Respond ONLY with valid JSON in this exact format:
{
  "weeklyPlan": [
    {
      "day": "monday",
      "workout": {
        "name": "Push Day",
        "type": "push",
        "exercises": [
          { "name": "Barbell Bench Press", "sets": 4, "reps": "8-10", "muscleGroup": "chest" },
          { "name": "Push-ups", "sets": 3, "reps": "12-15", "muscleGroup": "chest" }
        ],
        "duration": 45,
        "intensity": "medium"
      }
    }
  ],
  "tips": ["Recovery tip", "Nutrition tip"]
}`;

      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are a professional fitness coach that creates personalized workout plans. Always respond with valid JSON only, no markdown code blocks.',
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: 0.7,
        max_tokens: 2500,
      });
      
      const responseText = completion.choices[0]?.message?.content || '';
      
      // Parse JSON response
      try {
        let jsonStr = responseText.trim();
        
        // Remove markdown code blocks if present
        const jsonMatch = jsonStr.match(/```(?:json)?\s*([\s\S]*?)```/);
        if (jsonMatch) {
          jsonStr = jsonMatch[1];
        }
        
        const plan = JSON.parse(jsonStr);
        
        // Validate the plan has required structure
        if (plan.weeklyPlan && Array.isArray(plan.weeklyPlan)) {
          return NextResponse.json(plan);
        }
        
        throw new Error('Invalid plan structure');
        
      } catch {
        console.log('Failed to parse AI response, using fallback');
        // Return fallback plan
        const fallbackPlan = generateFallbackPlan(goals, availableDays, equipment, duration);
        return NextResponse.json(fallbackPlan);
      }
      
    } catch (aiError) {
      console.log('AI generation failed, using fallback plan:', aiError);
      const fallbackPlan = generateFallbackPlan(goals, availableDays, equipment, duration);
      return NextResponse.json(fallbackPlan);
    }
    
  } catch (error) {
    console.error('Generate plan error:', error);
    
    // Return a basic fallback plan
    return NextResponse.json(
      generateFallbackPlan(
        ['strength'], 
        ['monday', 'wednesday', 'friday'], 
        ['none'], 
        45
      )
    );
  }
}
