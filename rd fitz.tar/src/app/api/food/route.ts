import { NextRequest, NextResponse } from 'next/server';

const OPEN_FOOD_FACTS_API = 'https://world.openfoodfacts.org/api/v2';

// Common foods database as fallback
const COMMON_FOODS = [
  { id: 'chicken-breast', name: 'Chicken Breast (cooked)', calories: 165, protein: 31, carbs: 0, fat: 3.6, servingSize: 100, servingUnit: 'g' },
  { id: 'brown-rice', name: 'Brown Rice (cooked)', calories: 112, protein: 2.6, carbs: 24, fat: 0.9, servingSize: 100, servingUnit: 'g' },
  { id: 'broccoli', name: 'Broccoli (steamed)', calories: 35, protein: 2.8, carbs: 7, fat: 0.4, servingSize: 100, servingUnit: 'g' },
  { id: 'salmon', name: 'Salmon (baked)', calories: 208, protein: 20, carbs: 0, fat: 13, servingSize: 100, servingUnit: 'g' },
  { id: 'sweet-potato', name: 'Sweet Potato (baked)', calories: 103, protein: 2.3, carbs: 24, fat: 0.1, servingSize: 100, servingUnit: 'g' },
  { id: 'eggs', name: 'Eggs (whole, boiled)', calories: 155, protein: 13, carbs: 1.1, fat: 11, servingSize: 100, servingUnit: 'g' },
  { id: 'egg-white', name: 'Egg White', calories: 52, protein: 11, carbs: 0.7, fat: 0.2, servingSize: 100, servingUnit: 'g' },
  { id: 'oatmeal', name: 'Oatmeal (cooked)', calories: 68, protein: 2.4, carbs: 12, fat: 1.4, servingSize: 100, servingUnit: 'g' },
  { id: 'banana', name: 'Banana', calories: 89, protein: 1.1, carbs: 23, fat: 0.3, servingSize: 100, servingUnit: 'g' },
  { id: 'apple', name: 'Apple', calories: 52, protein: 0.3, carbs: 14, fat: 0.2, servingSize: 100, servingUnit: 'g' },
  { id: 'greek-yogurt', name: 'Greek Yogurt (plain)', calories: 100, protein: 17, carbs: 6, fat: 0.7, servingSize: 100, servingUnit: 'g' },
  { id: 'almonds', name: 'Almonds', calories: 579, protein: 21, carbs: 22, fat: 50, servingSize: 100, servingUnit: 'g' },
  { id: 'whey-protein', name: 'Whey Protein (shake)', calories: 120, protein: 24, carbs: 3, fat: 1.5, servingSize: 30, servingUnit: 'g' },
  { id: 'tuna', name: 'Tuna (canned in water)', calories: 116, protein: 26, carbs: 0, fat: 0.8, servingSize: 100, servingUnit: 'g' },
  { id: 'turkey', name: 'Turkey Breast (roasted)', calories: 135, protein: 30, carbs: 0, fat: 1, servingSize: 100, servingUnit: 'g' },
  { id: 'cottage-cheese', name: 'Cottage Cheese (low-fat)', calories: 72, protein: 12, carbs: 3, fat: 1, servingSize: 100, servingUnit: 'g' },
  { id: 'spinach', name: 'Spinach (raw)', calories: 23, protein: 2.9, carbs: 3.6, fat: 0.4, servingSize: 100, servingUnit: 'g' },
  { id: 'avocado', name: 'Avocado', calories: 160, protein: 2, carbs: 9, fat: 15, servingSize: 100, servingUnit: 'g' },
  { id: 'black-beans', name: 'Black Beans (cooked)', calories: 132, protein: 8.9, carbs: 24, fat: 0.5, servingSize: 100, servingUnit: 'g' },
  { id: 'quinoa', name: 'Quinoa (cooked)', calories: 120, protein: 4.4, carbs: 21, fat: 1.9, servingSize: 100, servingUnit: 'g' },
  { id: 'beef-ground', name: 'Ground Beef (lean, cooked)', calories: 250, protein: 26, carbs: 0, fat: 15, servingSize: 100, servingUnit: 'g' },
  { id: 'milk', name: 'Milk (2%)', calories: 50, protein: 3.3, carbs: 5, fat: 1.9, servingSize: 100, servingUnit: 'ml' },
  { id: 'orange', name: 'Orange', calories: 47, protein: 0.9, carbs: 12, fat: 0.1, servingSize: 100, servingUnit: 'g' },
  { id: 'peanut-butter', name: 'Peanut Butter', calories: 588, protein: 25, carbs: 20, fat: 50, servingSize: 100, servingUnit: 'g' },
  { id: 'protein-bar', name: 'Protein Bar (average)', calories: 200, protein: 20, carbs: 22, fat: 7, servingSize: 50, servingUnit: 'g' },
];

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search');
    const barcode = searchParams.get('barcode');
    
    if (barcode) {
      // Search by barcode
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        
        const response = await fetch(`${OPEN_FOOD_FACTS_API}/product/${barcode}`, {
          signal: controller.signal,
          headers: {
            'Accept': 'application/json',
            'User-Agent': 'RDFitz-Gym-App/1.0',
          },
        });
        
        clearTimeout(timeoutId);
        
        if (!response.ok) {
          throw new Error('Product not found');
        }
        
        const data = await response.json();
        
        if (data.status === 0) {
          return NextResponse.json({ error: 'Product not found' }, { status: 404 });
        }
        
        const product = data.product;
        
        return NextResponse.json({
          id: product.code,
          name: product.product_name || 'Unknown Product',
          barcode: product.code,
          calories: Math.round(product.nutriments?.['energy-kcal_100g'] || 0),
          protein: Math.round((product.nutriments?.proteins_100g || 0) * 10) / 10,
          carbs: Math.round((product.nutriments?.carbohydrates_100g || 0) * 10) / 10,
          fat: Math.round((product.nutriments?.fat_100g || 0) * 10) / 10,
          fiber: Math.round((product.nutriments?.fiber_100g || 0) * 10) / 10,
          sugar: Math.round((product.nutriments?.sugars_100g || 0) * 10) / 10,
          servingSize: 100,
          servingUnit: 'g',
          source: 'openfoodfacts',
        });
      } catch {
        return NextResponse.json({ error: 'Product not found' }, { status: 404 });
      }
    }
    
    if (search) {
      // Search by name - first check local database
      const lowerSearch = search.toLowerCase();
      const localMatches = COMMON_FOODS.filter(food => 
        food.name.toLowerCase().includes(lowerSearch)
      );
      
      // Try OpenFoodFacts API
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        
        const response = await fetch(
          `${OPEN_FOOD_FACTS_API}/search?search_terms=${encodeURIComponent(search)}&page_size=10&fields=code,product_name,nutriments`,
          {
            signal: controller.signal,
            headers: {
              'Accept': 'application/json',
              'User-Agent': 'RDFitz-Gym-App/1.0',
            },
          }
        );
        
        clearTimeout(timeoutId);
        
        if (response.ok) {
          const data = await response.json();
          
          const apiProducts = (data.products || []).map((product: { code: string; product_name?: string; nutriments?: Record<string, number> }) => ({
            id: product.code,
            name: product.product_name || 'Unknown Product',
            barcode: product.code,
            calories: Math.round(product.nutriments?.['energy-kcal_100g'] || 0),
            protein: Math.round((product.nutriments?.proteins_100g || 0) * 10) / 10,
            carbs: Math.round((product.nutriments?.carbohydrates_100g || 0) * 10) / 10,
            fat: Math.round((product.nutriments?.fat_100g || 0) * 10) / 10,
            servingSize: 100,
            servingUnit: 'g',
            source: 'openfoodfacts',
          }));
          
          // Merge local and API results
          return NextResponse.json({
            results: [...localMatches, ...apiProducts.filter((p: { name: string }) => 
              !localMatches.some(l => l.name.toLowerCase() === p.name.toLowerCase())
            )],
            count: localMatches.length + apiProducts.length,
          });
        }
      } catch {
        // API failed, return local results
      }
      
      // Return local results
      return NextResponse.json({
        results: localMatches,
        count: localMatches.length,
        source: 'local',
      });
    }
    
    // No search provided - return common foods
    return NextResponse.json({
      results: COMMON_FOODS,
      count: COMMON_FOODS.length,
      source: 'local',
    });
    
  } catch (error) {
    console.error('Food API error:', error);
    return NextResponse.json({
      results: COMMON_FOODS,
      count: COMMON_FOODS.length,
      source: 'local',
      error: 'Using local data',
    });
  }
}
