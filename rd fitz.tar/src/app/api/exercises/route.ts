import { NextRequest, NextResponse } from 'next/server';
import { COMPREHENSIVE_EXERCISES, searchExercises, getExercisesByMuscle } from '@/data/exercises';

const WGER_API_BASE = 'https://wger.de/api/v2';

// Muscle group mapping
const MUSCLE_GROUPS: Record<number, string> = {
  1: 'biceps',
  2: 'forearms',
  3: 'triceps',
  4: 'back',
  5: 'chest',
  6: 'shoulders',
  7: 'abs',
  8: 'glutes',
  9: 'calves',
  10: 'hamstrings',
  11: 'quadriceps',
  12: 'neck',
  13: 'obliques',
  14: 'cardio',
};

// Equipment mapping
const EQUIPMENT_MAP: Record<number, string> = {
  1: 'barbell',
  2: 'none',
  3: 'dumbbells',
  4: 'kettlebell',
  5: 'cable_machine',
  6: 'treadmill',
  7: 'bench',
  8: 'pull_up_bar',
  9: 'resistance_bands',
  10: 'bike',
  11: 'rower',
};

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const muscle = searchParams.get('muscle');
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '100');
    const useLocal = searchParams.get('local') === 'true';
    
    // If local data is requested or muscle filter/search, use local database
    if (useLocal || muscle || search) {
      let results = COMPREHENSIVE_EXERCISES;
      
      if (muscle) {
        results = getExercisesByMuscle(muscle);
      }
      
      if (search) {
        results = searchExercises(search);
      }
      
      return NextResponse.json({
        results: results.slice(0, limit),
        count: results.length,
        source: 'local',
      });
    }
    
    // Try to fetch from Wger API with timeout
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      
      const response = await fetch(`${WGER_API_BASE}/exercise/?limit=${limit}&language=2`, {
        signal: controller.signal,
        headers: { 'Accept': 'application/json' },
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        throw new Error('Wger API failed');
      }
      
      const data = await response.json();
      
      // Fetch exercise images
      const imageResponse = await fetch(`${WGER_API_BASE}/exerciseimage/?limit=200`, {
        headers: { 'Accept': 'application/json' },
      });
      
      const imageData = imageResponse.ok ? await imageResponse.json() : { results: [] };
      
      // Create image map
      const imageMap = new Map<number, string>();
      imageData.results?.forEach((img: { exercise: number; image: string; is_main: boolean }) => {
        if (img.is_main && !imageMap.has(img.exercise)) {
          imageMap.set(img.exercise, img.image);
        }
      });
      
      // Transform Wger data
      const wgerExercises = data.results
        .filter((ex: { status: string }) => ex.status === '2')
        .map((ex: { id: number; name: string; description: string; muscles: number[]; muscles_secondary: number[]; equipment: number[] }) => ({
          id: `wger-${ex.id}`,
          name: ex.name,
          muscleGroup: MUSCLE_GROUPS[ex.muscles[0]] || 'other',
          secondaryMuscles: ex.muscles_secondary.map((m: number) => MUSCLE_GROUPS[m]).filter(Boolean),
          equipment: ex.equipment.map((e: number) => EQUIPMENT_MAP[e]).filter(Boolean),
          description: ex.description.replace(/<[^>]*>/g, ''),
          instructions: ex.description.replace(/<[^>]*>/g, '').split('\n').filter(Boolean),
          image: imageMap.get(ex.id) || undefined,
        }));
      
      // Merge with local exercises (remove duplicates by name)
      const localNames = new Set(COMPREHENSIVE_EXERCISES.map(e => e.name.toLowerCase()));
      const uniqueWger = wgerExercises.filter((e: { name: string }) => !localNames.has(e.name.toLowerCase()));
      const allExercises = [...COMPREHENSIVE_EXERCISES, ...uniqueWger];
      
      return NextResponse.json({
        results: allExercises.slice(0, limit),
        count: allExercises.length,
        source: 'merged',
      });
      
    } catch {
      // Fallback to local data
      console.log('Wger API unavailable, using local database');
      return NextResponse.json({
        results: COMPREHENSIVE_EXERCISES.slice(0, limit),
        count: COMPREHENSIVE_EXERCISES.length,
        source: 'local',
      });
    }
    
  } catch (error) {
    console.error('Exercise API error:', error);
    // Always return local data as fallback
    return NextResponse.json({
      results: COMPREHENSIVE_EXERCISES,
      count: COMPREHENSIVE_EXERCISES.length,
      source: 'local',
      error: 'Using local fallback data',
    });
  }
}

// Get single exercise by ID
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { id } = body;
    
    const exercise = COMPREHENSIVE_EXERCISES.find(e => e.id === id);
    
    if (!exercise) {
      return NextResponse.json({ error: 'Exercise not found' }, { status: 404 });
    }
    
    return NextResponse.json(exercise);
    
  } catch {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
}
