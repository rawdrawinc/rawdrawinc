import { NextRequest, NextResponse } from 'next/server';

// Using Nominatim (OpenStreetMap) for free reverse geocoding
const NOMINATIM_API = 'https://nominatim.openstreetmap.org';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const lat = searchParams.get('lat');
    const lng = searchParams.get('lng');
    
    if (!lat || !lng) {
      return NextResponse.json(
        { error: 'Missing lat or lng parameters' },
        { status: 400 }
      );
    }
    
    // Reverse geocode
    const response = await fetch(
      `${NOMINATIM_API}/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18`,
      {
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'RDFitz-Gym-App/1.0',
        },
      }
    );
    
    if (!response.ok) {
      throw new Error('Failed to geocode');
    }
    
    const data = await response.json();
    
    return NextResponse.json({
      displayName: data.display_name,
      address: data.address,
      lat: data.lat,
      lng: data.lon,
    });
  } catch (error) {
    console.error('Geocode API error:', error);
    return NextResponse.json(
      { error: 'Failed to geocode location' },
      { status: 500 }
    );
  }
}
