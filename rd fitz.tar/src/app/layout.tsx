import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "RD FITZ - My Gym Copilot",
  description: "Your personal gym copilot. Plan workouts, track progress, and achieve your fitness goals with a privacy-first approach.",
  keywords: ["fitness", "workout", "gym", "planner", "exercise", "health", "nutrition", "tracking"],
  authors: [{ name: "RD FITZ Team" }],
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "RD FITZ",
  },
  formatDetection: {
    telephone: false,
  },
  openGraph: {
    type: "website",
    siteName: "RD FITZ",
    title: "RD FITZ - My Gym Copilot",
    description: "Your personal gym copilot for workout planning and tracking",
  },
  twitter: {
    card: "summary",
    title: "RD FITZ - My Gym Copilot",
    description: "Your personal gym copilot for workout planning and tracking",
  },
  icons: {
    icon: [
      { url: "/icons/icon-192x192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512x512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [
      { url: "/icons/apple-icon-180x180.png", sizes: "180x180", type: "image/png" },
    ],
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#F5F5F5" },
    { media: "(prefers-color-scheme: dark)", color: "#1A1A1A" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* PWA Meta Tags for iOS */}
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="RD FITZ" />
        <meta name="mobile-web-app-capable" content="yes" />
        
        {/* iOS Splash Screens */}
        <link rel="apple-touch-icon" href="/icons/apple-icon-180x180.png" />
        
        {/* Preconnect to external APIs */}
        <link rel="preconnect" href="https://wger.de" />
        <link rel="preconnect" href="https://world.openfoodfacts.org" />
      </head>
      <body
        className={`${inter.variable} antialiased bg-background text-foreground font-sans`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
