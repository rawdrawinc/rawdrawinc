import type { Achievement, AchievementType, StreakData, AppState } from '@/types';

export const DEFAULT_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_workout',
    type: 'first_workout',
    title: 'First Steps',
    description: 'Complete your first workout',
    icon: 'trophy',
    unlockedAt: undefined,
    progress: 0,
    target: 1,
    tier: 'bronze',
  },
  {
    id: 'workouts_5',
    type: 'workouts_5',
    title: 'Getting Started',
    description: 'Complete 5 workouts',
    icon: 'flame',
    unlockedAt: undefined,
    progress: 0,
    target: 5,
    tier: 'bronze',
  },
  {
    id: 'workouts_10',
    type: 'workouts_10',
    title: 'Building Momentum',
    description: 'Complete 10 workouts',
    icon: 'zap',
    unlockedAt: undefined,
    progress: 0,
    target: 10,
    tier: 'silver',
  },
  {
    id: 'workouts_50',
    type: 'workouts_50',
    title: 'Dedicated Athlete',
    description: 'Complete 50 workouts',
    icon: 'medal',
    unlockedAt: undefined,
    progress: 0,
    target: 50,
    tier: 'gold',
  },
  {
    id: 'workouts_100',
    type: 'workouts_100',
    title: 'Century Club',
    description: 'Complete 100 workouts',
    icon: 'crown',
    unlockedAt: undefined,
    progress: 0,
    target: 100,
    tier: 'platinum',
  },
  {
    id: 'first_5km',
    type: 'first_5km',
    title: '5K Runner',
    description: 'Complete your first 5km run',
    icon: 'map-pin',
    unlockedAt: undefined,
    progress: 0,
    target: 5000,
    tier: 'bronze',
  },
  {
    id: 'first_10km',
    type: 'first_10km',
    title: '10K Champion',
    description: 'Complete your first 10km run',
    icon: 'mountain',
    unlockedAt: undefined,
    progress: 0,
    target: 10000,
    tier: 'silver',
  },
  {
    id: 'streak_7',
    type: 'streak_7',
    title: 'Week Warrior',
    description: 'Maintain a 7-day streak',
    icon: 'flame',
    unlockedAt: undefined,
    progress: 0,
    target: 7,
    tier: 'bronze',
  },
  {
    id: 'streak_30',
    type: 'streak_30',
    title: 'Monthly Master',
    description: 'Maintain a 30-day streak',
    icon: 'star',
    unlockedAt: undefined,
    progress: 0,
    target: 30,
    tier: 'gold',
  },
  {
    id: 'streak_100',
    type: 'streak_100',
    title: 'Unstoppable',
    description: 'Maintain a 100-day streak',
    icon: 'rocket',
    unlockedAt: undefined,
    progress: 0,
    target: 100,
    tier: 'platinum',
  },
];

export function updateStreak(currentStreak: StreakData, workoutDate: string): StreakData {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const workoutDay = new Date(workoutDate);
  workoutDay.setHours(0, 0, 0, 0);
  
  const lastWorkout = currentStreak.lastWorkoutDate 
    ? new Date(currentStreak.lastWorkoutDate) 
    : null;
  
  let newCurrentStreak = currentStreak.currentStreak;
  let newLongestStreak = currentStreak.longestStreak;
  
  // Update weekly activity
  const dayOfWeek = workoutDay.getDay();
  const newWeeklyActivity = [...currentStreak.weeklyActivity];
  newWeeklyActivity[dayOfWeek] = true;
  
  if (!lastWorkout) {
    // First workout
    newCurrentStreak = 1;
    newLongestStreak = 1;
  } else {
    const lastWorkoutDay = new Date(lastWorkout);
    lastWorkoutDay.setHours(0, 0, 0, 0);
    
    const diffDays = Math.floor((workoutDay.getTime() - lastWorkoutDay.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) {
      // Consecutive day
      newCurrentStreak += 1;
      newLongestStreak = Math.max(newLongestStreak, newCurrentStreak);
    } else if (diffDays === 0) {
      // Same day, no change
    } else {
      // Streak broken
      newCurrentStreak = 1;
    }
  }
  
  return {
    currentStreak: newCurrentStreak,
    longestStreak: newLongestStreak,
    lastWorkoutDate: workoutDate,
    weeklyActivity: newWeeklyActivity,
  };
}

export function checkAchievements(state: AppState): AchievementType[] {
  const unlocked: AchievementType[] = [];
  const completedWorkouts = state.workouts.filter(w => w.completed);
  
  // Check workout count achievements
  const workoutCount = completedWorkouts.length;
  
  if (workoutCount >= 1 && !state.achievements.find(a => a.type === 'first_workout')?.unlockedAt) {
    unlocked.push('first_workout');
  }
  if (workoutCount >= 5 && !state.achievements.find(a => a.type === 'workouts_5')?.unlockedAt) {
    unlocked.push('workouts_5');
  }
  if (workoutCount >= 10 && !state.achievements.find(a => a.type === 'workouts_10')?.unlockedAt) {
    unlocked.push('workouts_10');
  }
  if (workoutCount >= 50 && !state.achievements.find(a => a.type === 'workouts_50')?.unlockedAt) {
    unlocked.push('workouts_50');
  }
  if (workoutCount >= 100 && !state.achievements.find(a => a.type === 'workouts_100')?.unlockedAt) {
    unlocked.push('workouts_100');
  }
  
  // Check streak achievements
  if (state.streak.currentStreak >= 7 && !state.achievements.find(a => a.type === 'streak_7')?.unlockedAt) {
    unlocked.push('streak_7');
  }
  if (state.streak.currentStreak >= 30 && !state.achievements.find(a => a.type === 'streak_30')?.unlockedAt) {
    unlocked.push('streak_30');
  }
  if (state.streak.currentStreak >= 100 && !state.achievements.find(a => a.type === 'streak_100')?.unlockedAt) {
    unlocked.push('streak_100');
  }
  
  // Check running achievements
  const maxDistance = Math.max(...state.routes.map(r => r.distance), 0);
  if (maxDistance >= 5000 && !state.achievements.find(a => a.type === 'first_5km')?.unlockedAt) {
    unlocked.push('first_5km');
  }
  if (maxDistance >= 10000 && !state.achievements.find(a => a.type === 'first_10km')?.unlockedAt) {
    unlocked.push('first_10km');
  }
  
  return unlocked;
}

export function getAchievementProgress(
  achievement: Achievement, 
  state: AppState
): number {
  const completedWorkouts = state.workouts.filter(w => w.completed);
  
  switch (achievement.type) {
    case 'first_workout':
      return Math.min(completedWorkouts.length, 1);
    case 'workouts_5':
    case 'workouts_10':
    case 'workouts_50':
    case 'workouts_100':
      return completedWorkouts.length;
    case 'streak_7':
    case 'streak_30':
    case 'streak_100':
      return state.streak.currentStreak;
    case 'first_5km':
    case 'first_10km':
      const maxDistance = Math.max(...state.routes.map(r => r.distance), 0);
      return maxDistance;
    default:
      return achievement.progress;
  }
}
