import { useState, useEffect, useCallback } from 'react';

const DB_NAME = 'rdfitz-db';
const DB_VERSION = 1;

interface DBStores {
  workouts: IDBObjectStore;
  exercises: IDBObjectStore;
  routes: IDBObjectStore;
  nutrition: IDBObjectStore;
  journal: IDBObjectStore;
  reminders: IDBObjectStore;
  achievements: IDBObjectStore;
}

type StoreNames = keyof DBStores;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      
      if (!db.objectStoreNames.contains('workouts')) {
        db.createObjectStore('workouts', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('exercises')) {
        db.createObjectStore('exercises', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('routes')) {
        db.createObjectStore('routes', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('nutrition')) {
        db.createObjectStore('nutrition', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('journal')) {
        db.createObjectStore('journal', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('reminders')) {
        db.createObjectStore('reminders', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('achievements')) {
        db.createObjectStore('achievements', { keyPath: 'id' });
      }
    };
  });
}

export async function dbGet<T>(storeName: StoreNames, key: string): Promise<T | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readonly');
    const store = transaction.objectStore(storeName);
    const request = store.get(key);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result || null);
  });
}

export async function dbGetAll<T>(storeName: StoreNames): Promise<T[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readonly');
    const store = transaction.objectStore(storeName);
    const request = store.getAll();
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result || []);
  });
}

export async function dbPut<T>(storeName: StoreNames, value: T): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.put(value);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
}

export async function dbDelete(storeName: StoreNames, key: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.delete(key);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
}

export async function dbClear(storeName: StoreNames): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.clear();
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
}

export function useIndexedDB<T>(storeName: StoreNames) {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  
  const load = useCallback(async () => {
    try {
      setLoading(true);
      const result = await dbGetAll<T>(storeName);
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Unknown error'));
    } finally {
      setLoading(false);
    }
  }, [storeName]);
  
  useEffect(() => {
    load();
  }, [load]);
  
  const add = useCallback(async (item: T) => {
    await dbPut(storeName, item);
    await load();
  }, [storeName, load]);
  
  const update = useCallback(async (item: T) => {
    await dbPut(storeName, item);
    await load();
  }, [storeName, load]);
  
  const remove = useCallback(async (key: string) => {
    await dbDelete(storeName, key);
    await load();
  }, [storeName, load]);
  
  const clear = useCallback(async () => {
    await dbClear(storeName);
    await load();
  }, [storeName, load]);
  
  return { data, loading, error, add, update, remove, clear, reload: load };
}

export { openDB };
