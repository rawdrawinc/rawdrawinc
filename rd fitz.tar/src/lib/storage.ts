import type { UserProfile, AppSettings, StreakData } from '@/types';

const STORAGE_KEYS = {
  PROFILE: 'rdfitz_profile',
  SETTINGS: 'rdfitz_settings',
  STREAK: 'rdfitz_streak',
  ONBOARDING_COMPLETE: 'rdfitz_onboarding_complete',
  LAST_SYNC: 'rdfitz_last_sync',
} as const;

// Default values
const DEFAULT_SETTINGS: AppSettings = {
  theme: 'light',
  hapticFeedback: true,
  audioFeedback: true,
  notifications: true,
  units: 'metric',
  language: 'en',
};

const DEFAULT_STREAK: StreakData = {
  currentStreak: 0,
  longestStreak: 0,
  lastWorkoutDate: null,
  weeklyActivity: [false, false, false, false, false, false, false],
};

// Profile storage
export function getProfile(): UserProfile | null {
  if (typeof window === 'undefined') return null;
  try {
    const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export function saveProfile(profile: UserProfile): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
}

export function clearProfile(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(STORAGE_KEYS.PROFILE);
}

// Settings storage
export function getSettings(): AppSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return data ? { ...DEFAULT_SETTINGS, ...JSON.parse(data) } : DEFAULT_SETTINGS;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
}

// Streak storage
export function getStreak(): StreakData {
  if (typeof window === 'undefined') return DEFAULT_STREAK;
  try {
    const data = localStorage.getItem(STORAGE_KEYS.STREAK);
    return data ? { ...DEFAULT_STREAK, ...JSON.parse(data) } : DEFAULT_STREAK;
  } catch {
    return DEFAULT_STREAK;
  }
}

export function saveStreak(streak: StreakData): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.STREAK, JSON.stringify(streak));
}

// Onboarding status
export function isOnboardingComplete(): boolean {
  if (typeof window === 'undefined') return false;
  return localStorage.getItem(STORAGE_KEYS.ONBOARDING_COMPLETE) === 'true';
}

export function setOnboardingComplete(complete: boolean): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.ONBOARDING_COMPLETE, String(complete));
}

// Last sync time
export function getLastSync(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(STORAGE_KEYS.LAST_SYNC);
}

export function setLastSync(time: string): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.LAST_SYNC, time);
}

// Clear all storage
export function clearAllStorage(): void {
  if (typeof window === 'undefined') return;
  Object.values(STORAGE_KEYS).forEach(key => {
    localStorage.removeItem(key);
  });
}
